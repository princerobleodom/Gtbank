(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [4048], {
        74048: function(e, t, n) {
            var i = window.define;
            i("hotline-web/templates/home", (function() {
                return n(40070)
            })), i("hotline-web/routes/home", (function() {
                return n(59789)
            })), i("hotline-web/templates/home/all-conversations", (function() {
                return n(49877)
            })), i("hotline-web/routes/home/all-conversations", (function() {
                return n(99387)
            })), i("hotline-web/templates/home/all-topics", (function() {
                return n(18324)
            })), i("hotline-web/routes/home/all-topics", (function() {
                return n(16672)
            })), i("hotline-web/templates/home/help-widget", (function() {
                return n(84924)
            })), i("hotline-web/routes/home/help-widget", (function() {
                return n(99531)
            })), i("hotline-web/templates/home/index", (function() {
                return n(8556)
            }))
        },
        52718: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return k
                }
            });
            var i, o, r, s, l, a, u, c, d, h, f, p, g, m, v, b, y, w = n(10935),
                E = n(34645),
                C = n(5660),
                Z = n(69049),
                I = n(58678),
                O = n(55411),
                M = n(79833),
                R = n(52626),
                A = n(13256),
                T = n(18006),
                S = n(50660),
                P = n(13418);

            function _(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, M.Z)(e);
                    if (t) {
                        var o = (0, M.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, O.Z)(this, n)
                }
            }
            var k = (i = (0, T.classNames)("channel", "animated", "fadeInLeft"), o = (0, T.classNameBindings)("enabledAgentTypingIndicator"), r = Ember.computed.alias("hotlineUI.config.enabledAgentTypingIndicator"), s = Ember.computed("channel.channelId"), l = Ember.computed("channel.conversationId"), a = Ember.computed("lastAgentMessage.messageId"), u = Ember.inject.service(), c = Ember.computed.readOnly("hotline.ui.isIPhone"), d = Ember.computed("unreadCount"), h = Ember.computed("unreadCount", "isParallelConversationEnabled"), f = Ember.computed.gt("lastMessage.messageFragments.length", 0), i(p = o((g = function(e) {
                (0, I.Z)(n, e);
                var t = _(n);

                function n() {
                    var e;
                    (0, E.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, w.Z)((0, Z.Z)(e), "enabledAgentTypingIndicator", m, (0, Z.Z)(e)), (0, R.Z)((0, Z.Z)(e), "USER", P.default.CONVERSATION.USER_TYPE.USER), (0, w.Z)((0, Z.Z)(e), "hotline", v, (0, Z.Z)(e)), (0, w.Z)((0, Z.Z)(e), "isIPhone", b, (0, Z.Z)(e)), (0, w.Z)((0, Z.Z)(e), "isNonWelcomeMessage", y, (0, Z.Z)(e)), e
                }
                return (0, C.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null === (e = this.channel) || void 0 === e ? void 0 : e.channelId
                    }
                }, {
                    key: "conversationId",
                    get: function() {
                        var e;
                        return null === (e = this.channel) || void 0 === e ? void 0 : e.conversationId
                    }
                }, {
                    key: "currentAgent",
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("messageUserAlias");
                        return !!t && this.agentService.getAgentInfo(t)
                    }
                }, {
                    key: "getAriaLabel",
                    get: function() {
                        var e = this.unreadCount;
                        return e ? e <= 9 ? e > 1 ? this.intl.t("aria_labels.unread_msg_other", {
                            count: e
                        }) : this.intl.t("aria_labels.unread_msg_one") : this.intl.t("aria_labels.unread_msg_other", {
                            count: this.intl.t("common.numbers.nine") + "+"
                        }) : ""
                    }
                }, {
                    key: "unReadParallelConversation",
                    get: function() {
                        return this.isParallelConversationEnabled && this.unreadCount >= P.default.MIN_UNREAD_MSGS ? "unreadMessage" : ""
                    }
                }]), n
            }(Ember.Component.extend(S.default)), m = (0, A.Z)(g.prototype, "enabledAgentTypingIndicator", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, A.Z)(g.prototype, "channelId", [s], Object.getOwnPropertyDescriptor(g.prototype, "channelId"), g.prototype), (0, A.Z)(g.prototype, "conversationId", [l], Object.getOwnPropertyDescriptor(g.prototype, "conversationId"), g.prototype), (0, A.Z)(g.prototype, "currentAgent", [a], Object.getOwnPropertyDescriptor(g.prototype, "currentAgent"), g.prototype), v = (0, A.Z)(g.prototype, "hotline", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), b = (0, A.Z)(g.prototype, "isIPhone", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, A.Z)(g.prototype, "getAriaLabel", [d], Object.getOwnPropertyDescriptor(g.prototype, "getAriaLabel"), g.prototype), (0, A.Z)(g.prototype, "unReadParallelConversation", [h], Object.getOwnPropertyDescriptor(g.prototype, "unReadParallelConversation"), g.prototype), y = (0, A.Z)(g.prototype, "isNonWelcomeMessage", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), p = g)) || p) || p)
        },
        71644: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return U
                }
            });
            var i, o, r, s, l, a, u, c, d, h, f, p, g, m, v, b, y = n(35235),
                w = n(10935),
                E = n(34645),
                C = n(5660),
                Z = n(69049),
                I = n(28433),
                O = n(58678),
                M = n(55411),
                R = n(79833),
                A = n(52626),
                T = n(13256),
                S = n(18006),
                P = n(22126),
                _ = n(16686),
                k = n(75920),
                H = n(32583),
                N = n(60534),
                L = n(13418),
                B = n(65882);

            function j(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function D(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, R.Z)(e);
                    if (t) {
                        var o = (0, R.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, M.Z)(this, n)
                }
            }
            var U = (i = (0, S.tagName)(""), o = Ember.inject.service, r = Ember.computed.gt("displayChannels.length", 3), s = Ember.computed("isStartNew", "isHistoryView", "session.showHistory"), l = Ember.computed("isParallelConversationEnabled", "isExpandAllTopics"), a = Ember.computed("session.{config.content.headers.chat,isMultiWidget}", "hotline.ui.config.{title,appearanceConfig.conversationTitle}"), u = Ember.computed("isStartNew", "displayChannels"), c = Ember.computed("isParallelConversationEnabled", "displayHistoryConversations.[]", "session.user", "isChannelsLoading"), d = Ember.computed, h = Ember.computed(), f = Ember._action, p = Ember._action, i((m = function(e) {
                (0, O.Z)(n, e);
                var t = D(n);

                function n() {
                    var e;
                    (0, E.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, w.Z)((0, Z.Z)(e), "smartPolling", v, (0, Z.Z)(e)), (0, A.Z)((0, Z.Z)(e), "isExpandAllTopics", !1), (0, A.Z)((0, Z.Z)(e), "isLoadedAllConversations", !1), (0, A.Z)((0, Z.Z)(e), "isShowConversationLoadingIcon", !1), (0, A.Z)((0, Z.Z)(e), "isChannelsLoading", !1), (0, A.Z)((0, Z.Z)(e), "images", {
                        LoadingIcon: B.Z
                    }), (0, w.Z)((0, Z.Z)(e), "isShowAllTopics", b, (0, Z.Z)(e)), e
                }
                return (0, C.Z)(n, [{
                    key: "isShowHistoryIcon",
                    get: function() {
                        return this.session.showHistory && !this.isHistoryView && !this.isStartNew
                    }
                }, {
                    key: "isParallelConversation",
                    get: function() {
                        return this.isParallelConversationEnabled && !this.isExpandAllTopics
                    }
                }, {
                    key: "headerTitle",
                    get: function() {
                        var e, t, n, i, o, r, s, l, a, u, c, d = this.intl,
                            h = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i ? void 0 : i.chat,
                            f = this.session.isMultiWidget ? null === (o = this.hotline) || void 0 === o || null === (r = o.ui) || void 0 === r || null === (s = r.config) || void 0 === s || null === (l = s.appearanceConfig) || void 0 === l ? void 0 : l.conversationTitle : null === (a = this.hotline) || void 0 === a || null === (u = a.ui) || void 0 === u || null === (c = u.config) || void 0 === c ? void 0 : c.title;
                        return h ? (0, _.sanitizeHTML)(this, h, "strict") : f ? (0, _.sanitizeHTML)(this, f, "strict") : this.session.isMultiWidget ? d.t("channel.heading_title_chat") : d.t("channel.heading_title")
                    }
                }, {
                    key: "displayAllChannels",
                    get: function() {
                        var e = this;
                        return this.displayChannels.map(function(t) {
                            return (0, y.Z)(this, e), delete t.conversationId,
                                function(e) {
                                    for (var t = 1; t < arguments.length; t++) {
                                        var n = null != arguments[t] ? arguments[t] : {};
                                        t % 2 ? j(Object(n), !0).forEach((function(t) {
                                            (0, A.Z)(e, t, n[t])
                                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : j(Object(n)).forEach((function(t) {
                                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                        }))
                                    }
                                    return e
                                }({}, t)
                        }.bind(this))
                    }
                }, {
                    key: "isShowHistoryLoadingIcon",
                    get: function() {
                        var e, t;
                        return this.isParallelConversationEnabled && 0 === this.displayHistoryConversations.length && this.isChannelsLoading && (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.alias)
                    }
                }, {
                    key: "handleFetchConversationCallback",
                    value: function(e, t) {
                        t && e.length < L.default.CONVERSATION.PAGE_COUNT && this.set("isLoadedAllConversations", !0), this.isDestroyed && this.isDestroying || (this.set("isShowConversationLoadingIcon", !1), this.set("isChannelsLoading", !1)), this.loadConversation(e)
                    }
                }, {
                    key: "conversationCallback",
                    get: function() {
                        return this.handleFetchConversationCallback.bind(this)
                    }
                }, {
                    key: "didInsertElement",
                    value: function() {
                        (0, I.Z)((0, R.Z)(n.prototype), "didInsertElement", this).apply(this, arguments), this.session && this.session.user && this.session.user.alias && !this.isStartNew && !this.isHistoryView && (this.handleHideResolvedConversation(), this.set("isChannelsLoading", !0), this.smartPolling.fetchConversations(this.conversationCallback)), this.isHistoryView && (0, N.bindEvent)(document.querySelector(".history-view-scroll"), "scroll", this.scrollCallback)
                    }
                }, {
                    key: "willDestroyElement",
                    value: function() {
                        (0, I.Z)((0, R.Z)(n.prototype), "willDestroyElement", this).apply(this, arguments), (0, N.unbindEvent)(document.querySelector(".history-view-scroll"), "scroll", this.scrollCallback)
                    }
                }, {
                    key: "onScroll",
                    value: function(e) {
                        var t = document.getElementsByClassName("history-view-scroll")[0],
                            n = t.offsetHeight + t.scrollTop;
                        0 !== t.scrollHeight - n || this.isLoadedAllConversations || (this.set("isShowConversationLoadingIcon", !0), this.handleHideResolvedConversation(), this.smartPolling.fetchConversations(this.conversationCallback, !1, !0))
                    }
                }, {
                    key: "onScrollWithDebounce",
                    value: function() {
                        Ember.run.debounce(this, this.onScroll, L.default.Debounce.SCROLL_DELAY)
                    }
                }, {
                    key: "scrollCallback",
                    get: function() {
                        return this.onScrollWithDebounce.bind(this)
                    }
                }, {
                    key: "handleHideResolvedConversation",
                    value: function() {
                        var e, t = this;
                        (0, H.isHideResolvedConversationEnabled)(null === (e = this.hotlineUI) || void 0 === e ? void 0 : e.config) && (this.conversations || []).forEach(function(e) {
                            (0, y.Z)(this, t), e.isResolved && !e.hasPendingCsat && e.deleteMessages()
                        }.bind(this))
                    }
                }, {
                    key: "showAllTopics",
                    value: function() {
                        this.set("isExpandAllTopics", !this.isExpandAllTopics)
                    }
                }, {
                    key: "showViewHistory",
                    value: function() {
                        this.router.send("gotoHistoryView", "home")
                    }
                }]), n
            }(Ember.Component.extend(k.default, P.default)), v = (0, T.Z)(m.prototype, "smartPolling", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), b = (0, T.Z)(m.prototype, "isShowAllTopics", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, T.Z)(m.prototype, "isShowHistoryIcon", [s], Object.getOwnPropertyDescriptor(m.prototype, "isShowHistoryIcon"), m.prototype), (0, T.Z)(m.prototype, "isParallelConversation", [l], Object.getOwnPropertyDescriptor(m.prototype, "isParallelConversation"), m.prototype), (0, T.Z)(m.prototype, "headerTitle", [a], Object.getOwnPropertyDescriptor(m.prototype, "headerTitle"), m.prototype), (0, T.Z)(m.prototype, "displayAllChannels", [u], Object.getOwnPropertyDescriptor(m.prototype, "displayAllChannels"), m.prototype), (0, T.Z)(m.prototype, "isShowHistoryLoadingIcon", [c], Object.getOwnPropertyDescriptor(m.prototype, "isShowHistoryLoadingIcon"), m.prototype), (0, T.Z)(m.prototype, "conversationCallback", [d], Object.getOwnPropertyDescriptor(m.prototype, "conversationCallback"), m.prototype), (0, T.Z)(m.prototype, "scrollCallback", [h], Object.getOwnPropertyDescriptor(m.prototype, "scrollCallback"), m.prototype), (0, T.Z)(m.prototype, "showAllTopics", [f], Object.getOwnPropertyDescriptor(m.prototype, "showAllTopics"), m.prototype), (0, T.Z)(m.prototype, "showViewHistory", [p], Object.getOwnPropertyDescriptor(m.prototype, "showViewHistory"), m.prototype), g = m)) || g)
        },
        64719: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return H
                }
            });
            var i, o, r, s, l, a, u, c, d, h, f, p, g, m, v = n(35235),
                b = n(10935),
                y = n(34645),
                w = n(5660),
                E = n(69049),
                C = n(28433),
                Z = n(58678),
                I = n(55411),
                O = n(79833),
                M = n(52626),
                R = n(13256),
                A = n(18006),
                T = n(22126),
                S = n(50913),
                P = n(70387),
                _ = n(65882);

            function k(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, O.Z)(e);
                    if (t) {
                        var o = (0, O.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, I.Z)(this, n)
                }
            }
            var H = (i = (0, A.tagName)(""), o = Ember.inject.service, r = Ember.computed.gt("faqCategories.length", 3), s = Ember.computed.gt("faqCategories.length", 0), l = Ember.computed("categories", "categories.[]", "session.faqTags", "hotline.ui.config.contentConfig.categories.[]"), a = Ember.computed("session.isMultiWidget", "hotline.ui.config.appearanceConfig.faqTitle"), u = Ember.computed("faqCategories"), c = Ember._action, d = Ember._action, i((f = function(e) {
                (0, Z.Z)(n, e);
                var t = k(n);

                function n() {
                    var e;
                    (0, y.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, M.Z)((0, E.Z)(e), "images", {
                        UploadingNew: _.Z
                    }), (0, b.Z)((0, E.Z)(e), "hotline", p, (0, E.Z)(e)), (0, b.Z)((0, E.Z)(e), "isShowMoreCategories", g, (0, E.Z)(e)), (0, b.Z)((0, E.Z)(e), "isCategoriesPresent", m, (0, E.Z)(e)), e
                }
                return (0, w.Z)(n, [{
                    key: "faqCategories",
                    get: function() {
                        var e = this;
                        if (this.isKbaseEnabled) {
                            var t, n, i, o = this.store.peekAll("category");
                            if (null !== (t = this.session) && void 0 !== t && t.isMultiWidget && null !== (n = this.hotline.ui) && void 0 !== n && null !== (i = n.config) && void 0 !== i && i.contentConfig) {
                                var r, s, l, a, u = [];
                                return null === (r = this.hotline.ui) || void 0 === r || null === (s = r.config) || void 0 === s || null === (l = s.contentConfig) || void 0 === l || null === (a = l.categories) || void 0 === a || a.forEach(function(t) {
                                    (0, v.Z)(this, e);
                                    var n = o.findBy("categoryId", t);
                                    n && n.enabled && u.pushObject(n)
                                }.bind(this)), u
                            }
                            return o
                        }
                        var c, d = this.categories,
                            h = null === (c = this.session) || void 0 === c ? void 0 : c.faqTags;
                        return this.filterFAQCategories(d, h)
                    }
                }, {
                    key: "getFaqTitle",
                    get: function() {
                        var e, t, n, i;
                        return this.session.isMultiWidget && null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && null !== (n = t.config) && void 0 !== n && null !== (i = n.appearanceConfig) && void 0 !== i && i.faqTitle ? this.hotline.ui.config.appearanceConfig.faqTitle : this.intl.t("faqs.faq_title")
                    }
                }, {
                    key: "willDestroyElement",
                    value: function() {
                        var e, t;
                        (0, C.Z)((0, O.Z)(n.prototype), "willDestroyElement", this).apply(this, arguments), this.isKbaseEnabled && null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.lastSelectedCategoryId && this.set("hotline.ui.lastSelectedCategoryId", null)
                    }
                }, {
                    key: "sliceCategories",
                    get: function() {
                        return this.faqCategories && this.faqCategories.length > 3 ? this.faqCategories.slice(0, 3) : this.faqCategories
                    }
                }, {
                    key: "selectCategory",
                    value: function(e) {
                        var t, n;
                        !this.isKbaseEnabled || null !== (t = this.hotline) && void 0 !== t && null !== (n = t.ui) && void 0 !== n && n.lastSelectedCategoryId || this.set("hotline.ui.lastSelectedCategoryId", e.categoryId), P.default.moveFocusTo(".search-input-text"), this.router.send("gotoFAQArticles", e.categoryId)
                    }
                }, {
                    key: "goToCategory",
                    value: function() {
                        this.router.send("gotoFAQCategory"), P.default.moveFocusTo(".search-input-text")
                    }
                }]), n
            }(Ember.Component.extend(T.default, S.default)), p = (0, R.Z)(f.prototype, "hotline", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), g = (0, R.Z)(f.prototype, "isShowMoreCategories", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), m = (0, R.Z)(f.prototype, "isCategoriesPresent", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, R.Z)(f.prototype, "faqCategories", [l], Object.getOwnPropertyDescriptor(f.prototype, "faqCategories"), f.prototype), (0, R.Z)(f.prototype, "getFaqTitle", [a], Object.getOwnPropertyDescriptor(f.prototype, "getFaqTitle"), f.prototype), (0, R.Z)(f.prototype, "sliceCategories", [u], Object.getOwnPropertyDescriptor(f.prototype, "sliceCategories"), f.prototype), (0, R.Z)(f.prototype, "selectCategory", [c], Object.getOwnPropertyDescriptor(f.prototype, "selectCategory"), f.prototype), (0, R.Z)(f.prototype, "goToCategory", [d], Object.getOwnPropertyDescriptor(f.prototype, "goToCategory"), f.prototype), h = f)) || h)
        },
        41955: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return m
                }
            });
            var i, o, r, s, l = n(34645),
                a = n(5660),
                u = n(58678),
                c = n(55411),
                d = n(79833),
                h = n(13256),
                f = n(18006),
                p = n(22126);

            function g(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, d.Z)(e);
                    if (t) {
                        var o = (0, d.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, c.Z)(this, n)
                }
            }
            var m = (i = (0, f.tagName)(""), o = Ember._action, i((s = function(e) {
                (0, u.Z)(n, e);
                var t = g(n);

                function n() {
                    return (0, l.Z)(this, n), t.apply(this, arguments)
                }
                return (0, a.Z)(n, [{
                    key: "gotoHome",
                    value: function() {
                        this.router.send("handleRoute", this.model.fromPage)
                    }
                }]), n
            }(Ember.Component.extend(p.default)), (0, h.Z)(s.prototype, "gotoHome", [o], Object.getOwnPropertyDescriptor(s.prototype, "gotoHome"), s.prototype), r = s)) || r)
        },
        93497: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(22126),
                r = n(13418),
                s = n(60534),
                l = n(76441);
            t.default = Ember.Component.extend(o.default, {
                store: Ember.inject.service(),
                classNames: ["h-channel"],
                brand: Ember.inject.service("brand-check"),
                images: Ember.Object.create({
                    HomeIcon: l.Z
                }),
                isRoutedFromFAQ: Ember.computed.reads("model.isRoutedFromFAQ"),
                isRateLimited: Ember.computed("hotline.ui.{isKbaseCategoryRateLimited,rateLimitedCategoryArticles}", {
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.isKbaseCategoryRateLimited) || (null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.rateLimitedCategoryArticles)
                    }
                }),
                headerStyle: Ember.computed("hotline.ui.config.appearanceConfig.brandColorStyle", "session.isMultiWidget", {
                    get: function() {
                        var e, t, n, i, o, r, s, l;
                        return this.session.isMultiWidget ? null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.appearanceConfig) || void 0 === i ? void 0 : i.brandColorStyle : null === (o = this.hotline) || void 0 === o || null === (r = o.ui) || void 0 === r || null === (s = r.config) || void 0 === s || null === (l = s.headerProperty) || void 0 === l ? void 0 : l.headerStyle
                    }
                }),
                welcomeMsg: Ember.computed("session.{isMultiWidget,config.content.welcomeMessage}", "hotline.ui.config.appearanceConfig.welcomeMessage", {
                    get: function() {
                        var e, t, n, i, o, r, s;
                        return this.session.isMultiWidget && ((null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n ? void 0 : n.welcomeMessage) || (null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || null === (r = o.config) || void 0 === r || null === (s = r.appearanceConfig) || void 0 === s ? void 0 : s.welcomeMessage))
                    }
                }),
                welcomeSubMessage: Ember.computed("session.{isMultiWidget,config.content.welcomeSubMessage}", "hotline.ui.config.appearanceConfig.welcomeSubMessage", {
                    get: function() {
                        var e, t, n, i, o, r, s;
                        return this.session.isMultiWidget && ((null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n ? void 0 : n.welcomeSubMessage) || (null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || null === (r = o.config) || void 0 === r || null === (s = r.appearanceConfig) || void 0 === s ? void 0 : s.welcomeSubMessage))
                    }
                }),
                brandLogoURL: Ember.computed("session.isMultiWidget", "hotline.ui.config.{appearanceConfig.brandLogoURL,widgetLogoUrl}", {
                    get: function() {
                        var e, t, n, i, o, r, s;
                        return this.session.isMultiWidget ? null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.appearanceConfig) || void 0 === i ? void 0 : i.brandLogoURL : null === (o = this.hotline) || void 0 === o || null === (r = o.ui) || void 0 === r || null === (s = r.config) || void 0 === s ? void 0 : s.widgetLogoUrl
                    }
                }),
                retryRateLimitedUrlIn: Ember.computed.alias("hotline.ui.retryAfter"),
                get hidePoweredBy() {
                    return this.brand.hidePoweredBy
                },
                onScroll: function(e) {
                    var t = e && e.target;
                    t && (parseInt(t.scrollHeight - t.scrollTop - t.clientHeight) <= 0 ? (0, s.addCSSInline)(this.element.querySelector(".bottom-gradient"), "visibility", "hidden") : (0, s.addCSSInline)(this.element.querySelector(".bottom-gradient"), "visibility", "visible"), t.scrollHeight - t.scrollTop - t.clientHeight <= 20 ? (0, s.addClass)(this.element.querySelector(".footer-note"), "show-when-zoom") : (0, s.removeClass)(this.element.querySelector(".footer-note"), "show-when-zoom"), t.scrollTop <= 0 ? (0, s.addCSSInline)(this.element.querySelector(".dummy-bar"), "height", this.session.isMultiWidget ? "3rem" : "1.5rem") : (0, s.addCSSInline)(this.element.querySelector(".dummy-bar"), "height", "0"))
                },
                scrollCallback: Ember.computed({
                    get: function() {
                        return this.onScroll.bind(this)
                    }
                }),
                getShowHistory: function() {
                    var e = this,
                        t = r.default.EmberModelUrl.showHistory,
                        n = this.session,
                        o = n && n.user,
                        s = n && n.token,
                        l = t.url.replace("{token}", s).replace("{userAlias}", o.alias);
                    this.store.getRequest("GET", l).then(function(t) {
                        (0, i.Z)(this, e), this.set("session.showHistory", null == t ? void 0 : t.showHistory)
                    }.bind(this))
                },
                didInsertElement: function() {
                    var e;
                    this._super.apply(this, arguments), (0, s.bindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), this.onScroll({
                        target: this.element.querySelector(".scroll-section")
                    }), this.isParallelFeatureEnabled && !this.isParallelConversationEnabled && null !== (e = this.session.user) && void 0 !== e && e.alias && void 0 === this.session.showHistory && this.getShowHistory()
                },
                willDestroyElement: function() {
                    this._super.apply(this, arguments), this.set("model.isRoutedFromFAQ", !1), (0, s.unbindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback)
                },
                actions: {
                    retryCallbackOnRateLimit: function() {
                        this.router.send("retryCallbackOnRateLimitedUrl")
                    }
                }
            })
        },
        30694: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return Z
                }
            });
            var i, o, r, s, l, a, u, c, d = n(35235),
                h = n(10935),
                f = n(34645),
                p = n(5660),
                g = n(69049),
                m = n(58678),
                v = n(55411),
                b = n(79833),
                y = n(13256),
                w = n(76144),
                E = n(62471);

            function C(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, b.Z)(e);
                    if (t) {
                        var o = (0, b.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, v.Z)(this, n)
                }
            }
            var Z = (i = Ember.inject.service, o = Ember.inject.service, r = Ember.computed.readOnly("session.isHelpWidgetScriptLoaded"), s = Ember.computed("currentLocale"), l = function(e) {
                (0, m.Z)(n, e);
                var t = C(n);

                function n() {
                    var e, i;
                    return (0, f.Z)(this, n), i = t.apply(this, arguments), (0, h.Z)((0, g.Z)(i), "session", a, (0, g.Z)(i)), (0, h.Z)((0, g.Z)(i), "locale", u, (0, g.Z)(i)), (0, h.Z)((0, g.Z)(i), "isHelpWidgetAppReady", c, (0, g.Z)(i)), null !== (e = i.session) && void 0 !== e && e.isHelpWidgetScriptLoaded || i._loadHelpWidgetScript(), i
                }
                return (0, p.Z)(n, [{
                    key: "currentLocale",
                    get: function() {
                        return this.locale.currentLocale()
                    }
                }, {
                    key: "_loadHelpWidgetScript",
                    value: function() {
                        var e = this,
                            t = E.default.helpWidgetCdnUrl;
                        fetch("".concat(t, "/manifest.json")).then(function(t) {
                            return (0, d.Z)(this, e), t.json()
                        }.bind(this)).then(function(n) {
                            var i = this;
                            (0, d.Z)(this, e);
                            var o = n["src/main.tsx"],
                                r = "".concat(t, "/").concat(null == o ? void 0 : o.file);
                            if (r) {
                                var s = document.createElement("script");
                                s.src = r, s.type = "module", s.onload = function() {
                                    (0, d.Z)(this, i), Ember.set(this.session, "isHelpWidgetScriptLoaded", !0)
                                }.bind(this), document.head.appendChild(s)
                            }
                        }.bind(this))
                    }
                }]), n
            }(w.default), a = (0, y.Z)(l.prototype, "session", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), u = (0, y.Z)(l.prototype, "locale", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), c = (0, y.Z)(l.prototype, "isHelpWidgetAppReady", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, y.Z)(l.prototype, "currentLocale", [s], Object.getOwnPropertyDescriptor(l.prototype, "currentLocale"), l.prototype), l)
        },
        56407: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return A
                }
            });
            var i, o, r, s, l, a, u, c, d, h, f = n(35235),
                p = n(10935),
                g = n(34645),
                m = n(5660),
                v = n(69049),
                b = n(28433),
                y = n(58678),
                w = n(55411),
                E = n(79833),
                C = n(52626),
                Z = n(13256),
                I = n(76144),
                O = n(13418),
                M = n(96064);

            function R(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var o = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var A = (i = Ember._tracked, o = Ember.inject.service, r = Ember.inject.service, s = Ember.inject.service, l = Ember.computed("hotline.ui.{isFirstBotMessage,firstBotChannelId}", "channelId"), a = function(e) {
                (0, y.Z)(n, e);
                var t = R(n);

                function n(e, i) {
                    var o, r = this;
                    return (0, g.Z)(this, n), o = t.call(this, e, i), (0, p.Z)((0, v.Z)(o), "isAgentTyping", u, (0, v.Z)(o)), (0, C.Z)((0, v.Z)(o), "agentThread", void 0), (0, C.Z)((0, v.Z)(o), "freddyThread", void 0), (0, C.Z)((0, v.Z)(o), "chatWindow", document.querySelector(".h-conv-chat")), (0, C.Z)((0, v.Z)(o), "onRTSMessageCB", o.onRTSMessage.bind((0, v.Z)(o))), (0, p.Z)((0, v.Z)(o), "rts", c, (0, v.Z)(o)), (0, p.Z)((0, v.Z)(o), "hotline", d, (0, v.Z)(o)), (0, p.Z)((0, v.Z)(o), "session", h, (0, v.Z)(o)), Ember.addListener(o.rts, "didRTSMessage", o.onRTSMessageCB), setTimeout(function() {
                        var e;
                        (0, f.Z)(this, r), Ember.set(null === (e = o.hotline) || void 0 === e ? void 0 : e.ui, "isFirstBotMessage", !1)
                    }.bind(this), O.default.TYPING_INDICATOR_DURATION.FREDDY_BOT), o
                }
                return (0, m.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null !== (e = this.args.channelId) && void 0 !== e ? e : void 0
                    }
                }, {
                    key: "showTypingIndForBots",
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.isFirstBotMessage) && (null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.firstBotChannelId) === this.channelId
                    }
                }, {
                    key: "willDestroy",
                    value: function() {
                        (0, b.Z)((0, E.Z)(n.prototype), "willDestroy", this).apply(this, arguments), Ember.removeListener(this.rts, "didRTSMessage", this.onRTSMessageCB)
                    }
                }, {
                    key: "hideTypingIndicator",
                    value: function() {
                        var e = this.agentThread,
                            t = this.freddyThread;
                        this.isAgentTyping = !1, e && clearTimeout(e), t && clearTimeout(t)
                    }
                }, {
                    key: "showTypingIndicator",
                    value: function(e) {
                        var t = this,
                            n = this.chatWindow,
                            i = this.agentThread;
                        this.isAgentTyping = !0, n && n.scrollTop >= n.scrollHeight - n.offsetHeight - 30 && !document.querySelector(".h-conv-chat .notification-container") && M.default.scrollTo(n, n.scrollHeight, 1500), i && clearTimeout(i), this.agentThread = setTimeout(function() {
                            (0, f.Z)(this, t), this.isDestroying || this.isDestroyed || (this.isAgentTyping = !1)
                        }.bind(this), e)
                    }
                }, {
                    key: "onRTSMessage",
                    value: function(e) {
                        var t, n = this,
                            i = e && e.userId,
                            o = this.channelId,
                            r = this.session.user.id;
                        if (Ember.set(null === (t = this.hotline) || void 0 === t ? void 0 : t.ui, "isFirstBotMessage", !1), "is_typing" === e.action && e.channelId && e.channelId === o && r && r !== parseInt(i, 10)) this.showTypingIndicator(O.default.TYPING_INDICATOR_DURATION.AGENT);
                        else if ("MESSAGE_RECEIVED" === e.type && e.conversation && e.conversation.channelId === o) {
                            r === (e.conversation && e.conversation.messages && e.conversation.messages.length && e.conversation.messages[0].messageUserId) ? e.conversation && e.conversation.status === O.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT && (this.hideTypingIndicator(), this.freddyThread = setTimeout(function() {
                                (0, f.Z)(this, n), this.showTypingIndicator(O.default.TYPING_INDICATOR_DURATION.FREDDY_BOT)
                            }.bind(this), 1e3)) : this.hideTypingIndicator()
                        }
                    }
                }]), n
            }(I.default), u = (0, Z.Z)(a.prototype, "isAgentTyping", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), c = (0, Z.Z)(a.prototype, "rts", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), d = (0, Z.Z)(a.prototype, "hotline", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), h = (0, Z.Z)(a.prototype, "session", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, Z.Z)(a.prototype, "showTypingIndForBots", [l], Object.getOwnPropertyDescriptor(a.prototype, "showTypingIndForBots"), a.prototype), a)
        },
        10228: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return E
                }
            });
            var i, o, r, s, l, a, u = n(10935),
                c = n(34645),
                d = n(5660),
                h = n(69049),
                f = n(58678),
                p = n(55411),
                g = n(79833),
                m = n(52626),
                v = n(13256),
                b = n(76144),
                y = n.p + "freshchat_logo.f6e2dc08072c0bf69ca4c005e561b7dc.png";

            function w(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, g.Z)(e);
                    if (t) {
                        var o = (0, g.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, p.Z)(this, n)
                }
            }
            var E = (i = Ember.inject.service, o = Ember.inject.service, r = Ember.computed("hotline"), s = function(e) {
                (0, f.Z)(n, e);
                var t = w(n);

                function n() {
                    var e;
                    (0, c.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)), (0, u.Z)((0, h.Z)(e), "session", l, (0, h.Z)(e)), (0, u.Z)((0, h.Z)(e), "hotline", a, (0, h.Z)(e)), (0, m.Z)((0, h.Z)(e), "images", {
                        Logo: y
                    }), e
                }
                return (0, d.Z)(n, [{
                    key: "getRemoveFooter",
                    get: function() {
                        var e, t, n, i;
                        return !!this.session.isMultiWidget && (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.appearanceConfig) || void 0 === i ? void 0 : i.removeFreshworksBranding)
                    }
                }]), n
            }(b.default), l = (0, v.Z)(s.prototype, "session", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), a = (0, v.Z)(s.prototype, "hotline", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, v.Z)(s.prototype, "getRemoveFooter", [r], Object.getOwnPropertyDescriptor(s.prototype, "getRemoveFooter"), s.prototype), s)
        },
        72847: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(29436),
                r = n(89567);

            function s(e, t, n) {
                return (e - t) * (e - n) <= 0
            }
            t.default = Ember.Helper.extend({
                compute: function(e, t) {
                    var n = this,
                        l = (0, o.Z)(e, 2),
                        a = l[0],
                        u = l[1];
                    if (a && !isNaN(a)) {
                        var c, d = 0,
                            h = (0, r.default)(a).diff((0, r.default)(), "seconds"),
                            f = !0;
                        if (t && t.updateOnInterval && (f = Boolean(t.updateOnInterval)), u) c = (0, r.default)(a).format(u);
                        else try {
                            c = h < 44 ? (0, r.default)(a).fromNow() : (0, r.default)().fromNow()
                        } catch (e) {
                            c = (0, r.default)(a).format("ddd, LT")
                        }
                        return f && (this.clearTimer(), d = function(e) {
                            return s(e, -89, 89) ? 3 : s(e, -5340, 5340) ? 120 : s(e, -86400, 86400) ? 1800 : 86400
                        }(h), this.intervalTimer = setInterval(function() {
                            var e = this;
                            (0, i.Z)(this, n), Ember.run(function() {
                                return (0, i.Z)(this, e), this.recompute()
                            }.bind(this))
                        }.bind(this), parseInt(1e3 * d, 10))), c
                    }
                    return ""
                },
                clearTimer: function() {
                    clearInterval(this.intervalTimer)
                },
                destroy: function() {
                    this.clearTimer()
                }
            })
        },
        53812: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                },
                lte: function() {
                    return i.lte
                }
            });
            var i = n(2118)
        },
        59789: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return ue
                }
            });
            var i, o, r, s, l, a, u, c, d, h, f, p, g, m, v, b, y, w, E, C, Z, I, O, M, R, A, T, S, P = n(35235),
                _ = n(10935),
                k = n(34645),
                H = n(5660),
                N = n(69049),
                L = n(28433),
                B = n(58678),
                j = n(55411),
                D = n(79833),
                U = n(52626),
                F = n(13256),
                x = n(85853),
                q = n(87643),
                V = n(13418),
                W = n(42410),
                z = n(22126),
                G = n(50913),
                Q = n(71725),
                K = n(75920),
                Y = n(79956),
                J = n(89567),
                X = n(72857),
                $ = n(8653),
                ee = n(4961),
                te = n(50660),
                ne = n(7259),
                ie = n(1053),
                oe = n(32583);

            function re(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function se(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? re(Object(n), !0).forEach((function(t) {
                        (0, U.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : re(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function le(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, D.Z)(e);
                    if (t) {
                        var o = (0, D.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, j.Z)(this, n)
                }
            }
            var ae = V.default.CONVERSATION.MESSAGE_TYPE.IMAGE,
                ue = (i = Ember.inject.service, o = Ember.inject.service, r = Ember.inject.service, s = Ember.inject.service, l = Ember.inject.service, a = Ember.inject.service, u = Ember.inject.service("window-listener"), c = Ember.computed, d = Ember.computed("isKbaseEnabled"), h = Ember.computed("commandHelper"), f = Ember.computed, p = Ember.computed, g = Ember.computed, m = (0, x.observes)("session.user.id"), v = Ember._action, b = Ember._action, y = Ember._action, w = Ember._action, E = Ember._action, C = Ember._action, Z = function(e) {
                    (0, B.Z)(n, e);
                    var t = le(n);

                    function n() {
                        var e;
                        (0, k.Z)(this, n);
                        for (var i = arguments.length, o = new Array(i), r = 0; r < i; r++) o[r] = arguments[r];
                        return e = t.call.apply(t, [this].concat(o)), (0, _.Z)((0, N.Z)(e), "ruleEngine", I, (0, N.Z)(e)), (0, _.Z)((0, N.Z)(e), "notification", O, (0, N.Z)(e)), (0, U.Z)((0, N.Z)(e), "fetchFaqs", !1), (0, _.Z)((0, N.Z)(e), "messageStacker", M, (0, N.Z)(e)), (0, _.Z)((0, N.Z)(e), "postMessage", R, (0, N.Z)(e)), (0, _.Z)((0, N.Z)(e), "user", A, (0, N.Z)(e)), (0, _.Z)((0, N.Z)(e), "smartPolling", T, (0, N.Z)(e)), (0, _.Z)((0, N.Z)(e), "windowListener", S, (0, N.Z)(e)), e
                    }
                    return (0, H.Z)(n, [{
                        key: "model",
                        value: function() {
                            var e, t = null === (e = this.hotline) || void 0 === e ? void 0 : e.ui,
                                n = t && t.userBehaviour,
                                i = t && t.channels,
                                o = t && t.hours,
                                r = n && n.eventRules,
                                s = t && t.rspTime,
                                l = t && t.offlineExperience;
                            return Ember.RSVP.hash({
                                channels: i,
                                hours: o,
                                rspTime: s,
                                eventRules: r,
                                offlineExperience: l
                            })
                        }
                    }, {
                        key: "afterModel",
                        value: function(e) {
                            var t, i, o;
                            null !== (t = this.ruleEngine) && void 0 !== t && t.isFMJourneyEnabled && Ember.addListener(this.rts, "didCampaignMessage", this.onCampaignMessageCB), null !== (i = this.session) && void 0 !== i && null !== (o = i.user) && void 0 !== o && o.id || this.hotline.broadcastConversationLoaded(), this.windowListener.bindNetworkEvents(), e && (this.setupModel(e), this.getAgentsInformationForRules(e), this.getAgentsInformationForChannels(e)), (0, L.Z)((0, D.Z)(n.prototype), "afterModel", this).call(this)
                        }
                    }, {
                        key: "getAgentsInformationForRules",
                        value: function(e) {
                            var t = e && e.eventRules;
                            if (t && t.length > 0)
                                for (var n = t.length - 1; n >= 0; n--) {
                                    var i = t[n];
                                    i.agent && this.store.pushPayload("agent", {
                                        agent: i.agent
                                    }), i.serviceAccount && this.store.pushPayload("agent", {
                                        agent: i.serviceAccount
                                    })
                                }
                        }
                    }, {
                        key: "getAgentsInformationForChannels",
                        value: function(e) {
                            var t = e && e.channels;
                            if (t && t.length > 0)
                                for (var n = t.length - 1; n >= 0; n--) {
                                    var i = t[n];
                                    i.serviceAccount && this.store.pushPayload("agent", {
                                        agent: i.serviceAccount
                                    })
                                }
                        }
                    }, {
                        key: "setupModel",
                        value: function(e) {
                            this.postModel(e), this.isKbaseEnabled ? (this.resetDsFaq(), this.fetchKbaseCategories()) : this.loadFAQS()
                        }
                    }, {
                        key: "fetchKbaseCategories",
                        value: function() {
                            var e = this;
                            this.getKbaseCategories(!0).then(function(t) {
                                var n, i;
                                (0, P.Z)(this, e), t && null !== (n = t.categories) && void 0 !== n && n.length && Ember.set(this.session, "isKbaseFaqAvailable", !0), Ember.setProperties(null === (i = this.hotline) || void 0 === i ? void 0 : i.ui, {
                                    isKbaseCategoryRateLimited: !1,
                                    retryingRateLimitedUrl: !1
                                })
                            }.bind(this), function(t) {
                                var n;
                                (0, P.Z)(this, e);
                                var i, o, r = t && t.errors && t.errors.length && t.errors[0];
                                r && r.status === V.default.HTTP_STATUS_CODES.RATE_LIMIT_ERROR ? Ember.setProperties(null === (i = this.hotline) || void 0 === i ? void 0 : i.ui, {
                                    isKbaseCategoryRateLimited: !0,
                                    retryAfter: r.retryAfter
                                }) : Ember.set(null === (o = this.hotline) || void 0 === o ? void 0 : o.ui, "isKbaseCategoryRateLimited", !1);
                                Ember.set(null === (n = this.hotline) || void 0 === n ? void 0 : n.ui, "retryingRateLimitedUrl", !1)
                            }.bind(this))
                        }
                    }, {
                        key: "postModel",
                        value: function(e) {
                            var t, n, i, o, r, s = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                            e.hours && (e.hours.operatingHours && (e.hours.operatingHours.clientTimeInMillis = (new Date).getTime()), Ember.set(s, "hours", e.hours), this.processOperatingHours(), this.pollster || ((r = $.Z.create({
                                onPoll: this.processOperatingHours.bind(this),
                                interval: 6e4
                            })).start(), this.set("pollster", r))), e.rspTime && Ember.set(s, "rspTime", e.rspTime), Ember.set(s, "userBehaviour", {
                                eventRules: e.eventRules
                            }), -1 !== (null === (n = this.transition) || void 0 === n ? void 0 : n.targetName.indexOf("channels.index")) && this.openChannel(), this.connectSocket(), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), null !== (i = this.session) && void 0 !== i && null !== (o = i.user) && void 0 !== o && o.id || s.dsLoaded || (Ember.set(s, "dsLoaded", !0), this.postMessage.post({
                                action: "datastore_loaded"
                            })), Ember.set(s, "homeRouteLoadMillis", (new Date).getTime()), e.isRoutedFromFAQ = this.transition.to.queryParams.isRoutedFromFAQ
                        }
                    }, {
                        key: "didAuthUserCB",
                        get: function() {
                            return this.didAuthenticateUser.bind(this)
                        }
                    }, {
                        key: "faqRouteName",
                        get: function() {
                            return this.isKbaseEnabled ? "home.kbase-faq" : "home.faqs"
                        }
                    }, {
                        key: "helper",
                        get: function() {
                            return ee.Z.create({
                                scope: this
                            })
                        }
                    }, {
                        key: "didAuthenticateUser",
                        value: function() {
                            this.jwt.auth.expired ? this.disconnectSocket(!1) : this.jwt.auth.user && this.connectSocket()
                        }
                    }, {
                        key: "canShowBusinessClosedBanner",
                        value: function(e) {
                            var t, n, i, o, r, s, l, a, u, c = this;
                            return !!e && (1 === e.filter(function(e) {
                                return (0, P.Z)(this, c), e.enabled && e.defaultBhr
                            }.bind(this)).length && (this.session.isMultiWidget ? null === (t = this.hotline) || void 0 === t || null === (n = t.ui) || void 0 === n || null === (i = n.config) || void 0 === i || null === (o = i.appearanceConfig) || void 0 === o || null === (r = o.widgetVisiblity) || void 0 === r ? void 0 : r.selected : null === (s = this.hotline) || void 0 === s || null === (l = s.ui) || void 0 === l || null === (a = l.config) || void 0 === a || null === (u = a.messengerVisibility) || void 0 === u ? void 0 : u.selected) === V.default.messengerVisibilityOptions.businessHours)
                        }
                    }, {
                        key: "isCurrentDayInHolidays",
                        value: function(e, t) {
                            var n = !1,
                                i = e && e.length;
                            if (i && t)
                                for (var o = 0; o < i; o++) {
                                    var r = e[o],
                                        s = String(r.date).toUpperCase(),
                                        l = (0, J.default)(X.default.convert(new Date, t.replace(" - ", "/"), !0));
                                    if (l && s === l.format("MMM DD").toUpperCase() || s === l.format("MMM D").toUpperCase()) {
                                        n = !0;
                                        break
                                    }
                                }
                            return n
                        }
                    }, {
                        key: "processOperatingHours",
                        value: function() {
                            var e, t, n, i, o, r, s = this,
                                l = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.hours,
                                a = l && l.operatingHours,
                                u = void 0,
                                c = this.canShowBusinessClosedBanner(a);
                            Ember.set(null === (n = this.hotline) || void 0 === n ? void 0 : n.ui, "awayMessage", []);
                            for (var d = 0, h = a.length; d < h; d++) {
                                var f, p, g = a[d],
                                    m = (new Date).getTime(),
                                    v = this.isCurrentDayInHolidays(g.holidays, g.timezone),
                                    b = void 0,
                                    y = void 0,
                                    w = void 0,
                                    E = !0,
                                    C = void 0;
                                if (Ember.set(g, "clientTimeInMillis", (new Date).getTime()), g)
                                    if (g.enabled) {
                                        if (!v)
                                            if (b = m - a.clientTimeInMillis, w = ((y = (0, J.default)(X.default.convert(g.serverTimeInMillis + b, g.timezone.replace(" - ", "/"), !0))).day() + 6) % 7, "true" !== g.working[w]) E = !0;
                                            else
                                                for (var Z = 0, I = (C = this.workingHours(g.days[w])).length; Z < I; Z++) {
                                                    var O = C[Z],
                                                        M = parseInt(O[0], 10),
                                                        R = parseInt(O[1], 10),
                                                        A = y.clone().startOf("day").add(M, "s"),
                                                        T = y.clone().startOf("day").add(R, "s");
                                                    if (y.isAfter(A) && y.isBefore(T)) {
                                                        E = !1, c && (u = T.diff(y));
                                                        break
                                                    }
                                                }
                                    } else E = !1;
                                else E = !1;
                                var S = {
                                    operatingHoursId: g.operatingHoursId,
                                    awayMessage: E ? g.awayMessage : "",
                                    defaultBhr: g.defaultBhr,
                                    enabled: g.enabled
                                };
                                null === (f = this.hotline) || void 0 === f || null === (p = f.ui) || void 0 === p || p.awayMessage.push(S)
                            }
                            c && (null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || !o.triggerTimerForBusinessHours) && u && u > 0 && (Ember.set(null === (r = this.hotline) || void 0 === r ? void 0 : r.ui, "triggerTimerForBusinessHours", !0), this.logger.log("Countdown timer to show Business Closed banner after end of Business hours has begun. Duration: ".concat(u, " milliseconds")), Ember.run.later(function() {
                                var e, t;
                                (0, P.Z)(this, s), Ember.set(null === (e = this.hotline) || void 0 === e ? void 0 : e.ui, "showBusinessClosedBanner", !0), Ember.set(null === (t = this.hotline) || void 0 === t ? void 0 : t.ui, "triggerTimerForBusinessHours", V.default.messengerVisibilityOptions.businessHours), this.logger.log("Countdown timer to show Business Closed banner has completed. Duration: ".concat(u, " milliseconds"))
                            }.bind(this), u))
                        }
                    }, {
                        key: "workingHours",
                        value: function(e) {
                            var t = this;
                            return e.substr(0, e.length - 1).split(";").reduce(function(e, n, i) {
                                (0, P.Z)(this, t);
                                var o = Math.floor(i / 2);
                                return e[o] = [].concat(e[o] || [], n), e
                            }.bind(this), [])
                        }
                    }, {
                        key: "onAdvicePullCB",
                        get: function() {
                            return this.onAdvicePull.bind(this)
                        }
                    }, {
                        key: "onUserMessageCB",
                        get: function() {
                            return this.onUserMessage.bind(this)
                        }
                    }, {
                        key: "onCampaignMessageCB",
                        get: function() {
                            return this.onCampaignMessage.bind(this)
                        }
                    }, {
                        key: "onCampaignMessage",
                        value: function(e, t, n) {
                            var i, o, r = this,
                                s = null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o ? void 0 : o.userBehaviour.eventRules;
                            (s = s.find(function(t) {
                                return (0, P.Z)(this, r), t.ruleId === e.campaignId
                            }.bind(this))).command.delay = e.timeOnCurrentPage ? (0, W.convertOperand)("NUMBER", e.timeOnCurrentPage) : 0, s.command.ruleId = e.campaignId, this.commandHelper.execute([s])
                        }
                    }, {
                        key: "disconnectSocket",
                        value: function() {
                            var e, t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                            !this.rts.connection || this.rts.connecting || this.rts.reconnecting || (Ember.removeListener(this.rts, "didUserMessage", this.onUserMessageCB), null !== (e = this.ruleEngine) && void 0 !== e && e.isFMJourneyEnabled && Ember.removeListener(this.rts, "didCampaignMessage", this.onCampaignMessageCB), Ember.removeListener(this.rts, "didAdvicePull", this.onAdvicePullCB), t && this.rts.connection.unsubscribeAll(), this.rts.close())
                        }
                    }, {
                        key: "connectSocket",
                        value: function() {
                            var e, t, n, i, o, r, s = this;
                            this.rts.connection || this.rts.connecting || this.rts.reconnecting || null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t || !t.id ? this.rts.connection && this.rts.didDisconnect && !this.rts.connecting && !this.rts.reconnecting && null !== (n = this.session) && void 0 !== n && null !== (i = n.user) && void 0 !== i && i.id && (this.rts.close(), this.rts.create()) : (Ember.addListener(this.rts, "didUserMessage", this.onUserMessageCB), Ember.addListener(this.rts, "didAdvicePull", this.onAdvicePullCB), null !== (r = this.ruleEngine) && void 0 !== r && r.isFMJourneyEnabled && this.rts.close(), this.rts.create());
                            if (null !== (o = this.ruleEngine) && void 0 !== o && o.isCampaignHistoryRequired) {
                                var l, a, u = V.default.EmberModelUrl.campaignHistory,
                                    c = u.url.replace("{token}", null === (l = this.session) || void 0 === l ? void 0 : l.token).replace("{userAlias}", null === (a = this.session) || void 0 === a ? void 0 : a.omniCookie);
                                this.store.getRequest(u.model, c).then(function(e) {
                                    var t = this;
                                    (0, P.Z)(this, s);
                                    var n = null == e ? void 0 : e.campaignIds;
                                    if (null != n && n.length) {
                                        var i, o, r, l = null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || null === (r = o.userBehaviour) || void 0 === r ? void 0 : r.eventRules,
                                            a = n.map(function(e) {
                                                var n = this;
                                                (0, P.Z)(this, t);
                                                var i = l.find(function(t) {
                                                    return (0, P.Z)(this, n), t.ruleId === e
                                                }.bind(this));
                                                return i.command.ruleId = e, se({}, i)
                                            }.bind(this));
                                        this.commandHelper.execute(a)
                                    }
                                }.bind(this))
                            }
                        }
                    }, {
                        key: "sessionUserObserver",
                        value: function() {
                            var e, t;
                            null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.id ? this.connectSocket() : this.disconnectSocket()
                        }
                    }, {
                        key: "resetMessageStacker",
                        value: function() {
                            var e, t = null === (e = this.hotline) || void 0 === e ? void 0 : e.ui,
                                n = this.messageStacker;
                            null != n && n.hasMessages && (this.postMessage.post({
                                action: "notify_frame",
                                data: "close"
                            }), n.resetLastAgentMessages(), Ember.setProperties(t, {
                                lockAgentMessage: void 0
                            }))
                        }
                    }, {
                        key: "onUserMessage",
                        value: function(e, t, n) {
                            var i, o, r, s = this,
                                l = null === (i = this.hotline) || void 0 === i ? void 0 : i.ui,
                                a = this.messageStacker,
                                u = this.session,
                                c = u && u.config,
                                d = c && c.agent,
                                h = d && d.hideName,
                                f = u && u.appDisplayName || u.appName,
                                p = this.store,
                                g = this.localds,
                                m = g.get("seq"),
                                v = this.conversations,
                                b = this.displayChannels,
                                y = e && e.type,
                                w = e && (null === (o = e.conversation) || void 0 === o ? void 0 : o.conversationReferenceId),
                                E = e && e.conversation,
                                C = E && E.messages && E.messages.length && E.messages[0];
                            if (e.userRules || this.send("ackMessageInRTS", C, t), this.isJWTStrictMode) {
                                if (this.jwt.auth.expiredAt || this.jwt.auth.scheduled || this.jwt.auth.expired) return void this.disconnectSocket(!1);
                                if (this.isJwtExpired()) return this.disconnectSocket(!1), void this.initiateSendingMode()
                            }
                            if (e.userRules) {
                                var Z = e.userRules.filter(function(e) {
                                    return (0, P.Z)(this, s), !(l.prevExecutedRuleIds.length > 0 && l.prevExecutedRuleIds.includes(e.ruleId))
                                }.bind(this));
                                Z.length > 0 && Z.forEach(function(e) {
                                    (0, P.Z)(this, s), e.command.delay = 0, e.command.ruleId = e.ruleId
                                }.bind(this)), Z.length > 0 && this.commandHelper.execute(Z)
                            } else {
                                var I, O, M, R, A = E && E.channelId,
                                    T = (0, W.findObjectByValueProperty)(b, A, "channelId"),
                                    S = null === (I = this.hotline) || void 0 === I || null === (O = I.ui) || void 0 === O ? void 0 : O.conversationReferenceId;
                                if (S) {
                                    var _ = v.filter(function(e) {
                                        return (0, P.Z)(this, s), e.conversationReferenceId === E.conversationReferenceId
                                    }.bind(this));
                                    M = 0 !== (null == _ ? void 0 : _.length) ? _.findBy("channelId", A) : void 0
                                } else if (this.isParallelConversationEnabled) {
                                    var k = v.find(function(e) {
                                        return (0, P.Z)(this, s), e.channelId === A && (!e.conversationId || -1 === e.conversationId)
                                    }.bind(this));
                                    M = k || v.findBy("conversationId", E.conversationId)
                                } else M = v.findBy("conversationId", E.conversationId);
                                if (C && C.messageType === V.default.CONVERSATION.MESSAGE_TYPE.SCREEN_SHARING.ENDED && window.parent && this.postMessage.post({
                                        event_id: "cobrowsingStop"
                                    }), "MESSAGE_RECEIVED" === y)
                                    if (R = (C && C.messageUserType) === V.default.CONVERSATION.USER_TYPE.USER ? "message_from_user" : "message_from_agent", this.rts.checkForSubscription(), C) {
                                        var H = C.messageUserName;
                                        V.default.CONVERSATION.MESSAGE_TYPE.BOT !== C.messageType && V.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT !== C.messageType && (H = h || !H ? f : H.split(" ")[0]), this.postMessage.post({
                                            action: R,
                                            data: {
                                                message: se(se({}, w && {
                                                    conversationReferenceId: w
                                                }), {}, {
                                                    messageFragments: C.messageFragments,
                                                    messageUserName: H,
                                                    appName: f,
                                                    createdMillis: C.createdMillis,
                                                    channelId: A,
                                                    conversationId: E.conversationId,
                                                    stepId: C.flowStepId,
                                                    conversationAlias: C.conversationAlias
                                                })
                                            }
                                        })
                                    }
                                if (1 === n || 0 === m.id || n === m.id + 1) {
                                    if ("MESSAGE_RECEIVED" === y || "COBOROWSING_STATUS_UPDATED" === y) {
                                        if (E) {
                                            var N, L, B, j, D, U, F, x, q = C && C.messageId,
                                                z = C && C.marketingId,
                                                G = C && C.msgHopId,
                                                Q = C && C.messageUserType,
                                                K = M && M.get("messages"),
                                                Y = this.notification;
                                            if (-1 !== ae.indexOf(C.messageType) && (0, W.resizeImage)(C), A && Ember.set(C, "channelId", A), w ? (Ember.set(C, "conversationReferenceId", w), Ember.set(l, "receivedMsgRefId", w)) : Ember.set(l, "receivedMsgRefId", void 0), Ember.set(C, "delivered", !0), K) {
                                                B = q && K.findBy("messageId", q) || z && K.findBy("marketingId", z) || G && K.findBy("msgHopId", G), C && C.flowStepId && 0 !== C.messageUserType && (x = (0, W.updateAndGetLastFlowMessage)(K, C)), C && C.ruleId && 0 !== C.messageUserType && (j = (0, W.updateAndGetLastAutoMessage)(K, C)), C && C.source === V.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE && (D = (F = (U = K.filter(function(e) {
                                                    return (0, P.Z)(this, s), e.get("source") === V.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE && e.get("needsUpdation")
                                                }.bind(this))) && U.length) ? U[F - 1] : null);
                                                var J = K.filterBy("offlineMessage", !0).filterBy("hasBeenRepliedToOffline", !1);
                                                if ((C && C.messageUserType === V.default.CONVERSATION.USER_TYPE.AGENT && J.length || C.internalMeta) && J.length && J[J.length - 1].set("hasBeenRepliedToOffline", !0), B && G && B.get("msgHopId") && q && B.get("messageId") && B.get("msgHopId") === G && B.get("messageId") !== q && (B = null), B) "COBOROWSING_STATUS_UPDATED" === y ? B.set("messageType", C.messageType) : p.cloneRecord(B, C), this.logger.log("Updating Message");
                                                else if (j) Ember.set(j, "messageUserAlias", C.messageUserAlias), (0, W.checkAndUpdateReadMillis)(j.get("createdMillis"), C.createdMillis, M), p.cloneRecord(j, C), this.logger.log("Updated automessage via Websockets");
                                                else if (x) Ember.set(x, "messageUserAlias", C.messageUserAlias), (0, W.checkAndUpdateReadMillis)(x.get("createdMillis"), C.createdMillis, M), p.cloneRecord(x, C), this.logger.log("Updated flowmessage via Websockets");
                                                else if (D) {
                                                    Ember.set(D, "messageUserAlias", C.messageUserAlias), p.cloneRecord(D, C), D.set("needsUpdation", !1);
                                                    for (var X = 0; X < F - 1; X++) U[X].set("needsUpdation", !1);
                                                    this.logger.log("Updated offlineMessage via Websockets")
                                                } else {
                                                    var $ = p.createRecord("message", C),
                                                        ee = K.lastObject;
                                                    if (K.firstObject && K.firstObject.messageId && K.firstObject.createdMillis > C.createdMillis) K.unshiftObjects([$]);
                                                    else if (ee && ee.messageId) {
                                                        for (var te = K.length - 1; te >= 0; te--) {
                                                            if (K.objectAt(te).createdMillis < C.createdMillis) {
                                                                K.insertAt(te + 1, $);
                                                                break
                                                            }
                                                        }
                                                        te < 0 && K.pushObject($)
                                                    } else K.pushObject($);
                                                    this.smartPolling.clearSmartPoll(), this.smartPolling.setMessageAfterMillis("agent-message", C.createdMillis), this.logger.log("Adding Message"), C && C.messageUserType === V.default.CONVERSATION.USER_TYPE.USER && this.postMessage.post({
                                                        action: "notify_frame",
                                                        data: "close"
                                                    })
                                                }
                                            } else {
                                                var ne, ie = Ember.A([]);
                                                if (ie.pushObject(p.createRecord("message", C)), ne = p.createRecord("conversation", {
                                                        conversationId: E.conversationId,
                                                        channelId: E.channelId,
                                                        messages: ie,
                                                        updatedMillis: E.updatedMillis,
                                                        conversationReferenceId: E.conversationReferenceId || S
                                                    }), v) v.pushObject(ne);
                                                else {
                                                    var oe = Ember.A([]);
                                                    oe.pushObject(ne), g.set("conversations", oe)
                                                }
                                            }
                                            r = C.createdMillis, g.set("messageAfter", r), this.send("save", T && !B), T && (Q && !C.ruleId ? (a.isSameAsLastAgentChannelId(C.channelId) ? Ember.setProperties(l, {
                                                lockAgentMessage: !0
                                            }) : l.lockAgentMessage || Ember.setProperties(l, {
                                                lockAgentMessage: void 0
                                            }), a.setLastAgentMessage(C), Ember.run.later(function() {
                                                var e;
                                                if ((0, P.Z)(this, s), S === (null === (e = M) || void 0 === e ? void 0 : e.conversationReferenceId) || !S) {
                                                    var t = C && C.messageFragments;
                                                    "" !== (t && t.length && t[0].content) && Y.playSound()
                                                }
                                            }.bind(this), 0)) : l.lockAgentMessage || (Ember.setProperties(l, {
                                                lockAgentMessage: void 0
                                            }), a.resetLastAgentMessages())), null === (N = M) || void 0 === N || N.set("status", E.status), null === (L = M) || void 0 === L || L.set("updatedMillis", E.updatedMillis)
                                        }
                                    } else "CONVERSATION_RESOLVED" === y ? (this.smartPolling.clearSmartPoll(), E.hasPendingCsat && (M.set("csat", p.createRecord("csat", E.csat)), M.set("hasPendingCsat", E.hasPendingCsat)), M.set("status", E.status), this.send("save"), this.send("publishConversationResolved", E), this.resetMessageStacker()) : "CSAT_RESPONSE_RECEIVED" === y ? (this.smartPolling.clearSmartPoll(), M.get("csat") && (Ember.set(M, "hasPendingCsat", !1), Ember.set(M, "status", null == E ? void 0 : E.status), this.send("save"))) : "GDPR_USER_DELETED" === y && (this.user.delete(), this.send("reset", null, !0));
                                    g.set("seq", {
                                        id: n,
                                        millis: r
                                    }), this.send("save")
                                } else this.populateConversation(V.default.CONVERSATION.FETCH.RTS_SEQ_ID_MISMATCH, null, m.millis)
                            }
                        }
                    }, {
                        key: "onAdvicePull",
                        value: function(e) {
                            var t = e && e.src,
                                n = this.router.currentRouteName,
                                i = n && "home.faqs" !== n;
                            this.populateConversation(t, e.channel && i ? this.openChannel : null, e && e.reset ? 0 : null)
                        }
                    }, {
                        key: "openChannel",
                        value: function() {
                            var e, t, n = this.displayChannels,
                                i = n && n.length,
                                o = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t ? void 0 : t.openChannelId;
                            if (i && 1 === i && !this.isFAQAvailable) this.transition.abort();
                            else if (o) {
                                var r = n.findBy("channelId", o);
                                r && r.channelId && this.replaceWith("home.channel", r.channelId, {
                                    queryParams: {
                                        conversationId: r.conversationId
                                    }
                                })
                            }
                        }
                    }, {
                        key: "populateConversation",
                        value: function() {
                            var e, t, n, i, o, r = this,
                                s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                                l = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                                a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                                u = V.default.EmberModelUrl,
                                c = u.conversations,
                                d = this.session,
                                h = d && d.user,
                                f = c.url.replace("{token}", d.token).replace("{userAlias}", h.alias),
                                p = d && d.siteId,
                                g = null !== a ? a : d && d.didMessage,
                                m = s ? {
                                    src: s
                                } : {
                                    src: V.default.CONVERSATION.FETCH.DEFAULT
                                };
                            (m = se(se({}, m), {}, {
                                limit: V.default.CONVERSATION.LIMIT
                            }), 0 !== (null === (e = this.smartPolling.messageAfterMillis) || void 0 === e ? void 0 : e.length)) ? m.messageAfter = null === (o = this.smartPolling.messageAfterMillis[0]) || void 0 === o ? void 0 : o.createdMillis: g && (m.messageAfter = g);
                            d.userCreated && (m.messageAfter = void 0), m.hideResolvedConversation = (0, oe.isHideResolvedConversationEnabled)(null === (t = this.hotlineUI) || void 0 === t ? void 0 : t.config);
                            var v = null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.conversationReferenceId;
                            if (v && (m.conversationReferenceId = v), this.isParallelFeatureEnabled) {
                                delete m.limit;
                                var b = this.session.currentPage;
                                this.conversations.length === V.default.CONVERSATION.PAGE_COUNT && this.displayHistoryConversations.length < V.default.CONVERSATION.PAGE_COUNT && (b += 1, delete m.messageAfter), m.page = b || 1, m.conversationsPerPage = V.default.CONVERSATION.PAGE_COUNT, m.isParallelConversation = !0
                            }
                            p && (f += "?siteId=".concat(p)), this.store.getRequest(c.model, f, m).then(function(e) {
                                var t, n = this;
                                (0, P.Z)(this, r);
                                var i = e && e.errorCode,
                                    o = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                                if (o && o.helpNote && Ember.set(o, "helpNote", void 0), e && e.conversations && !i) {
                                    var s = this.conversations,
                                        u = [];
                                    if (0 === a && s) {
                                        s.forEach(function(e) {
                                            var t = this;
                                            (0, P.Z)(this, n);
                                            var i = [];
                                            if (e.get("messages").forEach(function(e) {
                                                    (0, P.Z)(this, t), 0 === e.get("messageUserType") && e.get("status") === V.default.MESSAGE_STATUS.PENDING && i.push(e)
                                                }.bind(this)), i.length) {
                                                var o = e.serialize();
                                                e.messages = i, u.push(o)
                                            }
                                        }.bind(this));
                                        var c = e && e.conversations;
                                        c && c.forEach(function(e) {
                                            (0, P.Z)(this, n);
                                            var t = s.findBy("channelId", e.channelId);
                                            s.removeObject(t)
                                        }.bind(this)), this.send("save", !1)
                                    }
                                    this.loadConversation(e.conversations || []), this.loadConversation(u), Ember.set(this.session, "userCreated", !1), Ember.set(this.session, "isUserClearedAcrossTab", !1)
                                } else;
                                l && l.call(this)
                            }.bind(this))
                        }
                    }, {
                        key: "restoreConversation",
                        value: function() {
                            this.populateConversation(V.default.CONVERSATION.FETCH.CONVERSATION_RESTORED, this.openChannel)
                        }
                    }, {
                        key: "gotoFAQArticle",
                        value: function(e, t, n) {
                            var i, o = null === (i = this.hotline) || void 0 === i ? void 0 : i.ui;
                            Ember.set(o, "modal", e), this.transitionTo(this.faqRouteName, {
                                queryParams: {
                                    fromChannelId: t,
                                    fromConversationId: n
                                }
                            })
                        }
                    }, {
                        key: "gotoFAQArticles",
                        value: function(e) {
                            this.transitionTo(this.faqRouteName, {
                                queryParams: {
                                    categoryID: e
                                }
                            })
                        }
                    }, {
                        key: "gotoFAQCategory",
                        value: function() {
                            this.transitionTo(this.faqRouteName)
                        }
                    }, {
                        key: "gotoHistoryView",
                        value: function(e) {
                            this.transitionTo("home.all-conversations", {
                                queryParams: {
                                    fromPage: e
                                }
                            })
                        }
                    }, {
                        key: "retryCallbackOnRateLimitedUrl",
                        value: function() {
                            var e, t, n, i, o;
                            if (null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isKbaseCategoryRateLimited) Ember.set(null === (o = this.hotline) || void 0 === o ? void 0 : o.ui, "retryingRateLimitedUrl", !0), this.fetchKbaseCategories();
                            else if (null !== (n = this.hotline) && void 0 !== n && null !== (i = n.ui) && void 0 !== i && i.rateLimitedCategoryArticles) {
                                var r, s, l;
                                Ember.set(null === (r = this.hotline) || void 0 === r ? void 0 : r.ui, "retryingRateLimitedUrl", !0), this.send("gotoFAQArticles", null === (s = this.hotline) || void 0 === s || null === (l = s.ui) || void 0 === l ? void 0 : l.rateLimitedCategoryArticles)
                            }
                        }
                    }]), n
                }(q.default.extend(z.default, G.default, K.default, Q.default, Y.default, ne.default, te.default, ie.default)), I = (0, F.Z)(Z.prototype, "ruleEngine", [i], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), O = (0, F.Z)(Z.prototype, "notification", [o], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), M = (0, F.Z)(Z.prototype, "messageStacker", [r], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), R = (0, F.Z)(Z.prototype, "postMessage", [s], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), A = (0, F.Z)(Z.prototype, "user", [l], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), T = (0, F.Z)(Z.prototype, "smartPolling", [a], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), S = (0, F.Z)(Z.prototype, "windowListener", [u], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), (0, F.Z)(Z.prototype, "didAuthUserCB", [c], Object.getOwnPropertyDescriptor(Z.prototype, "didAuthUserCB"), Z.prototype), (0, F.Z)(Z.prototype, "faqRouteName", [d], Object.getOwnPropertyDescriptor(Z.prototype, "faqRouteName"), Z.prototype), (0, F.Z)(Z.prototype, "helper", [h], Object.getOwnPropertyDescriptor(Z.prototype, "helper"), Z.prototype), (0, F.Z)(Z.prototype, "onAdvicePullCB", [f], Object.getOwnPropertyDescriptor(Z.prototype, "onAdvicePullCB"), Z.prototype), (0, F.Z)(Z.prototype, "onUserMessageCB", [p], Object.getOwnPropertyDescriptor(Z.prototype, "onUserMessageCB"), Z.prototype), (0, F.Z)(Z.prototype, "onCampaignMessageCB", [g], Object.getOwnPropertyDescriptor(Z.prototype, "onCampaignMessageCB"), Z.prototype), (0, F.Z)(Z.prototype, "sessionUserObserver", [m], Object.getOwnPropertyDescriptor(Z.prototype, "sessionUserObserver"), Z.prototype), (0, F.Z)(Z.prototype, "restoreConversation", [v], Object.getOwnPropertyDescriptor(Z.prototype, "restoreConversation"), Z.prototype), (0, F.Z)(Z.prototype, "gotoFAQArticle", [b], Object.getOwnPropertyDescriptor(Z.prototype, "gotoFAQArticle"), Z.prototype), (0, F.Z)(Z.prototype, "gotoFAQArticles", [y], Object.getOwnPropertyDescriptor(Z.prototype, "gotoFAQArticles"), Z.prototype), (0, F.Z)(Z.prototype, "gotoFAQCategory", [w], Object.getOwnPropertyDescriptor(Z.prototype, "gotoFAQCategory"), Z.prototype), (0, F.Z)(Z.prototype, "gotoHistoryView", [E], Object.getOwnPropertyDescriptor(Z.prototype, "gotoHistoryView"), Z.prototype), (0, F.Z)(Z.prototype, "retryCallbackOnRateLimitedUrl", [C], Object.getOwnPropertyDescriptor(Z.prototype, "retryCallbackOnRateLimitedUrl"), Z.prototype), Z)
        },
        99387: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return g
                }
            });
            var i, o, r = n(34645),
                s = n(5660),
                l = n(58678),
                a = n(55411),
                u = n(79833),
                c = n(13256),
                d = n(87643),
                h = n(22126),
                f = n(75920);

            function p(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, a.Z)(this, n)
                }
            }
            var g = (i = Ember._action, o = function(e) {
                (0, l.Z)(n, e);
                var t = p(n);

                function n() {
                    return (0, r.Z)(this, n), t.apply(this, arguments)
                }
                return (0, s.Z)(n, [{
                    key: "beforeModel",
                    value: function(e) {
                        this.set("params", e.to.queryParams)
                    }
                }, {
                    key: "model",
                    value: function() {
                        return {
                            fromPage: this.params.fromPage
                        }
                    }
                }, {
                    key: "handleRoute",
                    value: function(e) {
                        this.transitionTo(e)
                    }
                }]), n
            }(d.default.extend(f.default, h.default)), (0, c.Z)(o.prototype, "handleRoute", [i], Object.getOwnPropertyDescriptor(o.prototype, "handleRoute"), o.prototype), o)
        },
        16672: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return p
                }
            });
            var i, o, r = n(34645),
                s = n(5660),
                l = n(58678),
                a = n(55411),
                u = n(79833),
                c = n(13256),
                d = n(87643),
                h = n(22126);

            function f(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, a.Z)(this, n)
                }
            }
            var p = (i = Ember._action, o = function(e) {
                (0, l.Z)(n, e);
                var t = f(n);

                function n() {
                    return (0, r.Z)(this, n), t.apply(this, arguments)
                }
                return (0, s.Z)(n, [{
                    key: "gotoHome",
                    value: function() {
                        this.replaceWith("home")
                    }
                }]), n
            }(d.default.extend(h.default)), (0, c.Z)(o.prototype, "gotoHome", [i], Object.getOwnPropertyDescriptor(o.prototype, "gotoHome"), o.prototype), o)
        },
        99531: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return p
                }
            });
            var i, o, r = n(34645),
                s = n(5660),
                l = n(58678),
                a = n(55411),
                u = n(79833),
                c = n(13256),
                d = n(87643),
                h = n(22126);

            function f(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, a.Z)(this, n)
                }
            }
            var p = (i = Ember._action, o = function(e) {
                (0, l.Z)(n, e);
                var t = f(n);

                function n() {
                    return (0, r.Z)(this, n), t.apply(this, arguments)
                }
                return (0, s.Z)(n, [{
                    key: "gotoHome",
                    value: function() {
                        this.replaceWith("home")
                    }
                }]), n
            }(d.default.extend(h.default)), (0, c.Z)(o.prototype, "gotoHome", [i], Object.getOwnPropertyDescriptor(o.prototype, "gotoHome"), o.prototype), o)
        },
        18711: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = p(n(83973)),
                o = p(n(26207)),
                r = p(n(51996)),
                s = p(n(98661)),
                l = p(n(12688)),
                a = p(n(15112)),
                u = p(n(44587)),
                c = p(n(56407)),
                d = p(n(19390)),
                h = p(n(72847)),
                f = p(n(66171));

            function p(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return o.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return r.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/component", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/component", (function() {
                return c.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return d.default
            })), window.define("hotline-web/helpers/format-time", (function() {
                return h.default
            })), window.define("hotline-web/helpers/gt", (function() {
                return f.default
            }));
            var g = (0, Ember.HTMLBars.template)({
                id: "VFNLCyPE",
                block: '[[[8,[39,0],[[24,0,"channel-link"]],[["@route","@model","@query","@replace"],["home.channel",[30,0,["channel","channelId"]],[28,[37,1],null,[["isRoutedFromHistory","fromPage","isStartNew","conversationId"],[[30,0,["isHistoryView"]],[30,0,["fromPage"]],[30,0,["isStartNew"]],[30,0,["channel","conversationId"]]]]],true]],[["default"],[[[[1,"\\n  "],[10,0],[14,0,"h-category-item"],[12],[1,"\\n    "],[10,0],[14,0,"h-category-icon"],[12],[1,"\\n"],[41,[30,0,["channel","iconUrl"]],[[[1,"        "],[10,"img"],[14,0,"img-circle avatar-image"],[15,"src",[30,0,["channel","iconUrl"]]],[15,"alt",[28,[37,3],["alt.channel_icon"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"        "],[10,1],[15,0,[29,["category-content-wrap ",[28,[37,4],[[30,0,["channel","name"]]],null]]]],[12],[1,"\\n          "],[10,1],[14,0,"category-content"],[12],[1,"\\n            "],[1,[28,[35,5],[[30,0,["channel","name"]]],null]],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]]],[1,"    "],[13],[1,"\\n   "],[10,0],[15,0,[29,["channel-names ",[52,[30,0,["isIPhone"]],"iPhone-channel-names"]]]],[12],[1,"\\n      "],[10,0],[14,0,"channel-content"],[12],[1,"\\n        "],[10,0],[15,0,[29,["h-category-detail ",[52,[30,0,["lastMessage"]],"aw"]]]],[12],[1,"\\n          "],[10,"h2"],[15,0,[29,["channel-name ",[52,[30,0,["isIPhone"]],"iPhone-h2"]," ",[30,0,["unReadParallelConversation"]]]]],[12],[1,"\\n            "],[1,[28,[35,6],[[30,0,["channel","name"]],"strict"],null]],[1,"\\n          "],[13],[1,"\\n"],[41,[30,0,["isStartNew"]],[[[1,"           "],[10,0],[15,0,[29,["welcome-text ",[52,[30,0,["unreadCount"]],"unreadMessage"]," ",[52,[30,0,["isIPhone"]],"iPhone-h2"]]]],[12],[1,"\\n             "],[10,0],[15,0,[29,["message-text ",[52,[30,0,["isIPhone"]]," iPhone-text-message"]]]],[12],[1,"\\n                "],[10,0],[15,0,[29,["last-msg-preview ",[52,[30,0,["isIPhone"]],"iPhone-text-message"]]]],[12],[1,"\\n                  "],[8,[39,7],null,[["@message","@isListView"],[[30,0,["channel","welcomeMessage"]],true]],null],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[1,"            "],[10,0],[15,0,[29,["welcome-text ",[52,[30,0,["unreadCount"]],"unreadMessage"]]]],[12],[1,"\\n"],[41,[30,0,["enabledAgentTypingIndicator"]],[[[1,"                "],[8,[39,8],null,[["@channelId"],[[30,0,["channel","channelId"]]]],null],[1,"\\n"]],[]],null],[1,"              "],[10,0],[14,0,"message-text"],[12],[1,"\\n"],[41,[30,0,["isNonWelcomeMessage"]],[[[41,[28,[37,9],[[30,0,["USER"]],[30,0,["lastMessage","messageUserType"]]],null],[[[1,"                    "],[10,"i"],[14,0,"icon-ic_reply"],[12],[13],[1,"\\n"]],[]],null],[1,"                  "],[10,0],[15,0,[29,["last-msg-preview ",[52,[30,0,["isIPhone"]],"iPhone-text-message"]]]],[12],[1,"\\n                    "],[8,[39,7],null,[["@message","@isListView"],[[30,0,["lastMessage"]],true]],null],[1,"\\n                  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["channel","welcomeMessage","messageFragments","length"]],[[[1,"                 "],[10,0],[15,0,[29,["last-msg-preview ",[52,[30,0,["isIPhone"]],"iPhone-text-message"]]]],[12],[1,"\\n                    "],[8,[39,7],null,[["@message","@isListView"],[[30,0,["channel","welcomeMessage"]],true]],null],[1,"\\n                  "],[13],[1,"\\n                "]],[]],null]],[]]],[1,"              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n"],[41,[51,[30,0,["isStartNew"]]],[[[1,"          "],[10,0],[14,0,"h-conv-user"],[12],[1,"\\n"],[41,[30,0,["lastMessage"]],[[[1,"              "],[10,0],[14,0,"time-stamp"],[12],[1,"\\n                "],[1,[28,[35,11],[[30,0,["lastMessage","createdMillis"]],"LT"],null]],[1,"\\n              "],[13],[1,"\\n"],[41,[30,0,["unreadCount"]],[[[1,"                "],[10,0],[15,0,[29,["h-notify ",[52,[28,[37,12],[[30,0,["unreadCount"]],9],null],"large-count"]]]],[15,"aria-label",[30,0,["getAriaLabel"]]],[12],[1,"\\n                  "],[10,1],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[28,[37,12],[[30,0,["unreadCount"]],9],null],[[[1,"                      "],[1,[28,[35,3],["common.numbers.nine"],null]],[1,"+\\n"]],[]],[[[1,"                      "],[1,[30,0,["unreadCount"]]],[1,"\\n"]],[]]],[1,"                  "],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"          "],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]]]]]],[],false,["link-to","hash","if","t","choose-theme","avatar-content","sanitize-html","ui-unity-message-fragment","ui-agent-typing-indicator","eq","unless","format-time","gt"]]',
                moduleName: "hotline-web/components/app-channel/template.hbs",
                isStrictMode: !1
            });
            t.default = g
        },
        8838: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = h(n(83973)),
                o = h(n(18711)),
                r = h(n(52718)),
                s = h(n(70234)),
                l = h(n(48692)),
                a = h(n(12076)),
                u = h(n(53812)),
                c = h(n(66171)),
                d = h(n(92945));

            function h(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/app-channel/template", (function() {
                return o.default
            })), window.define("hotline-web/components/app-channel/component", (function() {
                return r.default
            })), window.define("hotline-web/components/app-loader/template", (function() {
                return s.default
            })), window.define("hotline-web/helpers/and", (function() {
                return l.default
            })), window.define("hotline-web/helpers/not", (function() {
                return a.default
            })), window.define("hotline-web/helpers/lte", (function() {
                return u.default
            })), window.define("hotline-web/helpers/gt", (function() {
                return c.default
            })), window.define("hotline-web/helpers/or", (function() {
                return d.default
            }));
            var f = (0, Ember.HTMLBars.template)({
                id: "/EWd+KeY",
                block: '[[[10,0],[14,0,"channel-section animated fadeInUp delay faster h-categories"],[12],[1,"\\n  "],[10,0],[14,0,"channel-title"],[12],[1,"\\n    "],[10,0],[14,0,"list-sub-title"],[14,"role","heading"],[14,"aria-level","1"],[12],[1,"\\n      "],[1,[30,0,["headerTitle"]]],[1,"\\n    "],[13],[1,"\\n"],[41,[30,0,["isShowHistoryIcon"]],[[[1,"      "],[11,0],[24,0,"view-history"],[24,"role","heading"],[24,"aria-level","1"],[4,[38,1],[[30,0],"showViewHistory"],null],[12],[1,"\\n        "],[1,[28,[35,2],["channel.see_all_chats"],null]],[1," "],[10,0],[14,0,"arrow-icon"],[12],[10,"i"],[14,0,"icon icon-chevron_right_regular"],[12],[13],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"  "],[13],[1,"\\n"],[41,[30,0,["isStartNew"]],[[[1,"      "],[10,"ul"],[14,0,"channel-list start-new"],[12],[1,"\\n"],[42,[28,[37,4],[[28,[37,4],[[30,0,["displayAllChannels"]]],null]],null],null,[[[1,"            "],[10,"li"],[12],[1,"\\n              "],[8,[39,5],null,[["@channel","@update","@isStartNew"],[[30,1],[30,0,["session","didMessage"]],true]],null],[1,"\\n              "],[10,0],[14,0,"border-bottom"],[12],[1,[30,1,["conversationId"]]],[13],[1,"\\n            "],[13],[1,"\\n"]],[1]],null],[1,"      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["isShowHistoryLoadingIcon"]],[[[1,"      "],[10,0],[14,0,"history-conversation-loading"],[12],[1,"\\n        "],[10,"img"],[15,"src",[30,0,["images","LoadingIcon"]]],[14,0,"loading"],[15,"alt",[28,[37,2],["alt.loading_icon"],null]],[12],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["isHistoryView"]],[[[1,"      "],[10,"ul"],[14,0,"channel-list history-view-scroll"],[12],[1,"\\n"],[42,[28,[37,4],[[28,[37,4],[[30,0,["displayHistoryConversations"]]],null]],null],null,[[[1,"          "],[10,"li"],[15,"data-conversationId",[30,2,["conversationId"]]],[12],[1,"\\n            "],[8,[39,5],null,[["@channel","@update","@isHistoryView","@fromPage"],[[30,2],[30,0,["session","didMessage"]],true,[30,0,["fromPage"]]]],null],[1,"\\n            "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[2]],null],[41,[30,0,["isShowConversationLoadingIcon"]],[[[1,"          "],[10,"li"],[14,0,"app-loader-bottom"],[12],[1,"\\n            "],[8,[39,6],null,[["@isVertical","@label"],["true",[28,[37,2],["help_text.loading_older_conversations"],null]]],null],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["hasHistoryConversations"]],[[[1,"      "],[10,"ul"],[14,0,"channel-list"],[12],[1,"\\n"],[42,[28,[37,4],[[28,[37,4],[[30,0,["displayHistoryConversations"]]],null]],null],null,[[[41,[28,[37,7],[[28,[37,8],[[30,0,["isExpandAllTopics"]]],null],[28,[37,9],[[30,4],2],null]],null],[[[1,"            "],[10,"li"],[15,"data-conversationId",[30,3,["conversationId"]]],[12],[1,"\\n              "],[8,[39,5],null,[["@channel","@update"],[[30,3],[30,0,["session","didMessage"]]]],null],[1,"\\n              "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],null]],[3,4]],null],[1,"      "],[13],[1,"\\n"],[41,[28,[37,10],[[30,0,["displayHistoryConversations","length"]],3],null],[[[1,"        "],[11,0],[24,0,"see_more_topics"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"showViewHistory"],null],[12],[1,"\\n          "],[1,[28,[35,2],["channel.see_all_chats"],null]],[1,"\\n        "],[13],[1,"\\n"]],[]],null]],[]],[[[1,"      "],[10,"ul"],[14,0,"channel-list"],[12],[1,"\\n"],[42,[28,[37,4],[[28,[37,4],[[30,0,["displayChannels"]]],null]],null],null,[[[41,[28,[37,7],[[30,0,["isParallelConversation"]],[28,[37,9],[[30,6],2],null]],null],[[[1,"            "],[10,"li"],[12],[1,"\\n              "],[8,[39,5],null,[["@channel","@update"],[[30,5],[30,0,["session","didMessage"]]]],null],[1,"\\n              "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],null],[41,[28,[37,11],[[30,0,["isExpandAllTopics"]],[28,[37,8],[[30,0,["isParallelConversationEnabled"]]],null]],null],[[[1,"            "],[10,"li"],[12],[1,"\\n              "],[8,[39,5],null,[["@channel","@update"],[[30,5],[30,0,["session","didMessage"]]]],null],[1,"\\n              "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],null]],[5,6]],null],[1,"      "],[13],[1,"\\n"],[41,[28,[37,7],[[30,0,["isShowAllTopics"]],[30,0,["isParallelConversationEnabled"]]],null],[[[1,"        "],[11,0],[24,0,"see_more_topics"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"showAllTopics"],null],[12],[1,"\\n"],[41,[30,0,["isExpandAllTopics"]],[[[1,"            "],[1,[28,[35,2],["channel.show_less_topics"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[28,[35,2],["channel.show_all_topics"],null]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n"]],[]],null],[1,"    "]],[]]]],[]]]],[]]]],[]]],[13]],["channel","channel","channel","index","channel","index"],false,["if","action","t","each","-track-array","app-channel","app-loader","and","not","lte","gt","or"]]',
                moduleName: "hotline-web/components/app-channels-list/template.hbs",
                isStrictMode: !1
            });
            t.default = f
        },
        25808: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(98661)),
                o = a(n(83973)),
                r = a(n(26207)),
                s = a(n(51996)),
                l = a(n(19390));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/sanitize-html", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return r.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return s.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return l.default
            }));
            var u = (0, Ember.HTMLBars.template)({
                id: "HhC3ftYs",
                block: '[[[41,[30,0,["isCategoriesPresent"]],[[[1,"  "],[10,0],[15,0,[29,["faq-list animated fadeInUp delay faster ",[52,[30,0,["isShowMoreCategories"]],"show-more"]]]],[12],[1,"\\n    "],[10,0],[14,0,"faq-header"],[12],[1,"\\n      "],[10,0],[14,0,"title-header"],[12],[1,"\\n        "],[10,0],[14,0,"list-sub-title"],[14,"role","heading"],[14,"aria-level","1"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","faq"]],[[[1,"            "],[1,[28,[35,1],[[30,0,["session","config","content","headers","faq"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[30,0,["getFaqTitle"]]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n      "],[13],[1,"\\n      "],[11,0],[24,0,"search-category"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,2],["aria_labels.search_faq"],null]],[4,[38,3],[[30,0],"goToCategory"],null],[12],[1,"\\n        "],[10,"i"],[14,0,"icon-ic_search"],[12],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[10,0],[14,0,"faq-categories"],[12],[1,"\\n      "],[10,"ul"],[14,0,"categories-list"],[12],[1,"\\n"],[42,[28,[37,5],[[28,[37,5],[[30,0,["sliceCategories"]]],null]],null],null,[[[1,"          "],[11,"li"],[24,"tabindex","0"],[4,[38,3],[[30,0],"selectCategory",[30,1]],null],[12],[1,"\\n            "],[10,0],[14,0,"category-item"],[12],[1,"\\n              "],[10,0],[14,0,"category-icon"],[12],[1,"\\n"],[41,[30,1,["icon"]],[[[1,"                  "],[10,"img"],[15,"src",[30,1,["icon"]]],[14,0,"img-circle avatar-image"],[15,"alt",[28,[37,2],["alt.category_icon"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                  "],[10,1],[15,0,[29,["category-content-wrap ",[28,[37,6],[[30,1,["title"]]],null]]]],[12],[1,"\\n                    "],[1,[28,[35,7],[[30,1,["title"]]],null]],[1,"\\n                  "],[13],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n              "],[10,0],[14,0,"category-name"],[12],[1,"\\n                "],[10,0],[14,0,"faq-title"],[14,"role","heading"],[14,"aria-level","2"],[12],[1,"\\n                  "],[1,[28,[35,1],[[30,1,["title"]],"strict"],null]],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n\\n"],[41,[28,[37,8],[[30,0,["hotline","ui","lastSelectedCategoryId"]],[30,1,["categoryId"]]],null],[[[1,"                "],[10,"img"],[14,0,"faq-loader"],[15,"src",[30,0,["images","UploadingNew"]]],[15,"alt",[28,[37,2],["alt.loading_icon"],null]],[12],[13],[1,"\\n"]],[]],null],[1,"            "],[13],[1,"\\n            "],[10,0],[14,0,"border-bottom"],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[1,2]],null],[1,"      "],[13],[1,"\\n"],[41,[30,0,["isShowMoreCategories"]],[[[1,"        "],[11,0],[24,0,"see_more_faqs"],[24,"role","button"],[24,"tabindex","0"],[4,[38,3],[[30,0],"goToCategory"],null],[12],[1,"\\n          "],[1,[28,[35,2],["faqs.show_more_categories"],null]],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],["obj","index"],false,["if","sanitize-html","t","action","each","-track-array","choose-theme","avatar-content","eq"]]',
                moduleName: "hotline-web/components/app-faq-list/template.hbs",
                isStrictMode: !1
            });
            t.default = u
        },
        36818: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(83973)),
                o = s(n(8838)),
                r = s(n(71644));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/app-channels-list/template", (function() {
                return o.default
            })), window.define("hotline-web/components/app-channels-list/component", (function() {
                return r.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "sbnKXMdZ",
                block: '[[[10,0],[14,0,"h-conv"],[12],[1,"\\n  "],[10,0],[15,0,[52,[30,0,["isParallelConversationEnabled"]],"fc-conversation-view fc-all-conversation-view","fc-conversation-view fc-all-conversation-view disabled"]],[12],[1,"\\n    "],[10,0],[14,0,"h-header topics-header"],[12],[1,"\\n      "],[10,0],[15,0,[29,["title fadeIn ",[30,0,["headerStyle"]]]]],[12],[1,"\\n        "],[11,0],[24,0,"ic-back animated fadeIn faster"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.back"],null]],[4,[38,2],[[30,0],"gotoHome"],null],[12],[1,"\\n            "],[10,"i"],[14,0,"icon icon-ic_back"],[12],[13],[1,"\\n          "],[13],[1,"\\n        "],[10,0],[15,0,[29,["channel-info animated fadeIn faster ",[52,[30,0,["isConversationRefIdPresent"]],"no-back-button"]," ",[52,[30,0,["isCompact"]],"channel-info-compact-width","channel-info-width"]]]],[12],[1,"\\n          "],[10,"h1"],[14,0,"channel-title"],[12],[1,[28,[35,1],["channel.all_conversations"],null]],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[10,0],[14,0,"body"],[12],[1,"\\n      "],[8,[39,3],null,[["@isHistoryView","@fromPage"],[true,[30,0,["model","fromPage"]]]],null],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,"aria-live","assertive"],[14,0,"aria-live-region"],[12],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,0,["isParallelConversationEnabled"]],[[[1,"    "],[10,0],[14,0,"start-new-conversation"],[12],[1,"\\n      "],[11,"button"],[24,0,"h-img-button"],[24,4,"button"],[4,[38,2],[[30,0],"goToAllTopicsRoute"],null],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]],[[[1,"            "],[10,1],[14,0,"btn-content"],[12],[1,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]]],[1,"\\n          "],[13],[1,"\\n"]],[]],[[[1,"            "],[10,1],[14,0,"btn-content"],[12],[1,[28,[35,1],["channel.start_new_conversation"],null]],[13],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[13],[1,"\\n"]],[],false,["if","t","action","app-channels-list"]]',
                moduleName: "hotline-web/components/app-history-conversations/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        74978: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = p(n(83973)),
                o = p(n(48692)),
                r = p(n(92945)),
                s = p(n(8838)),
                l = p(n(71644)),
                a = p(n(25808)),
                u = p(n(64719)),
                c = p(n(61807)),
                d = p(n(60416)),
                h = p(n(17798)),
                f = p(n(10228));

            function p(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/and", (function() {
                return o.default
            })), window.define("hotline-web/helpers/or", (function() {
                return r.default
            })), window.define("hotline-web/components/app-channels-list/template", (function() {
                return s.default
            })), window.define("hotline-web/components/app-channels-list/component", (function() {
                return l.default
            })), window.define("hotline-web/components/app-faq-list/template", (function() {
                return a.default
            })), window.define("hotline-web/components/app-faq-list/component", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-rate-limit-error/template", (function() {
                return c.default
            })), window.define("hotline-web/components/ui-rate-limit-error/component", (function() {
                return d.default
            })), window.define("hotline-web/components/ui-footer-note/template", (function() {
                return h.default
            })), window.define("hotline-web/components/ui-footer-note/component", (function() {
                return f.default
            }));
            var g = (0, Ember.HTMLBars.template)({
                id: "ZzeYxivL",
                block: '[[[10,0],[14,0,"home-content"],[12],[1,"\\n  "],[10,0],[15,0,[29,["h-header ",[30,0,["headerStyle"]]]]],[12],[1,"\\n    "],[10,0],[15,0,[29,["title fadeIn ",[52,[30,0,["isRoutedFromFAQ"]],"home-header"]]]],[12],[1,"\\n      "],[10,0],[14,0,"logo"],[12],[1,"\\n"],[41,[30,0,["brandLogoURL"]],[[[1,"          "],[10,"img"],[15,0,[52,[30,0,["isRoutedFromFAQ"]],"home-logo","animated zoomIn faster"]],[15,"src",[30,0,["brandLogoURL"]]],[15,"alt",[28,[37,1],["alt.logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"          "],[10,"img"],[15,0,[52,[30,0,["isRoutedFromFAQ"]],"home-logo","animated zoomIn faster"]],[15,"src",[30,0,["images","HomeIcon"]]],[15,"alt",[28,[37,1],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n"],[41,[28,[37,2],[[30,0,["session","isMultiWidget"]],[28,[37,3],[[30,0,["welcomeMsg"]],[30,0,["welcomeSubMessage"]]],null]],null],[[[1,"        "],[10,0],[14,0,"head-text"],[12],[1,"\\n"],[41,[30,0,["welcomeMsg"]],[[[1,"            "],[10,"h3"],[12],[1,[30,0,["welcomeMsg"]]],[13],[1,"\\n"]],[]],null],[41,[30,0,["welcomeSubMessage"]],[[[1,"            "],[10,"h5"],[12],[1,[30,0,["welcomeSubMessage"]]],[13],[1,"\\n"]],[]],null],[1,"        "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,0],[15,0,[29,["body sections faq-body ",[52,[30,0,["hidePoweredBy"]],"no-footer"]]]],[12],[1,"\\n"],[1,"    "],[10,0],[15,0,[29,["dummy-bar ",[30,0,["headerStyle"]]," ",[52,[30,0,["isRoutedFromFAQ"]],"dummyBar"]]]],[12],[13],[1,"\\n    "],[10,0],[14,0,"card-layout scroll-section"],[12],[1,"\\n"],[1,"      "],[8,[39,4],null,null,null],[1,"\\n"],[41,[30,0,["hasHistoryConversations"]],[[[1,"        "],[10,0],[14,0,"start-new-conversation animated fadeInUp delay-1 faster"],[12],[1,"\\n          "],[10,0],[14,0,"header"],[12],[1,"\\n            "],[10,0],[14,0,"description"],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","advancedOptionsConfig","cardText"]],[[[1,"                "],[10,1],[14,0,"btn-content"],[12],[1,[30,0,["hotline","ui","config","advancedOptionsConfig","cardText"]]],[13],[1,"\\n"]],[]],[[[1,"                "],[10,1],[14,0,"btn-content"],[12],[1,[28,[35,1],["channel.cardText"],null]],[13],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n          "],[11,"button"],[24,0,"h-img-button"],[24,4,"button"],[4,[38,5],[[30,0],"goToAllTopicsRoute"],null],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]],[[[1,"                "],[10,1],[14,0,"btn-content"],[12],[1,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]]],[13],[1,"\\n"]],[]],[[[1,"                "],[10,1],[14,0,"btn-content"],[12],[1,[28,[35,1],["channel.start_new_conversation"],null]],[13],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["isFAQAvailable"]],[[[1,"        "],[8,[39,6],null,null,null],[1,"\\n"]],[]],null],[41,[30,0,["isHelpWidgetAvailable"]],[[[1,"        "],[11,0],[24,0,"start-new-conversation animated fadeInUp delay-1 faster contact-us"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["channel.contact_us"],null]],[4,[38,5],[[30,0],"goToHelpWidgetRoute"],null],[12],[1,"\\n          "],[10,0],[14,0,"header"],[12],[1,"\\n            "],[10,0],[14,0,"description"],[12],[1,"\\n                "],[10,1],[14,0,"btn-content"],[12],[1,[28,[35,1],["channel.contact_us"],null]],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"arrow-icon"],[12],[10,"i"],[14,0,"icon icon-chevron_right_solid"],[12],[13],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[41,[30,0,["isRateLimited"]],[[[1,"        "],[8,[39,7],null,[["@retryAfter","@retryCallback","@isRateLimitExceededOnScroll","@retryingRateLimitedUrl"],[[30,0,["retryRateLimitedUrlIn"]],[28,[37,5],[[30,0],"retryCallbackOnRateLimit"],null],"true",[30,0,["hotline","ui","retryingRateLimitedUrl"]]]],null],[1,"\\n"]],[]],null],[1,"\\n      "],[10,0],[14,0,"bottom-gradient"],[12],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"],[41,[51,[30,0,["hidePoweredBy"]]],[[[1,"  "],[8,[39,9],null,[["@hidePoweredBy"],[[30,0,["hidePoweredBy"]]]],null],[1,"\\n"]],[]],null]],[],false,["if","t","and","or","app-channels-list","action","app-faq-list","ui-rate-limit-error","unless","ui-footer-note"]]',
                moduleName: "hotline-web/components/app-home/template.hbs",
                isStrictMode: !1
            });
            t.default = g
        },
        24868: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(70234)),
                o = r(n(83973));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-loader/template", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "pgKuvVVT",
                block: '[[[10,0],[14,0,"ember-help-widget-wrapper"],[12],[1,"\\n"],[41,[30,0,["isHelpWidgetAppReady"]],[[[1,"        "],[10,"help-widget-app"],[15,"token",[30,0,["session","token"]]],[15,"ticketForms",[30,0,["session","hotline","ui","config","contentConfig","ticketForms"]]],[15,"user",[30,0,["session","prop"]]],[15,"appHost",[30,0,["session","appHost"]]],[15,"buttonColor",[30,0,["session","hotline","ui","config","appearanceConfig","buttonColor"]]],[15,"widgetUuid",[30,0,["session","widgetUuid"]]],[15,"locale",[30,0,["currentLocale"]]],[15,"appearanceConfig",[30,0,["session","hotline","ui","config","appearanceConfig","ticketFormsAppearanceConfig"]]],[12],[1,"\\n        "],[13],[1,"\\n"]],[]],[[[1,"        "],[8,[39,1],null,[["@isVertical","@label"],["true",[28,[37,2],["help_text.loading"],null]]],null],[1,"\\n"]],[]]],[13]],[],false,["if","app-loader","t"]]',
                moduleName: "hotline-web/components/help-widget-wrapper/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        44587: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(92945)),
                o = r(n(83973));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/or", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "Y+o9hb8T",
                block: '[[[11,0],[16,0,[29,["ui-agent-typing-indicator ",[52,[51,[28,[37,1],[[30,0,["isAgentTyping"]],[30,0,["showTypingIndForBots"]]],null]],"hidden"]]]],[16,"aria-label",[28,[37,2],["aria_labels.agent_typing"],null]],[17,1],[12],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["&attrs"],false,["unless","or","t"]]',
                moduleName: "hotline-web/components/ui-agent-typing-indicator/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        17798: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(92945)),
                o = r(n(83973));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/or", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "dWd6xBN8",
                block: '[[[11,0],[16,0,[29,["footer-note animated slideInUp faster ",[52,[28,[37,1],[[30,0,["getRemoveFooter"]],[30,1]],null],"hide-footer"]]]],[17,2],[12],[1,"\\n"],[41,[51,[28,[37,1],[[30,0,["getRemoveFooter"]],[30,1]],null]],[[[1,"    "],[1,[28,[35,3],["by_in_powered_by"],null]],[1,"  "],[10,"img"],[14,0,"icon"],[15,"src",[30,0,["images","Logo"]]],[15,"alt",[28,[37,3],["alt.powered_by"],null]],[12],[13],[1,"  \\n"],[1,"    "],[10,3],[14,6,"https://www.freshworks.com/live-chat-software/powered-by-freshchat/"],[14,0,"product"],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n      "],[1,[28,[35,3],["freshchat"],null]],[1,"\\n    "],[13],[1,"\\n"]],[]],[[[1,"    "],[10,"img"],[14,"src","data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="],[14,"width","0"],[14,"height","0"],[15,"alt",[28,[37,3],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[13],[1,"\\n"]],["@hidePoweredBy","&attrs"],false,["if","or","unless","t"]]',
                moduleName: "hotline-web/components/ui-footer-note/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        40070: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "Y+fKQKsX",
                block: '[[[46,[28,[37,1],null,null],null,null,null]],[],false,["component","-outlet"]]',
                moduleName: "hotline-web/templates/home.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        49877: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(36818)),
                o = r(n(41955));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-history-conversations/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-history-conversations/component", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "6wDVUDTB",
                block: '[[[8,[39,0],null,[["@model"],[[30,0,["model"]]]],null]],[],false,["app-history-conversations"]]',
                moduleName: "hotline-web/templates/home/all-conversations.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        18324: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(83973)),
                o = s(n(8838)),
                r = s(n(71644));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/app-channels-list/template", (function() {
                return o.default
            })), window.define("hotline-web/components/app-channels-list/component", (function() {
                return r.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "Ye8QMWcu",
                block: '[[[10,0],[14,0,"h-conv"],[12],[1,"\\n  "],[10,0],[14,0,"fc-conversation-view fc-all-topics-view"],[12],[1,"\\n    "],[10,0],[14,0,"h-header topics-header"],[12],[1,"\\n      "],[10,0],[15,0,[29,["title fadeIn ",[30,0,["headerStyle"]]]]],[12],[1,"\\n        "],[11,0],[24,0,"ic-back animated fadeIn faster"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,0],["aria_labels.back"],null]],[4,[38,1],[[30,0],"gotoHome"],null],[12],[1,"\\n            "],[10,"i"],[14,0,"icon icon-ic_back"],[12],[13],[1,"\\n          "],[13],[1,"\\n        "],[10,0],[15,0,[29,["channel-info animated fadeIn faster ",[52,[30,0,["isConversationRefIdPresent"]],"no-back-button"]," ",[52,[30,0,["isCompact"]],"channel-info-compact-width","channel-info-width"]]]],[12],[1,"\\n          "],[10,"h1"],[14,0,"channel-title"],[12],[1,[28,[35,0],["channel.all_topics"],null]],[13],[1,"\\n          "],[10,2],[14,0,"list-sub-title"],[12],[1,[28,[35,0],["channel.all_topics_desc"],null]],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[10,0],[14,0,"body"],[12],[1,"\\n      "],[8,[39,3],null,[["@isStartNew"],[true]],null],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,"aria-live","assertive"],[14,0,"aria-live-region"],[12],[13],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"]],[],false,["t","action","if","app-channels-list"]]',
                moduleName: "hotline-web/templates/home/all-topics.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        84924: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(83973)),
                o = s(n(24868)),
                r = s(n(30694));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/help-widget-wrapper/template", (function() {
                return o.default
            })), window.define("hotline-web/components/help-widget-wrapper/component", (function() {
                return r.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "IN3iXxVq",
                block: '[[[10,0],[14,0,"h-conv"],[12],[1,"\\n  "],[10,0],[14,0,"fc-conversation-view"],[12],[1,"\\n    "],[10,0],[14,0,"h-header topics-header contact-us-header"],[12],[1,"\\n      "],[10,0],[15,0,[29,["title fadeIn ",[30,0,["headerStyle"]]]]],[12],[1,"\\n        "],[11,0],[24,0,"ic-back animated fadeIn faster"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,0],["aria_labels.back"],null]],[4,[38,1],[[30,0],"gotoHome"],null],[12],[1,"\\n          "],[10,"i"],[14,0,"icon icon-ic_back"],[12],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,0],[15,0,[29,["channel-info animated fadeIn faster ",[52,[30,0,["isCompact"]],"channel-info-compact-width","channel-info-width"]]]],[12],[1,"\\n          "],[10,"h1"],[14,0,"channel-title contact-us-title"],[12],[1,[28,[35,0],["channel.contact_us"],null]],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[10,0],[14,0,"body help-widget-body"],[12],[1,"\\n      "],[8,[39,3],null,null,null],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"],[13]],[],false,["t","action","if","help-widget-wrapper"]]',
                moduleName: "hotline-web/templates/home/help-widget.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        8556: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n(74978)),
                o = r(n(93497));

            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-home/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-home/component", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "ItfW6C1z",
                block: '[[[8,[39,0],null,[["@model"],[[30,0,["model"]]]],null]],[],false,["app-home"]]',
                moduleName: "hotline-web/templates/home/index.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        65882: function(e, t, n) {
            "use strict";
            t.Z = n.p + "uploading_new.98b10ec655025f35a4f07a99ec6e6de9.gif"
        }
    }
]);