(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [3436], {
        3436: function(e, t, n) {
            var i = window.define;
            i("hotline-web/templates/home/channel", (function() {
                return n(30169)
            })), i("hotline-web/controllers/home/channel", (function() {
                return n(11219)
            })), i("hotline-web/routes/home/channel", (function() {
                return n(60451)
            }))
        },
        71968: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(62766),
                s = n(50660),
                a = n(7259),
                l = n(8869),
                r = n(13418);
            t.default = Ember.Component.extend(a.default, s.default, o.default, l.default, {
                tagName: "ul",
                classNames: ["fc-app-conversation-message"],
                classNameBindings: ["isFeedbackMessage:feedback-message"],
                notification: Ember.inject.service(),
                liveTranslation: Ember.inject.service(),
                localStorage: Ember.inject.service("local-storage"),
                pushPermissionOffered: !1,
                disablePushNotification: !0,
                channelWrapedMessage: Ember.computed("channelMessage", {
                    get: function() {
                        var e = [];
                        return e.push(this.channelMessage), e
                    }
                }),
                currentAgent: Ember.computed("lastAgentMessage.messageId", {
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("messageUserAlias");
                        return !!t && this.agentService.getAgentInfo(t)
                    }
                }),
                calendarMessages: Ember.computed.alias("conversationCalendarMessages"),
                messagesWithAppId: Ember.computed("messages.[]", {
                    get: function() {
                        var e = this,
                            t = this.messages.filter(function(t) {
                                return (0, i.Z)(this, e), t.get("appId")
                            }.bind(this));
                        return t && t.length
                    },
                    set: function(e, t) {
                        return t
                    }
                }),
                messageAppIdObserver: Ember.observer("messages.@each.createdMillis", (function() {
                    var e = this,
                        t = this.messages ? this.messages.filter(function(t) {
                            return (0, i.Z)(this, e), t.get("appId")
                        }.bind(this)) : null;
                    t && t.length > this.messagesWithAppId && this.set("messagesWithAppId", t.length)
                })),
                screenShare: Ember.computed.reads("session.fcCbstart"),
                showPushOptions: Ember.computed("hotline.ui.push.{subscription,permission}", "pushPermissionOffered", "messagesCount", "session.isMultiWidget", "hotline.ui.config.advancedOptionsConfig.enableBrowserNotification", {
                    get: function() {
                        var e, t, n, i, o, s, a;
                        if (null !== (e = this.session) && void 0 !== e && e.isMultiWidget && (null === (t = this.hotline) || void 0 === t || null === (n = t.ui) || void 0 === n || null === (i = n.config) || void 0 === i || null === (o = i.advancedOptionsConfig) || void 0 === o || !o.enableBrowserNotification) || this.disablePushNotification) return !1;
                        var l = null === (s = this.hotline) || void 0 === s || null === (a = s.ui) || void 0 === a ? void 0 : a.push,
                            r = this.messages,
                            u = r && r.findBy("messageUserType", 0),
                            c = this.messagesCount,
                            d = l && l.subscription,
                            p = "denied" === (l && l.permission),
                            h = this.pushPermissionOffered,
                            f = (new Date).getTime(),
                            m = this.localStorage.getItemLS("lastPushActionMillis"),
                            g = this.notification.isPushSupportedByBrowser(),
                            v = !1;
                        return m = parseInt(m), f - (m = isNaN(m) ? 0 : m) > 6048e5 && (v = !0), !p && !d && v && !h && c && g && u
                    }
                }),
                setLastPushActionMillis: function() {
                    var e, t, n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    !n && null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isFirefoxMobile || (this.localStorage.setItemLS("lastPushActionMillis", (new Date).getTime()), this.set("pushPermissionOffered", !0))
                },
                actions: {
                    askPermission: function() {
                        this.notification.requestPermission(), this.setLastPushActionMillis()
                    },
                    clearPermission: function() {
                        this.notification.clearPermission(), this.setLastPushActionMillis(!0)
                    },
                    openCalendarPickerMaximized: function(e) {
                        this.openCalendarPickerMaximized(e)
                    },
                    sendMessage: function(e, t) {
                        this.sendMessage(e, t)
                    },
                    resendMessage: function(e) {
                        this.resendMessage(e)
                    },
                    sendOfflineMessage: function(e) {
                        this.sendOfflineMessage(e)
                    },
                    setNextFocus: function(e) {
                        var t = document.querySelector(".ic-back"),
                            n = document.querySelector(".fc-carousel");
                        (null == e ? void 0 : e.target) === n && (null == e ? void 0 : e.keyCode) === r.default.KEYCODES.TAB && null != e && e.shiftKey && t && (e.preventDefault(), t.focus())
                    },
                    carouselSelectionHandler: function(e) {
                        var t = {
                            replyTo: {
                                originalMessageId: this.lastMessage.messageId
                            }
                        };
                        this.sendButtonMessage(e, t)
                    },
                    dateSelectionHandler: function(e, t) {
                        var n = [{
                                fragmentType: r.default.CONVERSATION.FRAGMENT_TYPE.TEXT,
                                contentType: "text/html",
                                content: t
                            }],
                            i = {
                                replyTo: {
                                    originalMessageId: this.lastMessage.messageId
                                }
                            };
                        this.sendButtonMessage(n, i)
                    },
                    sendButtonMessage: function(e, t) {
                        this.sendButtonMessage(e, t)
                    }
                }
            })
        },
        46379: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return R
                }
            });
            var i = n(35235),
                o = n(52626),
                s = n(13418),
                a = n(32583),
                l = n(7259),
                r = n(89866),
                u = n(62766),
                c = n(50660),
                d = n(79956),
                p = n(89567),
                h = n(16686),
                f = n(90123),
                m = n(60534),
                g = n(42410),
                v = n(62471),
                b = n(96064),
                y = n(70387),
                w = n(18949),
                E = n(71259),
                T = n(22342),
                C = n(76441),
                S = n.p + "ic_offline.e15c54b5fa2b3da7577b7869b850722d.svg",
                O = n.p + "briefcase-regular.1fb32179dcc50beeba1a21747ce7a539.svg",
                M = n(57041),
                I = n(67946),
                k = n(75920),
                _ = n(22126);

            function A(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function P(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? A(Object(n), !0).forEach((function(t) {
                        (0, o.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : A(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var R = Ember.Component.extend(l.default, c.default, u.default, r.default, d.default, f.default, k.default, _.default, {
                PLACEHOLDERS: s.default.CONVERSATION.PLACEHOLDERS,
                CONVERSATION: s.default.CONVERSATION,
                DOM_ID: s.default.DOM_ID,
                notification: Ember.inject.service(),
                hotline: Ember.inject.service(),
                rts: Ember.inject.service(),
                conversationService: Ember.inject.service("conversation"),
                localStorage: Ember.inject.service("local-storage"),
                botActionEvents: Ember.inject.service("bot-action-events"),
                smartPolling: Ember.inject.service("smart-polling"),
                checkBotTimeout: !1,
                responseTime30Mins: !1,
                responseTime7Days: !1,
                cdnUrl: v.default.EmberENV.cdnUrl,
                isOldConvRequestPending: !1,
                showUnreadToast: !1,
                focusAfterOfflineMessage: !1,
                isLoadedAllOlderMessages: !1,
                isDynamicFlowLoading: !1,
                extraParams: {},
                images: Ember.Object.create({
                    FCLine: C.Z,
                    ICOffline: S,
                    BCReg: O,
                    ValidationErrorIcon: M.Z,
                    ExternalLink: I.Z
                }),
                transitionDelays: 100,
                hideHeader: Ember.computed.alias("session.config.headerProperty.hideHeader"),
                isConversationsLoaded: Ember.computed.alias("hotline.ui.isConversationsLoaded"),
                isConversationRefIdPresent: Ember.computed.alias("hotline.ui.conversationReferenceId"),
                dynamicInitMessage: Ember.computed.alias("channelInfo.dynamicInitMessage"),
                freddyMessageType: s.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT,
                botMessageType: s.default.CONVERSATION.MESSAGE_TYPE.BOT,
                enabledBetaFeatures: Ember.computed.alias("hotlineUI.config.betaFeatures"),
                classNames: ["h-conv"],
                classNameBindings: ["hideHeader:hide-header"],
                allowRR: !0,
                fileId: "fileUploadInput",
                blockedFileTypes: s.default.ExcludedFileExtensions,
                fileType: s.default.FILETYPE,
                isTextLimitExceeded: !1,
                pendingUploadTextFileObject: null,
                isValueInEditor: !1,
                appConversationEditorNode: null,
                editorHasContent: !1,
                showPrivacyPolicy: !1,
                privacyPolicy: Ember.computed("hotline.ui.config", "session.config", {
                    get: function() {
                        var e, t, n = s.default.PrivacyPolicy,
                            i = n.messageMaxLength,
                            o = n.linkTextMaxLength,
                            a = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t ? void 0 : t.privacyPolicySetting;
                        if (a) {
                            var l = a,
                                r = l.message,
                                u = l.linkText;
                            a = P(P({}, a), {}, {
                                message: (null == r ? void 0 : r.length) > i ? "".concat(r.slice(0, i), "...") : r,
                                linkText: (null == u ? void 0 : u.length) > o ? "".concat(u.slice(0, o), "...") : u
                            })
                        } else {
                            var c, d, p, h;
                            a = null === (c = this.hotline) || void 0 === c || null === (d = c.ui) || void 0 === d || null === (p = d.config) || void 0 === p || null === (h = p.advancedOptionsConfig) || void 0 === h ? void 0 : h.privacyPolicySetting
                        }
                        return a
                    }
                }),
                chatWindowClass: Ember.computed("defaultComposer", "conversation.resolvedConversation", "quickActionButtons", "isOfflineForm", "isInLineReplyFragments", "isParallelConversationResolved", {
                    get: function() {
                        var e = "";
                        return this.defaultComposer ? this.quickActionButtons && (e = "".concat(e, " actions-composer")) : e = "".concat(e, " button-composer"), this.conversation && this.conversation.resolvedConversation && (e = "".concat(e, " fixed-scroll")), this.isOfflineForm && (e = "".concat(e, " offline-form")), this.isInLineReplyFragments && (e = "".concat(e, " in-line-reply-fragments")), this.isParallelConversationResolved && (e = "".concat(e, " parallel-conversation-resolved")), e
                    }
                }),
                agentProfileClass: Ember.computed("currentAgent.{title,bio}", {
                    get: function() {
                        var e = "",
                            t = Ember.get(this, "currentAgent");
                        return t && t.get("title") && (e = "".concat(e, " agent-section")), t && t.get("bio") && (e = "".concat(e, " agent-bio")), e
                    }
                }),
                isFeedbackMessage: Ember.computed("lastMessage", {
                    get: function() {
                        var e, t, n, i = s.default.TemplateType;
                        return [i.FEEDBACK_RATING, i.FEEDBACK_OPINION_POLL, i.FEEDBACK_COMMENT].includes(null === (e = this.lastMessage) || void 0 === e || null === (t = e.replyFragments) || void 0 === t || null === (n = t[0]) || void 0 === n ? void 0 : n.templateType)
                    }
                }),
                awaitingBotResponse: Ember.computed("lastAgentMessage.messageType", "checkBotTimeout", "conversation.status", "hasUnrepliedFlowMessages", {
                    get: function() {
                        var e, t, n, o = this,
                            a = s.default.CONVERSATION.MESSAGE_TYPE,
                            l = a.FREDDY_BOT,
                            r = a.BOT,
                            u = this.lastAgentMessage,
                            c = this.conversation,
                            d = this.lastMessage,
                            p = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n ? void 0 : n.widgetHideInputFeatureEnabled;
                        if (u && d && p) {
                            var h, f, m = u.messageType,
                                g = null === (h = this.CONVERSATION) || void 0 === h ? void 0 : h.CONVERSATION_STATUS,
                                v = g.FREDDY_BOT,
                                b = g.BOT,
                                y = g.RESOLVED,
                                w = m === l || m === r,
                                E = c.status === v || c.status === b,
                                T = void 0 === c.status,
                                C = T || c.status === y,
                                S = w && (E || C),
                                O = this.enabledBetaFeatures[s.default.widgetHideInputWithFlag],
                                M = this.enabledBetaFeatures[s.default.privateNodeHideInputFlag];
                            if (this.checkBotTimeout) return !1;
                            if (!S || !O || d.isFeedbackResponse || null !== (f = this.session) && void 0 !== f && f.previewMode || this.hasUnrepliedFlowMessages) {
                                var I, k, _ = !M && d.isBotsPrivate,
                                    A = this.localStorage.getItemLS("wcfcAlias"),
                                    P = null === (I = this.session) || void 0 === I || null === (k = I.user) || void 0 === k ? void 0 : k.alias;
                                return !(this.isConversationTestingEnabled && A && !P) && (w && (d.userMessage || _) && (T || E) && !d.isFeedbackResponse)
                            }
                            var R, D, N = null === (R = this.channelInfo) || void 0 === R || null === (D = R.flowMessages) || void 0 === D ? void 0 : D.filter(function(e) {
                                return (0, i.Z)(this, o), e.isBotsInput
                            }.bind(this));
                            return !((null == d ? void 0 : d.isBotsInput) || (null == d ? void 0 : d.botsInput) || (null == N ? void 0 : N.length) > 0 && C) || d.userMessage
                        }
                        return !1
                    }
                }),
                isSingleChannel: Ember.computed("isFAQAvailable", "channelsCount", "getFaqCategories", "isHelpWidgetAvailable", {
                    get: function() {
                        return !(this.isFAQAvailable && 0 !== this.getFaqCategories.length || 1 !== this.channelsCount || this.isParallelFeatureEnabled || this.isHelpWidgetAvailable)
                    }
                }),
                widgetInitFeatureEnabled: Ember.computed({
                    get: function() {
                        return this.enabledBetaFeatures[s.default.widgetInitLoadEnabled] && this.dynamicInitMessage
                    }
                }),
                headerStyle: Ember.computed("hotline.ui.config.appearanceConfig.brandColorStyle", "session.isMultiWidget", {
                    get: function() {
                        var e, t, n, i, o, s, a, l;
                        return this.session.isMultiWidget ? null === (o = this.hotline) || void 0 === o || null === (s = o.ui) || void 0 === s || null === (a = s.config) || void 0 === a || null === (l = a.appearanceConfig) || void 0 === l ? void 0 : l.brandColorStyle : null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.headerProperty) || void 0 === i ? void 0 : i.headerStyle
                    }
                }),
                botEventCB: Ember.computed({
                    get: function() {
                        return this.botActionEventCB.bind(this)
                    }
                }),
                onRTSMessageCB: Ember.computed({
                    get: function() {
                        return this.onRTSMessage.bind(this)
                    }
                }),
                onRTSMessage: function(e) {
                    e.type === s.default.BOT_TIMEOUT ? this.set("checkBotTimeout", !0) : e.type === s.default.MESSAGE_RECEIVED && this.set("checkBotTimeout", !1)
                },
                chatSectionClass: Ember.computed("showAgentProfile", "showCalPicker", "channelEventReminder.eventDateTime", "isAgentProfileExpand", "isFocusInput", "isOfflineForm", "conversation.resolvedConversation", "isFeedbackMessage", "quickActionButtons", {
                    get: function() {
                        var e = "";
                        return this.showAgentProfile && !this.showPrivacyPolicy && (e = "".concat(e, " profile")), this.showCalPicker && (e = "".concat(e, " show-calendar-picker")), this.channelEventReminder && this.channelEventReminder.eventDateTime && (e = "".concat(e, " cal-notif-active")), this.isAgentProfileExpand && (e = "".concat(e, " profile-expand")), this.isOfflineForm && (e = "".concat(e, " offline-form")), this.conversation && this.conversation.resolvedConversation && (e = "".concat(e, " csat-fix")), this.showAgentProfile && !this.isFocusInput || (e = "".concat(e, " no-profile")), this.isFeedbackMessage && this.quickActionButtons && (e = "".concat(e, " feedback-with-qa")), e
                    }
                }),
                toastMessageClass: Ember.computed("displayUnreadToastBubble", "showUnreadToast", "quickActionButtons", "isFeedbackMessage", {
                    get: function() {
                        return this.isFeedbackMessage && this.quickActionButtons ? "chip-height-with-feedback-qa" : this.quickActionButtons ? "chip-height" : ""
                    }
                }),
                replyWrapperClass: Ember.computed("defaultComposer", "isOfflineForm", {
                    get: function() {
                        var e = "";
                        return this.defaultComposer || (e = "".concat(e, " custom-reply-composer")), this.isOfflineForm && (e = "".concat(e, " offline-form")), e
                    }
                }),
                replyEditorClass: Ember.computed("hasFileAttachment", "data.fileContent", "hotline.ui.onLine", "isOfflineForm", {
                    get: function() {
                        var e = "";
                        return this.hasFileAttachment && (e = "".concat(e, " has-file-attachment")), this.data && this.data.fileContent && (e = "".concat(e, " preview")), this.hotline && this.hotline.ui && !this.hotline.ui.onLine && (e = "".concat(e, " is-disabled")), this.isOfflineForm && (e = "".concat(e, " offline-form")), e
                    }
                }),
                hasValueInEditor: Ember.computed("isValueInEditor", "data.fileContent", "hasFileAttachment", {
                    get: function() {
                        return this.isValueInEditor || this.data && this.data.fileContent || this.hasFileAttachment
                    }
                }),
                doesUserExists: Ember.computed({
                    get: function() {
                        return !0
                    },
                    set: function(e, t) {
                        return t
                    }
                }),
                validationMsg: Ember.computed("hotline.ui.validationMessage", {
                    get: function() {
                        var e, t;
                        return null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.validationMessage
                    }
                }),
                channelResponseTime: Ember.computed("channelId", "hotline.ui.rspTime.{channelResponseTime,channelResponseTimesFor7Days}", {
                    get: function() {
                        var e, t, n, i, o, s, a, l, r = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.rspTime) || void 0 === n ? void 0 : n.channelResponseTime,
                            u = null === (i = this.hotline) || void 0 === i || null === (o = i.ui) || void 0 === o || null === (s = o.rspTime) || void 0 === s ? void 0 : s.channelResponseTimesFor7Days,
                            c = this.channelId,
                            d = [];
                        return r && r.length && (a = r.find((function(e) {
                            return e.channelId === c
                        }))), u && u.length && (l = u.find((function(e) {
                            return e.channelId === c
                        }))), a ? (this.set("responseTime30Mins", !0), d = a) : l && (this.set("responseTime7Days", !0), d = l), d
                    }
                }),
                customResponseTime: Ember.computed("channelId", "hotline.ui.rspTime.channelCustomResponse", {
                    get: function() {
                        var e, t, n, i, o = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.rspTime) || void 0 === n ? void 0 : n.channelCustomResponse,
                            s = this.channelId;
                        return o && o.length && (i = o.findBy("channelId", s)), i
                    }
                }),
                checkIfRtlIE: Ember.computed("hotline.ui.browser.name", {
                    get: function() {
                        var e, t, n, i = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.browser) || void 0 === n ? void 0 : n.name,
                            o = document.body.attributes.dir;
                        return "rtl" === (o && o.value) && ("Trident" === i || "Microsoft Internet Explorer" === i)
                    }
                }),
                showAgentProfile: Ember.computed("currentAgent.{firstName,lastName}", "hideName", {
                    get: function() {
                        var e = Ember.get(this, "currentAgent");
                        return !!e && (Ember.get(e, "firstName") || Ember.get(e, "lastName"))
                    }
                }),
                isSocialLinkPresent: Ember.computed("currentAgent.socialInfo.{twitter,facebook,linkedIn,skype}", {
                    get: function() {
                        var e = Ember.get(this, "currentAgent.socialInfo");
                        return !!e && (e.twitter || e.facebook || e.linkedIn || e.skype)
                    }
                }),
                isOfflineForm: Ember.computed("isPhoneNumberWithCode", "shouldHideReplyEditor", {
                    get: function() {
                        return this.shouldHideReplyEditor && !this.isPhoneNumberWithCode
                    }
                }),
                handleLoadingOlderMessages: function() {
                    document.getElementsByClassName("h-conv-chat")[0].scrollTop <= 30 ? this.send("fetchOlderMessages") : this.getScrollDistanceFromBottom() < 90 && this.resetUnreadCount()
                },
                onScroll: function() {
                    this.set("isAgentProfileExpand", !1), this.handleLoadingOlderMessages()
                },
                onScrollWithDebounce: function() {
                    Ember.run.debounce(this, this.onScroll, s.default.Debounce.SCROLL_DELAY)
                },
                scrollCallback: Ember.computed({
                    get: function() {
                        return this.onScrollWithDebounce.bind(this)
                    }
                }),
                willDestroyElement: function() {
                    var e, t, n, i;
                    this._super.apply(this, arguments), (0, m.unbindEvent)(document, "selectionchange", this.setSelectionCallback), Ember.removeListener(this.botActionEvents, "botActionEvent", this.botEventCB), Ember.removeListener(this.hotline, "conversationsLoadedEvent", this.conversationsLoadedEventCB), Ember.removeListener(this.rts, "didRTSMessage", this.onRTSMessageCB), (0, m.unbindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isDesktop || ((0, m.unbindEvent)(this.element.querySelector("#app-conversation-editor"), "focus"), (0, m.unbindEvent)(this.element.querySelector("#app-conversation-editor"), "blur"), (0, m.unbindEvent)(window, "resize")), this.isJWTStrictMode && Ember.removeListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), this.messages && this.messages.length > 100 && this.set("messages", this.getLatestNMessages(this.messages)), null !== (n = this.hotline) && void 0 !== n && null !== (i = n.ui) && void 0 !== i && i.parallelConversationId && this.set("hotline.ui.parallelConversationId", "")
                },
                isAwayMessage: Ember.computed("lastAgentMessage.source", {
                    get: function() {
                        var e = this.lastAgentMessage,
                            t = e && e.get("source");
                        return t === s.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE || t === s.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE_THANK_MESSAGE || t === s.default.CONVERSATION.MESSAGE_SOURCE.BH_AWAY_MESSAGE
                    }
                }),
                isLastAgentMessageFromBot: Ember.computed("lastAgentMessage.messageType", {
                    get: function() {
                        var e, t = null === (e = this.lastAgentMessage) || void 0 === e ? void 0 : e.messageType;
                        return t === this.botMessageType || t === this.freddyMessageType
                    }
                }),
                currentAgent: Ember.computed("CONVERSATION.MESSAGE_TYPE.BOT", "agentService", "isAwayMessage", "lastAgentMessage.messageId", {
                    get: function() {
                        var e, t, n = this.lastAgentMessage,
                            i = n && n.get("messageUserAlias"),
                            o = this.isAwayMessage;
                        return i && n.get("messageType") === (null === (e = this.CONVERSATION) || void 0 === e || null === (t = e.MESSAGE_TYPE) || void 0 === t ? void 0 : t.BOT) ? Ember.Object.create({
                            firstName: n.get("userFirstName"),
                            lastName: n.get("userLastName"),
                            id: n.get("messageUserId"),
                            alias: i,
                            profilePicUrl: n.get("messageUserProfilePic") || T.Z
                        }) : !(!i || o) && this.agentService.getAgentInfo(i)
                    }
                }),
                freshIdAgentPic: Ember.computed("currentAgent.alias", {
                    get: function() {
                        var e, t, n, i = this.currentAgent,
                            o = i && i.get("alias");
                        return null !== (e = this.hotlineUI) && void 0 !== e && null !== (t = e.config) && void 0 !== t && t.sales360App ? (0, E.freshIdAgentPicUrl)(null === (n = this.session) || void 0 === n ? void 0 : n.token, o) : ""
                    }
                }),
                showAgentBio: Ember.computed("currentAgent", {
                    get: function() {
                        return this.currentAgent.get("bio") && !this.hideBio && !this.hideName
                    }
                }),
                dropDownOpen: function() {
                    y.default.moveFocusTo(".input__search"), y.default.onDropDownOpen(".fc-emoji-picker-emoji", ".input__search", !1)
                },
                getResponseMinutes: function(e) {
                    var t, n, i, o, s, a = null === (t = this.session) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.content) || void 0 === i || null === (o = i.headers) || void 0 === o || null === (s = o.channel_response) || void 0 === s ? void 0 : s.online;
                    if (a && a.minutes) {
                        if (a.minutes.one && 1 === e) return this.replaceWithResponseTime(a.minutes.one, e);
                        if (a.minutes.more && e > 1) return this.replaceWithResponseTime(a.minutes.more, e)
                    }
                    return null
                },
                getResponseHours: function(e) {
                    var t, n, i, o, s, a = null === (t = this.session) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.content) || void 0 === i || null === (o = i.headers) || void 0 === o || null === (s = o.channel_response) || void 0 === s ? void 0 : s.online;
                    if (a && a.hours) {
                        if (a.hours.one && 1 === e) return this.replaceWithResponseTime(a.hours.one, e);
                        if (a.hours.more && e > 1) return this.replaceWithResponseTime(a.hours.more, e)
                    }
                    return null
                },
                responseTime: Ember.computed("channelResponseTime", "customResponseTime", "intl", "responseTime30Mins", "session.config.content.headers.channel_response.online", {
                    get: function() {
                        var e, t, n, i, o, s, a = this.channelResponseTime,
                            l = a && a.responseTime,
                            r = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i || null === (o = i.channel_response) || void 0 === o ? void 0 : o.online,
                            u = this.responseTime30Mins,
                            c = this.customResponseTime;
                        if (c) return c.customRespMsg;
                        if (l) {
                            if (l < 3600) {
                                if ((l = Math.ceil(l / 60)) > 10) {
                                    if ((s = 5 * Math.ceil(l / 5)) < 60) {
                                        var d = this.getResponseMinutes(s);
                                        return d || (u ? this.intl.t("conversation.response_time.minutes_other", {
                                            count: s
                                        }) : this.intl.t("conversation.response_time_7days.minutes_other", {
                                            count: s
                                        }))
                                    }
                                    return r && r.hours && r.hours.one ? r.hours.one : u ? this.intl.t("conversation.response_time.hours_one") : this.intl.t("conversation.response_time_7days.hours_one")
                                }
                                var p = this.getResponseMinutes(l);
                                return p || (u ? l > 1 ? this.intl.t("conversation.response_time.minutes_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time.minutes_one") : l > 1 ? this.intl.t("conversation.response_time_7days.minutes_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time_7days.minutes_one"))
                            }
                            if ((l = Math.ceil(l / 3600)) <= 2) {
                                var h = this.getResponseHours(l);
                                return h || (u ? l > 1 ? this.intl.t("conversation.response_time.hours_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time.hours_one") : l > 1 ? this.intl.t("conversation.response_time_7days.hours_other", {
                                    count: l
                                }) : this.intl.t("conversation.response_time_7days.hours_one"))
                            }
                            return r && r.hours && r.hours.more ? this.replaceWithResponseTime(r.hours.more, l) : u ? this.intl.t("conversation.response_time.more") : this.intl.t("conversation.response_time_7days.more")
                        }
                        return r && r.default
                    }
                }),
                conversationDescription: Ember.computed("intl", "isChannelOffline", "isChannelOutsideBusinessHour", "responseTime", "session.config.content.headers.channel_response.offline", "isBotConversation", {
                    get: function() {
                        var e, t, n, i, o, s = this.isChannelOutsideBusinessHour,
                            a = this.responseTime,
                            l = this.intl,
                            r = null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.headers) || void 0 === i || null === (o = i.channel_response) || void 0 === o ? void 0 : o.offline,
                            u = this.isChannelOffline;
                        return this.isBotConversation ? null : s ? u ? l.t("channel.offline_message") : r ? (0, h.sanitizeHTML)(this, r, "strict") : l.t("channel.away_message") : a || null
                    }
                }),
                showingFocusEditor: Ember.observer("shouldHideEditorWrapper", "awaitingBotResponse", (function() {
                    this.shouldHideEditorWrapper || this.awaitingBotResponse || this.setFocus()
                })),
                onConversationFetch: Ember.observer("isConversationsLoaded", (function() {
                    var e = this;
                    this.isConversationsLoaded && (this.beforeChannelEnter(), setTimeout(function() {
                        (0, i.Z)(this, e), this.scrollToBottom()
                    }.bind(this), this.transitionDelays))
                })),
                shouldDisableUserInput: Ember.computed("isConversationsLoaded", "channelInfo", "hotline.ui.userBehaviour", {
                    get: function() {
                        var e, t, n, o, s = this,
                            a = null === (e = this.channelInfo) || void 0 === e ? void 0 : e.channelId,
                            l = null === (t = this.hotline.ui) || void 0 === t || null === (n = t.userBehaviour) || void 0 === n ? void 0 : n.eventRules,
                            r = Array.isArray(l) ? l.find(function(e) {
                                var t;
                                (0, i.Z)(this, s);
                                var n = null == e || null === (t = e.command) || void 0 === t ? void 0 : t.commandValue;
                                return n && n.channelId == a && n.flowId
                            }.bind(this)) : void 0,
                            u = null === (o = this.channelInfo) || void 0 === o ? void 0 : o.flowMessages;
                        return !(!r && !u) && !this.isConversationsLoaded
                    }
                }),
                quickActionsMenu: Ember.computed("channelInfo", "showQuickActions", {
                    get: function() {
                        var e = s.default.QUICK_ACTIONS_TYPE.menu;
                        return this.getQuickActions(e)
                    }
                }),
                quickActionsSlashCommandOptions: Ember.computed("channelInfo", "showQuickActions", {
                    get: function() {
                        var e = s.default.QUICK_ACTIONS_TYPE.slashCommand;
                        return this.getQuickActions(e)
                    }
                }),
                quickActionButtons: Ember.computed("lastMessage", "showQuickActions", {
                    get: function() {
                        var e = this;
                        if (this.showQuickActions) {
                            var t, n, o, a, l = this.getMessageQuickActions(null === (t = this.lastMessage) || void 0 === t ? void 0 : t.replyFragments);
                            if (l) n = null == l || null === (o = l.sections) || void 0 === o || null === (a = o.find(function(t) {
                                return (0, i.Z)(this, e), t.name === s.default.RICH_MESSAGES.SECTION_NAMES.ACTIONS
                            }.bind(this))) || void 0 === a ? void 0 : a.fragments;
                            return n
                        }
                        return !1
                    }
                }),
                showQuickActions: Ember.computed("conversation.status", {
                    get: function() {
                        var e, t = null === (e = this.conversation) || void 0 === e ? void 0 : e.status;
                        return Ember.isEmpty(t) || t === s.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT || t === s.default.CONVERSATION.CONVERSATION_STATUS.BOT
                    }
                }),
                getBrandLogo: Ember.computed("hotline.ui.config.{appearanceConfig.brandLogoURL,widgetLogoUrl}", "session.isMultiWidget", {
                    get: function() {
                        var e, t, n;
                        return this.session.isMultiWidget ? null === (e = this.hotline.ui.config) || void 0 === e || null === (t = e.appearanceConfig) || void 0 === t ? void 0 : t.brandLogoURL : null === (n = this.hotline.ui.config) || void 0 === n ? void 0 : n.widgetLogoUrl
                    }
                }),
                isParallelConversationResolved: Ember.computed("isParallelConversationEnabled", "conversation.isResolved", "hotline.ui.config.advancedOptionsConfig", "lastAgentMessage.createdMillis", {
                    get: function() {
                        var e, t, n, i, o, s = null === (e = this.lastAgentMessage) || void 0 === e ? void 0 : e.createdMillis,
                            a = null === (t = this.hotline) || void 0 === t || null === (n = t.ui) || void 0 === n || null === (i = n.config) || void 0 === i ? void 0 : i.advancedOptionsConfig,
                            l = null == a ? void 0 : a.isParallelConversationsReplyWindowEnabled,
                            r = s + 36e5 * (24 * (null == a ? void 0 : a.parallelConversationIntervalDays) + (null == a ? void 0 : a.parallelConversationIntervalHours)) < (new Date).getTime();
                        return this.isParallelConversationEnabled && l && (null === (o = this.conversation) || void 0 === o ? void 0 : o.isResolved) && r
                    }
                }),
                shouldHideEditorWrapper: Ember.computed("conversation.hasPendingCsat", "lastMessage", "isParallelConversationResolved", {
                    get: function() {
                        var e, t = this.lastMessage;
                        return !!(this.isParallelConversationResolved || null !== (e = this.conversation) && void 0 !== e && e.hasPendingCsat || t && t.restrictResponse && !this.isCarouselMessage(t.replyFragments) && !this.isCustomButtonComposer(t))
                    }
                }),
                shouldHideReplyEditor: Ember.computed("isPhoneNumberWithCode", "lastMessage", "shouldDisableUserInput", {
                    get: function() {
                        var e = this.lastMessage;
                        return !(!e || !e.get("offlineMessage")) || (!(!e || !e.get("flowStepId") || e.get("messageType") !== s.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT) || (!!this.shouldDisableUserInput || !!this.isPhoneNumberWithCode))
                    }
                }),
                getPlaceholderMessage: Ember.computed("lastMessage", {
                    get: function() {
                        var e, t, n = this,
                            o = {},
                            a = null == this || null === (e = this.lastMessage) || void 0 === e ? void 0 : e.replyFragments;
                        null != a && a.length && (o = P(P({}, o = a.find(function(e) {
                            return (0, i.Z)(this, n), s.default.VALIDATION_PLACEHOLDER_MESSAGE[e.inputType]
                        }.bind(this))), s.default.VALIDATION_PLACEHOLDER_MESSAGE[null === (t = o) || void 0 === t ? void 0 : t.inputType]));
                        return o.placeholder || "conversation.ce.placeholders.default"
                    }
                }),
                isChannelOffline: Ember.computed("isChannelOutsideBusinessHour", "offlineExperienceEnabledChannel", "model.offlineExperience.offlineExpEnabled", {
                    get: function() {
                        var e, t;
                        return !!(null !== (e = this.model) && void 0 !== e && null !== (t = e.offlineExperience) && void 0 !== t && t.offlineExpEnabled && this.offlineExperienceEnabledChannel && this.isChannelOutsideBusinessHour)
                    }
                }),
                getQuickActions: function(e) {
                    var t;
                    return !!this.showQuickActions && (this.channelInfo && (null === (t = this.channelInfo.quick_actions) || void 0 === t ? void 0 : t[e]))
                },
                isAwayExperienceEligible: function() {
                    var e, t, n, i;
                    if ((null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.triggerTimerForBusinessHours) === s.default.messengerVisibilityOptions.businessHours) return !1;
                    if (this.isChannelOffline && this.offlineExperienceEnabledChannel && null !== (n = this.model) && void 0 !== n && null !== (i = n.offlineExperience) && void 0 !== i && i.offlineExpEnabled) {
                        var o = this.conversation,
                            a = this.currentConversationhasPendingCsat,
                            l = this.isLastUserMessageTimeExceeded(),
                            r = this.repliedToLastOfflineMessage,
                            u = this.currentConversationStatus,
                            c = this.conversationOfflineMessagesCount;
                        if (!o) return !0;
                        if (o && c < 1 && o && !o.conversationId) return !0;
                        if (!a && (l || u === s.default.CONVERSATION.CONVERSATION_STATUS.RESOLVED) && (r || 0 === c)) return !0
                    }
                    return !1
                },
                managePrivacyPolicy: function() {
                    var e, t, n, i, o, s, a = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.config,
                        l = null === (n = this.session.user) || void 0 === n ? void 0 : n.alias,
                        r = this.localStorage.getItemLS("isPrivacyPolicyShown"),
                        u = (null === (i = this.session) || void 0 === i || null === (o = i.config) || void 0 === o ? void 0 : o.enablePrivacyPolicy) || (null == a || null === (s = a.advancedOptionsConfig) || void 0 === s ? void 0 : s.enablePrivacyPolicy);
                    l ? Ember.set(this, "showPrivacyPolicy", !r) : u && Ember.set(this, "showPrivacyPolicy", !0)
                },
                beforeChannelEnter: function() {
                    var e, t, n = this;
                    this.isDestroyed || this.isDestroying || this.parentView && !this.parentView.get("isOpen") || null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isConversationsLoaded && Ember.run.later(function() {
                        (0, i.Z)(this, n), this.channelEnter()
                    }.bind(this), 1)
                },
                updateUnrepliedFlowMsgs: function() {
                    var e = this,
                        t = this.messages && this.messages.filter(function(t) {
                            return (0, i.Z)(this, e), t.flowId && !t.messageId && !t.hasBeenRepliedTo
                        }.bind(this));
                    this.session && this.session.user && this.session.user.alias && !this.messagesCountWithMessageId && t.forEach(function(t) {
                        (0, i.Z)(this, e), Ember.set(t, "needsUpdation", !1)
                    }.bind(this))
                },
                channelEnter: function() {
                    var e = this;
                    if (this.hasUnrepliedFlowMessages)
                        if (this.canTriggerFlow()) this.triggerChannelEnter();
                        else {
                            var t, n = this.messages && this.messages.filter(function(t) {
                                return (0, i.Z)(this, e), t.flowId && !t.messageId && !t.hasBeenRepliedTo
                            }.bind(this));
                            this.widgetInitFeatureEnabled ? this.triggerChannelEnter() : n.lastObject.autoRuleId || (null === (t = this.channelInfo) || void 0 === t ? void 0 : t.flowId) === n.firstObject.flowId ? this.updateUnrepliedFlowMsgs() : this.triggerChannelEnter()
                        }
                    else if (this.isOngoingConversation);
                    else if (this.hasUnrepliedOfflineMessage || !this.messagesCountWithMessageId) this.triggerChannelEnter();
                    else if (this.currentConversationStatus === s.default.CONVERSATION.CONVERSATION_STATUS.RESOLVED) {
                        var o, l;
                        !(0, a.isHideResolvedConversationEnabled)(null === (o = this.hotlineUI) || void 0 === o ? void 0 : o.config) || null !== (l = this.conversation) && void 0 !== l && l.hasPendingCsat || this.conversation.deleteMessages(), this.triggerChannelEnter()
                    } else this.isAwayExperienceEligible() && (this.hasUnrepliedOfflineMessage && this.removelastOfflineMessage(), this.showAwayExperience());
                    this.isConversationTestingEnabled && this.removeResolveReopenConversation(), this.unreadCount ? this.scrollToFirstNewMessage() : this.scrollToBottom(), this.set("hasFirstUserMessageBeenSent", !1)
                },
                triggerChannelEnter: function() {
                    var e, t, n, i, o, a = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.enabledFeatures) || void 0 === i ? void 0 : i.indexOf(s.default.unifedBotBuilderEnabled);
                    if (this.hasUnrepliedFlowMessages) {
                        var l = this.unrepliedFlowMessages.firstObject && this.unrepliedFlowMessages.firstObject.autoRuleId;
                        this.removeBotMessages(l)
                    }
                    if (this.hasUnrepliedOfflineMessage && this.removelastOfflineMessage(), this.isAwayExperienceEligible()) this.showAwayExperience();
                    else if (this.channelInfo && null !== (o = this.channelInfo) && void 0 !== o && o.flowId && this.canShowChannelFlowForBusinessHourSetting) {
                        var r;
                        if (this.isFdInitiatedWidget() && -1 === a || this.isParallelConversationResolved || this.currentConversationStatus === s.default.CONVERSATION.CONVERSATION_STATUS.RESOLVED && null !== (r = this.conversation) && void 0 !== r && r.hasPendingCsat) return;
                        this.triggerChannelFlow()
                    }
                },
                triggerChannelFlow: function() {
                    var e, t, n = this,
                        o = null === (e = this.channelInfo) || void 0 === e ? void 0 : e.flowMessages,
                        l = null === (t = this.channelInfo) || void 0 === t ? void 0 : t.serviceAccount,
                        r = !this.messagesCount;
                    if (this.widgetInitFeatureEnabled) {
                        var u;
                        Ember.set(this, "isDynamicFlowLoading", !0);
                        var c = s.default.EmberModelUrl.dynamicFlow.url.replace("{token}", null === (u = this.session) || void 0 === u ? void 0 : u.token).replace("{channelAlias}", this.channelInfo.channelAlias);
                        this.axios.makeRequest({
                            method: "POST",
                            url: c,
                            dataType: "json",
                            contentType: "application/json"
                        }).then(function(e) {
                            var t = this;
                            (0, i.Z)(this, n), e.data && (Ember.set(this, "isDynamicFlowLoading", !1), e.data.flowMessages.forEach(function(n) {
                                (0, i.Z)(this, t), this.send("updateMessage", {
                                    flowId: e.data.flowId,
                                    flowVersionId: e.data.flowVersionId,
                                    campaignMessageId: n.campaignMessageId,
                                    flowStepId: n.flowStepId,
                                    actions: n.actions,
                                    hasBeenRepliedTo: !1,
                                    needsUpdation: this.getNeedUpdationValue(n),
                                    messageFragments: n.messageFragments,
                                    replyFragments: n.replyFragments,
                                    messageUserName: l.firstName,
                                    userFirstName: l.firstName,
                                    messageUserType: 1,
                                    internalMeta: n.internalMeta,
                                    messageType: n.messageType || this.freddyMessageType,
                                    messageUserId: l.id,
                                    messageUserAlias: l.alias,
                                    read: !1,
                                    createdMillis: (new Date).getTime(),
                                    messageUserProfilePic: l.profilePicUrl
                                })
                            }.bind(this)))
                        }.bind(this)).catch(function(e) {
                            (0, i.Z)(this, n), this.logger.log(e)
                        }.bind(this))
                    } else if (o) {
                        var d;
                        o.forEach(function(e) {
                            var t, o;
                            (0, i.Z)(this, n);
                            var s, a = e.messageFragments,
                                r = e.placeholderMeta;
                            (Ember.set(this, "isDynamicFlowLoading", !1), r) && this.updatePlaceholders(a, r, null === (s = this.channelInfo) || void 0 === s ? void 0 : s.flowId);
                            this.send("updateMessage", {
                                flowId: null === (t = this.channelInfo) || void 0 === t ? void 0 : t.flowId,
                                flowVersionId: null === (o = this.channelInfo) || void 0 === o ? void 0 : o.flowVersionId,
                                campaignMessageId: e.campaignMessageId,
                                flowStepId: e.flowStepId,
                                actions: e.actions,
                                hasBeenRepliedTo: !1,
                                needsUpdation: this.getNeedUpdationValue(e),
                                messageFragments: e.messageFragments,
                                replyFragments: e.replyFragments,
                                messageUserName: l.firstName,
                                userFirstName: l.firstName,
                                messageUserType: 1,
                                internalMeta: e.internalMeta,
                                messageType: e.messageType || this.freddyMessageType,
                                messageUserId: l.id,
                                messageUserAlias: l.alias,
                                read: !1,
                                createdMillis: (new Date).getTime(),
                                messageUserProfilePic: l.profilePicUrl
                            })
                        }.bind(this)), (0, a.canHideConversation)(this.conversation, null === (d = this.hotlineUI) || void 0 === d ? void 0 : d.config) && r && this.conversation.set("readMillis", this.conversation.messages.lastObject.createdMillis)
                    }
                },
                offlineExperienceEnabledChannel: Ember.computed("model.offlineExperience.channelIds.[]", "channel.channelId", {
                    get: function() {
                        var e, t, n, i = null === (e = this.model) || void 0 === e || null === (t = e.offlineExperience) || void 0 === t ? void 0 : t.channelIds,
                            o = null === (n = this.channel) || void 0 === n ? void 0 : n.channelId;
                        return i && i.find((function(e) {
                            return e === o
                        }))
                    }
                }),
                isChannelOutsideBusinessHour: Ember.computed("hotline.ui.awayMessage", "channel.operatingHoursId", {
                    get: function() {
                        var e, t, n, i = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.awayMessage,
                            o = null === (n = this.channel) || void 0 === n ? void 0 : n.operatingHoursId,
                            s = i && i.findBy("operatingHoursId", o);
                        return (!s || s && !s.enabled) && (s = i && i.findBy("defaultBhr", !0)), s && s.awayMessage
                    }
                }),
                triggerInConversationAwayExperiance: Ember.observer("isChannelOffline", "lastAgentMessage.createdMillis", "conversation.hasPendingCsat", (function() {
                    var e, t = this;
                    if (!this.isAwayExperienceEligible() || this.lastAgentMessage && !this.conversationService.isLastAgentMessageTimeExceeded(this.lastAgentMessage.createdMillis)) {
                        if (!this.isChannelOffline && null !== (e = this.lastAgentMessage) && void 0 !== e && e.offlineMessage) {
                            var n, o, s = null === (n = this.conversation) || void 0 === n ? void 0 : n.get("messages").toArray(),
                                a = s.find(function(e) {
                                    return (0, i.Z)(this, t), e.offlineMessage && !1 === e.hasBeenRepliedToOffline
                                }.bind(this));
                            s.removeObject(a), null == a || a.destroyRecord(), this.conversation.set("messages", s), null === (o = this.localds) || void 0 === o || o.save()
                        }
                    } else Ember.run.once(this, "showAwayExperience")
                })),
                showAwayExperience: function() {
                    var e, t, n, i, o, s = null === (e = this.model) || void 0 === e || null === (t = e.offlineExperience) || void 0 === t || null === (n = t.awayMessage) || void 0 === n ? void 0 : n.messageFragments,
                        a = null === (i = this.CONVERSATION) || void 0 === i || null === (o = i.MESSAGE_SOURCE) || void 0 === o ? void 0 : o.OFFLINE;
                    this.send("updateMessage", {
                        messageFragments: s,
                        messageUserType: 1,
                        messageType: 1,
                        read: !1,
                        needsUpdation: !0,
                        source: a,
                        createdMillis: (new Date).getTime(),
                        offlineMessage: !0,
                        hasBeenRepliedToOffline: !1
                    })
                },
                createText: function(e) {
                    var t = document.createElement("p");
                    t.innerHTML = "\r\n" === e || "\n" === e ? "<br>" : e, this.insertContentToEditor(t), this.set("height", this.element.offsetHeight)
                },
                channelEventReminder: Ember.computed("upcomingCalendarEventMessage", {
                    get: function() {
                        var e = this.upcomingCalendarEventMessage;
                        if (e) {
                            var t = e.internalMeta && e.internalMeta.calendarMessageMeta && e.internalMeta.calendarMessageMeta.calendarEventLink,
                                n = e.messageFragments && e.messageFragments[0],
                                i = n && n.startMillis;
                            return {
                                eventLink: t,
                                eventDateTime: i && (0, p.default)(i).format("LLL")
                            }
                        }
                        return null
                    }
                }),
                insertContentToEditor: function(e) {
                    var t = document.getElementById(this.DOM_ID.appConversationEditor);
                    t && e && t.appendChild(e)
                },
                prepopulateText: Ember.observer("hotline.ui.channelReplyText", (function() {
                    var e, t, n, o, s = this,
                        a = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.channelReplyText,
                        l = null === (n = this.hotline) || void 0 === n || null === (o = n.ui) || void 0 === o ? void 0 : o.channelSendMessage;
                    a && (this.emptyContentEditor(), this.set("height", this.element.offsetHeight), this.createText(a), this.set("editorHasContent", !0), this.set("hotline.ui.channelReplyText", null), Ember.run.later(this, function() {
                        (0, i.Z)(this, s), this.set("editorHasContent", !1)
                    }.bind(this)), l ? (this.set("hotline.ui.channelSendMessage", !1), this.send("beforeSendMessage")) : (this.set("hotline.ui.isChannelReplyText", !0), this.isSingleChannel || this.focusPrePopulateText(this))), this.hotline.ui.isDesktop || (this.hotline.ui.isChannelReplyText ? this.set("isValueInEditor", !0) : this.set("isValueInEditor", !1))
                })),
                isCompact: Ember.computed({
                    get: function() {
                        var e, t, n, i, o;
                        return "small" === (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.appearanceConfig) || void 0 === i || null === (o = i.widgetSize) || void 0 === o ? void 0 : o.toLowerCase())
                    }
                }),
                didAuthUserCB: Ember.computed("didAuthenticateUser", {
                    get: function() {
                        return this.didAuthenticateUser.bind(this)
                    }
                }),
                conversationsLoadedEventCB: Ember.computed("beforeChannelEnter", {
                    get: function() {
                        return this.beforeChannelEnter.bind(this)
                    }
                }),
                didAuthenticateUser: function() {
                    var e, t;
                    if (!this.hasUserToCreate || this.isJwtExpired() || null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.alias || this.localStorage.getItemLS("isUserCreateSent") || this.send("createNewUser"), this.jwt.auth.expired) this.disableReplyContainer(), this.send("updateMessageAsNotAuthenticated");
                    else if (this.jwt.auth.expiredAt || this.jwt.auth.scheduled) this.enableReplyContainer();
                    else if (this.jwt.auth.user) {
                        var n, i, o, s;
                        if (this.enableReplyContainer(), null !== (n = this.hotline) && void 0 !== n && null !== (i = n.ui) && void 0 !== i && i.offlineMessagesFragments) this.send("sendOfflineMessages", null === (o = this.hotline) || void 0 === o || null === (s = o.ui) || void 0 === s ? void 0 : s.offlineMessagesFragments), this.set("hotline.ui.offlineMessagesFragments", null);
                        this.send("updateMessageAsPending"), this.send("sendPendingMessagesAfterAuthenticated")
                    }
                },
                userHeader: function(e) {
                    this.set("isFocusInput", e), e ? (0, m.addCSSInline)(this.element.querySelector(".fc-agent-profile"), "display", "none") : (0, m.addCSSInline)(this.element.querySelector(".fc-agent-profile"), "display", "block")
                },
                didUpdate: function() {
                    this._super.apply(this, arguments);
                    var e = document.querySelector(".h-reply-smiley");
                    e && ((0, m.bindEvent)(document, "selectionchange", this.setSelectionCallback), this.set("appConversationEditorNode", document.getElementById(this.DOM_ID.appConversationEditor)))
                },
                clearPrivacyPolicy: function() {
                    this.showPrivacyPolicy && (Ember.set(this, "showPrivacyPolicy", !1), this.updateConversationElement(!1), !this.localStorage.getItemLS("isPrivacyPolicyShown") && this.localStorage.setItemLS("isPrivacyPolicyShown", !0))
                },
                updateConversationElement: function() {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        t = document.querySelector(".fc-app-conversation-message"),
                        n = document.querySelector(".privacy-policy-container");
                    n && t && (e ? t.style.marginTop = "".concat(n.offsetHeight, "px") : t.style.removeProperty("margin-top"))
                },
                didInsertElement: function() {
                    var e, t, n, o, s = this;
                    this._super.apply(this, arguments);
                    var a = document.querySelector(".h-reply-smiley");
                    if (a && ((0, m.bindEvent)(document, "selectionchange", this.setSelectionCallback), this.set("appConversationEditorNode", document.getElementById(this.DOM_ID.appConversationEditor))), Ember.addListener(this.botActionEvents, "botActionEvent", this.botEventCB), Ember.addListener(this.hotline, "conversationsLoadedEvent", this.conversationsLoadedEventCB), Ember.addListener(this.rts, "didRTSMessage", this.onRTSMessageCB), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB), Ember.run.scheduleOnce("afterRender", this, this.renderFunction), (0, m.bindEvent)(this.element.querySelector(".scroll-section"), "scroll", this.scrollCallback), null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || !t.isDesktop) {
                        (0, m.bindEvent)(this.element.querySelector("#app-conversation-editor"), "focus", function() {
                            (0, i.Z)(this, s), this.userHeader(!0)
                        }.bind(this)), (0, m.bindEvent)(this.element.querySelector("#app-conversation-editor"), "blur", function() {
                            (0, i.Z)(this, s), this.userHeader(!1)
                        }.bind(this));
                        var l = window.outerHeight;
                        (0, m.bindEvent)(window, "resize", function() {
                            (0, i.Z)(this, s), this.userHeader(window.outerHeight !== l)
                        }.bind(this))
                    }
                    var r = null === (n = this.hotline) || void 0 === n || null === (o = n.ui) || void 0 === o ? void 0 : o.parallelConversationId;
                    !r || this.conversation && this.conversation.conversationId || this.getMessages.perform("", !1, !1, r), Ember.run.later(function() {
                        (0, i.Z)(this, s);
                        var e = document.querySelector(".custom-reply-composer div.h-reply-dropdown div.select-box-trigger"),
                            t = document.querySelector(".custom-message-wrapper");
                        t && !e && t.focus()
                    }.bind(this), 100)
                },
                setSelectionForTextInEditor: function(e) {
                    if (this.appConversationEditorNode && e.target.activeElement.isSameNode(this.appConversationEditorNode)) {
                        var t = window.getSelection();
                        Ember.setProperties(this, {
                            sel: t,
                            range: t.getRangeAt(0)
                        })
                    }
                },
                renderFunction: function() {
                    !this.unreadCount && this.scrollToBottom(), this.send("toggleView", this), "phone" !== this.hotline.device() && this.focusOnTextarea(), this.prepopulateText()
                },
                willMessageSent: function() {
                    this.lastMessage && this.lastMessage.messageUserType === s.default.CONVERSATION.USER_TYPE.USER && this.send("scrollToRecentMessages")
                },
                getMessages: (0, w.task)(regeneratorRuntime.mark((function e() {
                    var t, n, o, l, r, u, c, d, p, h, f, m, v, b, y, w, E, T, C, S, O, M, I = this,
                        k = arguments;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return l = k.length > 0 && void 0 !== k[0] ? k[0] : "", r = !(k.length > 1 && void 0 !== k[1]) || k[1], u = k.length > 2 && void 0 !== k[2] && k[2], c = k.length > 3 && void 0 !== k[3] ? k[3] : "", d = s.default.EmberModelUrl, p = d.conversations, h = this.session, f = h && h.user, m = h && h.siteId, v = f && f.alias, b = h && h.token, y = this.notification, w = this.localds, E = w && w.get("messageAfter"), T = {
                                    src: s.default.CONVERSATION.FETCH.USER_CREATED,
                                    limit: s.default.CONVERSATION.LIMIT
                                }, C = p.url.replace("{token}", b).replace("{userAlias}", v), S = document.getElementsByClassName("h-conv-chat")[0], E && (T.messageAfter = E), (M = null === (t = this.hotline) || void 0 === t || null === (n = t.ui) || void 0 === n ? void 0 : n.conversationReferenceId) && (T.conversationReferenceId = M), u && (T.conversationId = l, T.messageBefore = this.messages.objectAt(0).createdMillis, T.messageAfter = 0, O = S.scrollHeight, this.set("isLoadingOldMessages", !0), this.isParallelConversationEnabled && (T.isParallelConversation = !0)), c && (T.conversationId = c, T.messageBefore = (new Date).getTime(), T.messageAfter = 0, T.isParallelConversation = !0), T.hideResolvedConversation = (0, a.isHideResolvedConversationEnabled)(null === (o = this.hotlineUI) || void 0 === o ? void 0 : o.config), m && (C = (0, g.addQueryParams)(C, {
                                    siteId: m
                                })), e.next = 14, this.store.getRequest(p.model, C, T).then(function(e) {
                                    var t = this;
                                    if ((0, i.Z)(this, I), e || !e.errorCode) {
                                        var n, o;
                                        if (e && e.conversations && (n = M ? e.conversations.filter(function(e) {
                                                return (0, i.Z)(this, t), e.channelId === this.channelId
                                            }.bind(this)) : e.conversations[0]), o = n && n.messages)
                                            if (u)
                                                for (var s = o.length - 1; s >= 0; s--) this.send("updateMessage", o[s]);
                                            else
                                                for (var a = 0, l = o.length; a < l; a++) this.send("updateMessage", o[a]);
                                        u && (Ember.run.later(this, (function() {
                                            S.scrollTop = S.scrollHeight - O
                                        }), 0), (Ember.isEmpty(o) || o.length < 100) && this.set("isLoadedAllOlderMessages", !0)), r && y.playSound()
                                    }
                                }.bind(this)).finally(function() {
                                    (0, i.Z)(this, I), this.set("isOldConvRequestPending", !1)
                                }.bind(this));
                            case 14:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))).enqueue(),
                handleSmartPollingCallback: function(e) {
                    this.loadConversation(e), this.smartPolling.clearSmartPoll()
                },
                didMessageSent: function() {
                    var e, t, n = null === (e = this.hotlineUI) || void 0 === e || null === (t = e.config) || void 0 === t ? void 0 : t.betaFeatures;
                    this.doesUserExists || (this.set("doesUserExists", !0), this.getMessages.perform()), this.parentView && !this.parentView.get("isOpen") && this.parentView.send("toggleChat", this), n[s.default.smartPollingBetaFeature] && !this.isLastAgentMessageFromBot & !this.isChannelOutsideBusinessHour && this.hotline.ui.onLine && this.smartPolling.startSmartPoll(this.handleSmartPollingCallback.bind(this))
                },
                init: function() {
                    this._super.apply(this, arguments), this.setTimer = null, Ember.set(this, "showCustomReplyOptions", !1), Ember.set(this, "setSelectionCallback", this.setSelectionForTextInEditor.bind(this)), this.beforeChannelEnter(), void 0 === this.localStorage.getItemLS("isPrivacyPolicyShown") && this.localStorage.setItemLS("isPivacyPolicyShown", !1), this.managePrivacyPolicy()
                },
                hideCustomReplyOptions: Ember.computed.not("showCustomReplyOptions"),
                displayUnreadToastBubble: Ember.computed.and("showUnreadToast", "hideCustomReplyOptions"),
                scrollToBottom: function() {
                    var e = this,
                        t = document.querySelectorAll(".body .h-chat-window .h-conv-chat");
                    t && t.length && (b.default.scrollTo(t[0], t[t.length - 1].scrollHeight, 1), clearTimeout(this.setTimer), this.setTimer = setTimeout(function() {
                        (0, i.Z)(this, e), b.default.scrollTo(t[0], t[t.length - 1].scrollHeight, 100)
                    }.bind(this), 1e3))
                },
                scrollToFirstNewMessage: function() {
                    var e = document.getElementById("newMessage");
                    null == e || e.scrollIntoView()
                },
                focusOnTextarea: function() {
                    var e = this;
                    this.element.querySelector(".editable") ? this.focusTextArea() : Ember.run.later(this, function() {
                        (0, i.Z)(this, e), this.focusTextArea()
                    }.bind(this), 0)
                },
                focusTextArea: function() {
                    if (this.element) {
                        var e = document.createRange(),
                            t = window.getSelection(),
                            n = this.element.querySelector(".editable p:last-child");
                        if (n && n[0]) e.setStart(n[0], 1), e.collapse(!0), t.removeAllRanges(), t.addRange(e);
                        else if (this.isJWTStrictMode && this.jwt.auth.expired);
                        else {
                            var i = this.element.querySelector(".editable"),
                                o = this.lastMessage;
                            i && !this.focusAfterOfflineMessage && o && !o.get("offlineMessage") && (this.focusAfterOfflineMessage = !0), i && i.focus()
                        }
                    }
                },
                disableReplyContainer: function() {
                    var e = this.element.querySelector(".editable"),
                        t = this.element.querySelector(".away-experience-form");
                    window.getSelection().removeAllRanges(), (0, m.addCSSInline)(this.element.querySelector(".h-reply"), "pointer-events", "none"), e && (e.blur(), (0, m.addCSSInline)(e, "background-color", "grey"), (0, m.addCSSInline)(e, "pointer-events", "none")), t && (t.blur(), (0, m.addCSSInline)(t, "pointer-events", "none"))
                },
                enableReplyContainer: function() {
                    var e = this.element.querySelector(".editable"),
                        t = this.element.querySelector(".away-experience-form");
                    (0, m.addCSSInline)(this.element.querySelector(".h-reply"), "pointer-events", "auto"), e && ((0, m.addCSSInline)(e, "background-color", ""), (0, m.addCSSInline)(e, "pointer-events", "auto"), e.focus()), t && (0, m.addCSSInline)(t, "pointer-events", "auto")
                },
                replaceWithResponseTime: function(e, t) {
                    return e = (e = e.replace("{{time}}", t)).replace("{!time!}", t)
                },
                calculatePosition: function(e, t) {
                    var n = document.getElementsByClassName("fc-emoji-picker ")[0],
                        i = e.getBoundingClientRect(),
                        o = i.top,
                        s = i.left,
                        a = i.width,
                        l = document.getElementsByTagName("body")[0],
                        r = s + e.parentElement.offsetWidth - n.offsetWidth,
                        u = {
                            width: a,
                            top: o - 10
                        };
                    return "rtl" === l.getAttribute("dir") ? u.right = r : u.left = s - n.offsetWidth / 1.22, {
                        style: u
                    }
                },
                getScrollDistanceFromBottom: function() {
                    var e = document.getElementsByClassName("h-conv-chat")[0],
                        t = 0;
                    return e && (t = e.scrollHeight - (e.scrollTop + e.clientHeight)), t
                },
                unreadChanged: (0, w.task)(regeneratorRuntime.mark((function e() {
                    var t, n = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, (0, w.waitForProperty)(this, "unreadCount", function(e) {
                                    return (0, i.Z)(this, n), e > 0
                                }.bind(this));
                            case 2:
                                t = e.sent, this.parentView && this.parentView.get("isOpen") && Ember.run.later(function() {
                                    if ((0, i.Z)(this, n), t) {
                                        var e, o = document.getElementsByClassName("h-conv-chat")[0],
                                            s = this.isCarouselMessage(null === (e = this.lastAgentMessage) || void 0 === e ? void 0 : e.replyFragments);
                                        o && o.scrollHeight <= o.clientHeight + 30 ? this.resetUnreadCount() : !s && this.getScrollDistanceFromBottom() > 300 ? (this.set("showUnreadToast", !0), this.set("showCustomReplyOptions", !1)) : this.hasFirstUserMessageBeenSent && this.scrollToBottom()
                                    }
                                }.bind(this));
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))).on("didRender"),
                resetUnreadCount: function() {
                    Ember.set(this, "unreadCount", 0), this.send("updateReadReceipt"), this.set("showUnreadToast", !1)
                },
                botActionEventCB: function(e) {
                    var t = e.name,
                        n = e.data,
                        i = s.default.BOT_ACTIONS,
                        o = s.default.WIDGET_OPEN_MSG;
                    if (t === i.HIDE_WIDGET) this.parentView.send("triggerShowHide", !1);
                    else if (t === i.MINIMIZE_WIDGET && this.parentView.get("isOpen")) this.parentView.send("toggleChat");
                    else if (t === i.SEND_AS_CUSTOMER_MESSAGE) this.sendMessageToBot(n.message);
                    else if (t === i.TRIGGER_JS_FUNCTION) this.sendMessageToBot(n.message, {
                        isBotsPrivate: !0,
                        channelId: n.channelId
                    });
                    else if (t === i.WIDGET_OPENED) {
                        var a = {
                            isBotsPrivate: !0
                        };
                        this.enabledBetaFeatures[s.default.widgetReOpenEvent] && (a = {
                            isWidgetOpenEvent: !0,
                            messageType: s.default.CONVERSATION.MESSAGE_TYPE.BOT_REOPENED
                        }), this.sendMessageToBot(o, a)
                    }
                    this.localds.save()
                },
                actions: {
                    onTimePickerKeyDown: function(e) {
                        this.onKeyPressDefault(e)
                    },
                    menuPosition: function() {
                        return {
                            style: this.isCompact ? {
                                top: "9%",
                                left: "21%",
                                width: "230px"
                            } : {
                                top: "7%",
                                left: "21%"
                            }
                        }
                    },
                    setNextFocus: function() {
                        var e = document.querySelector(".fc-carousel"),
                            t = document.querySelector(".fc_web_modal");
                        event && event.keyCode === s.default.KEYCODES.TAB && !event.shiftKey && e && !t && (event.preventDefault(), e.focus())
                    },
                    emojiKeyboardEvent: function(e) {
                        y.default.hideDropDownOnFocusOut(event, e, this, ".h-reply-smiley"), y.default.changeFocusOnArrowKeyPress(event, e, {
                            sourceElem: ".input__search",
                            optionsSelector: ".fc-emoji-picker-emoji",
                            scrollContainer: ".fc-emoji-picker__body",
                            arrowTypes: "left-right",
                            isDropDown: !0
                        })
                    },
                    setAriaSelected: function() {
                        var e = document.querySelector('.fc-emoji-picker-emoji[aria-selected="true"]');
                        event.target && (e && e.setAttribute("aria-selected", !1), event.target.classList.contains("fc-emoji-picker-emoji") ? event.target.setAttribute("aria-selected", !0) : event.target.parentElement && event.target.parentElement.classList.contains("fc-emoji-picker-emoji") && event.target.parentElement.setAttribute("aria-selected", !0))
                    },
                    setIsTextLimitExceeded: function(e) {
                        this.set("isTextLimitExceeded", e)
                    },
                    hasValueInEditor: function(e) {
                        this.set("isValueInEditor", e)
                    },
                    toggleProfileSize: function() {
                        this.hideBio || this.toggleProperty("isAgentProfileExpand")
                    },
                    onOpen: function() {
                        var e = this;
                        this.beforeChannelEnter(), setTimeout(function() {
                            (0, i.Z)(this, e), document.querySelector(".resize-fragments") && this.send("resizeChatWindow"), this.setFocus(), this.updateConversationElement(), this.hotline.ui.isChannelReplyText && this.focusPrePopulateText(this)
                        }.bind(this), this.transitionDelays)
                    },
                    toggleView: function(e) {
                        this.parentView && this.parentView.send("updateView", e)
                    },
                    toggleBack: function() {
                        var e = this;
                        this.model.isRoutedFromHistory ? this.gotoHome(this.model.isRoutedFromHistory, this.model.fromPage) : Ember.run.later(function() {
                            (0, i.Z)(this, e), this.send("toggleView", void 0), this.gotoHome(), y.default.moveFocusTo(".hotline-launcher")
                        }.bind(this), 0)
                    },
                    sendButtonMessage: function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                            i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
                        y.default.moveFocusTo("#app-conversation-editor"), this.send("resizeChatWindow", !0), this.send("beforeSendMessage", e, t, n, i)
                    },
                    setIntlPhoneInput: function(e) {
                        Ember.set(this, "intlPhoneInput", e)
                    },
                    resizeChatWindow: function(e) {
                        var t, n = document.querySelector(".h-chat-window"),
                            i = null === (t = document.querySelector(".custom-reply-composer")) || void 0 === t ? void 0 : t.offsetHeight,
                            o = n.style;
                        Ember.isEmpty(i) || e || !i ? (Ember.set(this, "showCustomReplyOptions", !1), o.removeProperty("height")) : (Ember.set(this, "showCustomReplyOptions", !0), o.height = "calc(100% - " + i + "px)")
                    },
                    sendMessageFromMobile: function() {
                        this.set("isValueInEditor", !1);
                        var e = this.element.querySelector("#app-conversation-editor");
                        e.blur(), this.send("beforeSendMessage")
                    },
                    sendOfflineMessage: function(e) {
                        this.send("sendOfflineMessages", e)
                    },
                    openCalendarPickerMaximized: function(e) {
                        Ember.setProperties(this, {
                            slotsData: e && e.slotsData,
                            meetingLength: e && e.meetingLength,
                            showCalPicker: !0,
                            calendarMessage: e && e.message
                        })
                    },
                    closeCalendarPicker: function() {
                        this.set("showCalPicker", !1), y.default.moveFocusTo(".calendar-picker-minified")
                    },
                    openConfirmationScreenForCalPicker: function(e, t) {
                        Ember.set(t, "internalMeta.meetingStartTime", e && e.from), this.send("closeCalendarPicker")
                    },
                    setConfig: function(e) {
                        var t = e.actions;
                        this.set("dropdownActions", t)
                    },
                    updateEditorContent: function(e) {
                        var t, n = this,
                            o = document.getElementById(this.DOM_ID.appConversationEditor),
                            s = e,
                            a = this.sel,
                            l = this.range;
                        if (a.rangeCount >= 0) {
                            var r = l.startContainer,
                                u = l.startOffset,
                                c = l.cloneRange(),
                                d = document.createTextNode(s),
                                p = document.createTextNode("");
                            c.collapse(!1), c.insertNode(p), c.setStart(r, u), c.collapse(!0), c.insertNode(d), l.setStartAfter(d), l.setEndBefore(p), a.removeAllRanges(), a.addRange(l)
                        }
                        setTimeout(function() {
                            (0, i.Z)(this, n), o.focus()
                        }.bind(this)), null === (t = this.dropdownActions) || void 0 === t || t.close()
                    },
                    fetchOlderMessages: function() {
                        var e, t = null === (e = this.conversation) || void 0 === e ? void 0 : e.conversationId;
                        this.isOldConvRequestPending || this.isLoadedAllOlderMessages || !t || t < 0 || 0 === this.messagesCount ? this.logger.log("Message lazy loading cancelled.") : (this.set("isOldConvRequestPending", !0), y.default.readOutDynamicUpdates(this.intl.t("aria_labels.loading_past_conv")), this.getMessages.perform(t, !1, !0))
                    },
                    scrollToRecentMessages: function() {
                        this.scrollToBottom(), this.resetUnreadCount()
                    },
                    focusTextEditor: function() {
                        this.focusAfterOfflineMessage || (this.focusAfterOfflineMessage = !0, this.send("focusIn"))
                    }
                }
            })
        },
        34835: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return Y
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h, f, m, g, v, b, y, w, E, T, C, S = n(35235),
                O = n(10935),
                M = n(34645),
                I = n(5660),
                k = n(69049),
                _ = n(28433),
                A = n(58678),
                P = n(55411),
                R = n(79833),
                D = n(52626),
                N = n(13256),
                Z = n(18006),
                x = n(85853),
                B = n(13418),
                F = n(50660),
                L = n(62766),
                U = n(22126),
                V = n(79956),
                j = n(70387),
                H = n(22342);

            function q(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function z(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? q(Object(n), !0).forEach((function(t) {
                        (0, D.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : q(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function G(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, R.Z)(e);
                    if (t) {
                        var o = (0, R.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, P.Z)(this, n)
                }
            }
            var Y = (i = (0, Z.tagName)(""), o = Ember.inject.service("post-message"), s = Ember.computed.or("showCsat", "feedbackSubmitted"), a = Ember.computed("paramsOfPendingCsat.{flag,cross}"), l = Ember.computed("allowCsatSubmit", "csatRatings.comment"), r = Ember.computed("allowCsatSubmit", "csatRatings.star"), u = Ember.computed("session.config.content.placeholders.csat_reply"), c = Ember.computed, d = (0, x.observes)("rating_value"), p = Ember.computed("conversation.hasPendingCsat"), h = Ember.computed, f = Ember._action, m = Ember._action, g = Ember._action, v = Ember._action, b = Ember._action, y = Ember._action, i((E = function(e) {
                (0, A.Z)(n, e);
                var t = G(n);

                function n() {
                    var e;
                    (0, M.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, O.Z)((0, k.Z)(e), "postMessage", T, (0, k.Z)(e)), (0, D.Z)((0, k.Z)(e), "feedbackSubmitted", !1), (0, D.Z)((0, k.Z)(e), "allowCsatSubmit", !0), (0, D.Z)((0, k.Z)(e), "disableCsatVoting", !1), (0, D.Z)((0, k.Z)(e), "csatTimer", null), (0, O.Z)((0, k.Z)(e), "showCsatForm", C, (0, k.Z)(e)), e
                }
                return (0, I.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, _.Z)((0, R.Z)(n.prototype), "init", this).apply(this, arguments), Ember.set(this, "paramsOfPendingCsat", {
                            flag: null,
                            cross: null
                        })
                    }
                }, {
                    key: "isJwtAuthInProgressing",
                    get: function() {
                        var e, t;
                        return null != (null === (e = this.paramsOfPendingCsat) || void 0 === e ? void 0 : e.flag) && null != (null === (t = this.paramsOfPendingCsat) || void 0 === t ? void 0 : t.cross)
                    }
                }, {
                    key: "enableSubmitButtonForResolvedConversationNo",
                    get: function() {
                        var e;
                        return this.allowCsatSubmit && !Ember.isBlank(null === (e = this.csatRatings) || void 0 === e ? void 0 : e.comment)
                    }
                }, {
                    key: "enableSubmitButtonForResolvedConversationYes",
                    get: function() {
                        var e;
                        return this.allowCsatSubmit && (null === (e = this.csatRatings) || void 0 === e ? void 0 : e.star) > 0
                    }
                }, {
                    key: "csatComments",
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.session) || void 0 === e || null === (t = e.config) || void 0 === t || null === (n = t.content) || void 0 === n || null === (i = n.placeholders) || void 0 === i ? void 0 : i.csat_reply) || this.intl.t("csat.enter_comments")
                    }
                }, {
                    key: "csatRatings",
                    get: function() {
                        return this.store.createRecord("csatValues", {
                            star: 0,
                            comment: ""
                        })
                    }
                }, {
                    key: "ratingObserve",
                    value: function() {
                        var e = this.csatRatings,
                            t = this.rating_value;
                        Ember.set(e, "star", t)
                    }
                }, {
                    key: "showCsat",
                    get: function() {
                        var e, t, n, i, o = this,
                            s = this.conversation,
                            a = s && s.get("hasPendingCsat"),
                            l = null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.config,
                            r = l && l.csatSettings,
                            u = s && s.get("csat"),
                            c = r && r.userCsatViewTimer,
                            d = r && r.maximumUserSurveyViewMillis,
                            p = u && u.get("initiated"),
                            h = (new Date).getTime(),
                            f = u && a ? p + d - h : 0,
                            m = null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.conversationReferenceId;
                        return this.resetCsat(), c ? f > 0 ? (a && (this.csatTimer = Ember.run.later(function() {
                            (0, S.Z)(this, o), this.resetCsat(), Ember.set(s, "hasPendingCsat", !1)
                        }.bind(this), f), this.postMessage.post({
                            action: "csat_received",
                            status: 200,
                            success: !0,
                            data: z({
                                csatId: u.get("csatId")
                            }, m && {
                                conversationReferenceId: m
                            })
                        }), j.default.moveFocusTo(".csat-rating")), a) : (s && (Ember.set(s, "hasPendingCsat", !1), Ember.set(s, "csat", null), this.send("save")), !1) : (a && (this.postMessage.post({
                            action: "csat_received",
                            status: 200,
                            success: !0,
                            data: z({
                                csatId: u.get("csatId")
                            }, m && {
                                conversationReferenceId: m
                            })
                        }), j.default.moveFocusTo(".csat-rating")), a)
                    }
                }, {
                    key: "didInsertElement",
                    value: function() {
                        (0, _.Z)((0, R.Z)(n.prototype), "didInsertElement", this).apply(this, arguments), this.isJWTStrictMode && Ember.addListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB)
                    }
                }, {
                    key: "willDestroyElement",
                    value: function() {
                        (0, _.Z)((0, R.Z)(n.prototype), "willDestroyElement", this).apply(this, arguments), this.isJWTStrictMode && Ember.removeListener(this.jwt, "didAuthenticateUser", this.didAuthUserCB)
                    }
                }, {
                    key: "didAuthUserCB",
                    get: function() {
                        return this.didAuthenticateUser.bind(this)
                    }
                }, {
                    key: "didAuthenticateUser",
                    value: function() {
                        if (this.set("disableCsatVoting", !this.jwt.auth.user), this.isJwtAuthInProgressing) {
                            var e, t;
                            if (this.jwt.auth.user) this.send("submitCsatRating", null === (e = this.paramsOfPendingCsat) || void 0 === e ? void 0 : e.flag, null === (t = this.paramsOfPendingCsat) || void 0 === t ? void 0 : t.cross);
                            this.resetParamsOfPendingCsat()
                        }
                    }
                }, {
                    key: "resetParamsOfPendingCsat",
                    value: function() {
                        this.set("paramsOfPendingCsat.flag", null), this.set("paramsOfPendingCsat.cross", null)
                    }
                }, {
                    key: "canVoteForCsat",
                    value: function() {
                        return this.jwt.auth.expiredAt || this.jwt.auth.scheduled || this.jwt.auth.expired ? (this.set("disableCsatVoting", !0), !1) : !this.isJwtExpired() || (this.initiateSendingMode(), this.set("disableCsatVoting", !0), !1)
                    }
                }, {
                    key: "resetCsat",
                    value: function() {
                        this.csatTimer && (Ember.run.cancel(this.csatTimer), this.csatTimer = null)
                    }
                }, {
                    key: "setCsatStars",
                    value: function(e) {
                        var t = this.csatRatings;
                        Ember.set(t, "star", e)
                    }
                }, {
                    key: "handleProfileImageError",
                    value: function(e) {
                        e.target.src = H.Z
                    }
                }, {
                    key: "csatKeyboardEvent",
                    value: function(e) {
                        j.default.changeFocusOnArrowKeyPress(e, null, {
                            sourceElem: ".star-rating",
                            optionsSelector: ".star-label",
                            arrowTypes: "both",
                            isDropDown: !1,
                            isReverse: !0
                        });
                        var t = document.querySelector(".d_hotline"),
                            n = document.querySelector(".csat-rating");
                        n && e && e.keyCode === B.default.KEYCODES.TAB && e.shiftKey && e.target === n && t && (e.preventDefault(), j.default.moveFocusTo(".d_hotline"))
                    }
                }, {
                    key: "submitCsatRating",
                    value: function(e, t) {
                        var n, i, o = this;
                        if (Ember.run.later(function() {
                                (0, S.Z)(this, o), j.default.moveFocusTo(".d_hotline")
                            }.bind(this), 1e3), e = "true" === String(e), t = "true" === String(t), this.isJWTStrictMode && !this.canVoteForCsat()) return this.set("paramsOfPendingCsat.flag", e), void this.set("paramsOfPendingCsat.cross", t);
                        this.set("allowCsatSubmit", !1);
                        var s = this.conversation,
                            a = this.csatRatings,
                            l = s.get("csat"),
                            r = this.session,
                            u = r && r.siteId,
                            c = this.localds,
                            d = B.default.EmberModelUrl.csatRating.url.replace("{token}", r.token).replace("{conversationId}", s.get("conversationId")).replace("{csatId}", l.get("csatId")),
                            p = {
                                csatResponse: {
                                    issueResolved: e
                                }
                            },
                            h = null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.conversationReferenceId;
                        t || (Ember.set(p.csatResponse, "stars", a.get("star")), Ember.set(p.csatResponse, "response", a.get("comment"))), u && (d += "?siteId=".concat(u)), u && this.isParallelConversationEnabled ? d += "&isParallelConversation=".concat(this.isParallelConversationEnabled) : this.isParallelConversationEnabled && (d += "?isParallelConversation=".concat(this.isParallelConversationEnabled)), this.axios.makeRequest({
                            method: "POST",
                            url: d,
                            data: p,
                            dataType: "json",
                            contentType: "application/json"
                        }).then(function(e) {
                            var n = this;
                            if ((0, S.Z)(this, o), this.set("allowCsatSubmit", !0), !e || !e.errorCode) {
                                if (t) Ember.set(s, "hasPendingCsat", !1), Ember.set(s, "resolvedConversationYes", !1), Ember.set(s, "resolvedConversationNo", !1), this.set("feedbackSubmitted", !1), Ember.set(a, "star", 0), Ember.set(a, "comment", ""), c.save(), Ember.set(s, "csat", null);
                                else {
                                    var i = "".concat(this.intl.t("csat.submitted"), ". ").concat(this.intl.t("csat.thank_you"));
                                    this.set("feedbackSubmitted", !0), j.default.readOutDynamicUpdates(i), Ember.set(s, "resolvedConversationYes", !1), Ember.set(s, "resolvedConversationNo", !1), setTimeout(function() {
                                        (0, S.Z)(this, n), this.isDestroyed && this.isDestroying || (this.set("feedbackSubmitted", !1), Ember.set(s, "hasPendingCsat", !1), Ember.set(a, "star", 0), Ember.set(a, "comment", ""), c.save(), Ember.set(s, "csat", null))
                                    }.bind(this), 2e3)
                                }
                                this.resetParamsOfPendingCsat(), Ember.set(p.csatResponse, "csatId", l.get("csatId")), Ember.set(p.csatResponse, "conversationId", s.get("conversationId")), this.postMessage.post({
                                    action: "csat_updated",
                                    status: 200,
                                    success: !0,
                                    data: {
                                        message: z(z({}, p), h && {
                                            conversationReferenceId: h
                                        })
                                    }
                                })
                            }
                        }.bind(this), function(e) {
                            (0, S.Z)(this, o), this.set("allowCsatSubmit", !0), this.logger.log(e.response), Ember.set(a, "star", 0), Ember.set(a, "comment", ""), this.set("feedbackSubmitted", !1), Ember.set(s, "hasPendingCsat", !1), Ember.set(s, "resolvedConversationYes", !1), Ember.set(s, "resolvedConversationNo", !1), Ember.set(s, "csat", null), this.resetParamsOfPendingCsat(), this.postMessage.post({
                                action: "csat_updated",
                                status: 400,
                                success: !1,
                                data: {
                                    message: z(z({}, e.response), h && {
                                        conversationReferenceId: h
                                    })
                                }
                            }), c.save()
                        }.bind(this))
                    }
                }, {
                    key: "csatVotingNo",
                    value: function() {
                        this.isJWTStrictMode && this.canVoteForCsat(), this.conversation.set("resolvedConversationNo", !0), j.default.moveFocusTo(".csat-rating")
                    }
                }, {
                    key: "csatVotingYes",
                    value: function() {
                        this.isJWTStrictMode && this.canVoteForCsat(), this.conversation.set("resolvedConversationYes", !0), j.default.moveFocusTo(".csat-rating")
                    }
                }]), n
            }(Ember.Component.extend(F.default, L.default, U.default, V.default)), T = (0, N.Z)(E.prototype, "postMessage", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), C = (0, N.Z)(E.prototype, "showCsatForm", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, N.Z)(E.prototype, "isJwtAuthInProgressing", [a], Object.getOwnPropertyDescriptor(E.prototype, "isJwtAuthInProgressing"), E.prototype), (0, N.Z)(E.prototype, "enableSubmitButtonForResolvedConversationNo", [l], Object.getOwnPropertyDescriptor(E.prototype, "enableSubmitButtonForResolvedConversationNo"), E.prototype), (0, N.Z)(E.prototype, "enableSubmitButtonForResolvedConversationYes", [r], Object.getOwnPropertyDescriptor(E.prototype, "enableSubmitButtonForResolvedConversationYes"), E.prototype), (0, N.Z)(E.prototype, "csatComments", [u], Object.getOwnPropertyDescriptor(E.prototype, "csatComments"), E.prototype), (0, N.Z)(E.prototype, "csatRatings", [c], Object.getOwnPropertyDescriptor(E.prototype, "csatRatings"), E.prototype), (0, N.Z)(E.prototype, "ratingObserve", [d], Object.getOwnPropertyDescriptor(E.prototype, "ratingObserve"), E.prototype), (0, N.Z)(E.prototype, "showCsat", [p], Object.getOwnPropertyDescriptor(E.prototype, "showCsat"), E.prototype), (0, N.Z)(E.prototype, "didAuthUserCB", [h], Object.getOwnPropertyDescriptor(E.prototype, "didAuthUserCB"), E.prototype), (0, N.Z)(E.prototype, "setCsatStars", [f], Object.getOwnPropertyDescriptor(E.prototype, "setCsatStars"), E.prototype), (0, N.Z)(E.prototype, "handleProfileImageError", [m], Object.getOwnPropertyDescriptor(E.prototype, "handleProfileImageError"), E.prototype), (0, N.Z)(E.prototype, "csatKeyboardEvent", [g], Object.getOwnPropertyDescriptor(E.prototype, "csatKeyboardEvent"), E.prototype), (0, N.Z)(E.prototype, "submitCsatRating", [v], Object.getOwnPropertyDescriptor(E.prototype, "submitCsatRating"), E.prototype), (0, N.Z)(E.prototype, "csatVotingNo", [b], Object.getOwnPropertyDescriptor(E.prototype, "csatVotingNo"), E.prototype), (0, N.Z)(E.prototype, "csatVotingYes", [y], Object.getOwnPropertyDescriptor(E.prototype, "csatVotingYes"), E.prototype), w = E)) || w)
        },
        79100: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return P
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h, f = n(10935),
                m = n(34645),
                g = n(5660),
                v = n(69049),
                b = n(28433),
                y = n(58678),
                w = n(55411),
                E = n(79833),
                T = n(52626),
                C = n(13256),
                S = n(18006),
                O = n(42410),
                M = n(13418),
                I = n.p + "valid_input.2fce7536ea57220d988b66cfc58d7130.svg",
                k = n.p + "invalid_input.d1bc033c6444ce115dd212169fbb0402.svg",
                _ = n.p + "ic_not_sent.29dca8318044041034480959c2f29c41.svg";

            function A(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var o = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var P = (i = (0, S.classNames)("away-experience-form"), o = (0, S.classNameBindings)("isIOS:ios-device"), s = Ember.computed.readOnly("hotline.ui.isIOS"), a = Ember.computed("hotline.ui.offlineExperience.contactInfo"), l = Ember.computed("contactInfo"), r = Ember._action, u = Ember._action, c = Ember._action, i(d = o((p = function(e) {
                (0, y.Z)(n, e);
                var t = A(n);

                function n() {
                    var e;
                    (0, m.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, T.Z)((0, v.Z)(e), "CONVERSATION", M.default.CONVERSATION), (0, T.Z)((0, v.Z)(e), "images", {
                        ValidInput: I,
                        InvalidInput: k,
                        ICNotSent: _
                    }), (0, f.Z)((0, v.Z)(e), "isIOS", h, (0, v.Z)(e)), e
                }
                return (0, g.Z)(n, [{
                    key: "init",
                    value: function() {
                        var e, t, i, o, s, a, l, r, u, c, d, p, h, f;
                        (0, b.Z)((0, E.Z)(n.prototype), "init", this).apply(this, arguments), this.setProperties({
                            invalidContactInfo: !1,
                            invalidUserMessage: !1,
                            showValidationMark: !1,
                            offlineFormSubmitted: !1
                        }), this.set("extraParams.isOfflineSendingFailed", !1);
                        var m = (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (i = this.session) || void 0 === i || null === (o = i.user) || void 0 === o ? void 0 : o.workEmail),
                            g = (null === (s = this.session) || void 0 === s || null === (a = s.user) || void 0 === a ? void 0 : a.phone) || (null === (l = this.session) || void 0 === l || null === (r = l.user) || void 0 === r ? void 0 : r.workNumber);
                        (null === (u = this.hotline) || void 0 === u || null === (c = u.ui) || void 0 === c || null === (d = c.offlineExperience) || void 0 === d ? void 0 : d.contactInfo) === this.CONVERSATION.CONTACT_INFO.EMAIL && m ? ((0, O.checkReplyValidation)("email", m) && this.set("showValidationMark", !0), this.set("contactDetail", m)) : (null === (p = this.hotline) || void 0 === p || null === (h = p.ui) || void 0 === h || null === (f = h.offlineExperience) || void 0 === f ? void 0 : f.contactInfo) === this.CONVERSATION.CONTACT_INFO.PHONE && g && ((0, O.checkReplyValidation)("phone", g) && this.set("showValidationMark", !0), this.set("contactDetail", g))
                    }
                }, {
                    key: "contactInfo",
                    get: function() {
                        var e, t, n;
                        return 0 === (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.offlineExperience) || void 0 === n ? void 0 : n.contactInfo) ? "email" : "phone"
                    }
                }, {
                    key: "contactInfoPlaceholder",
                    get: function() {
                        return "email" === this.contactInfo ? this.intl.t("away_experience.your_email") : this.intl.t("away_experience.your_phone")
                    }
                }, {
                    key: "createMessageFragment",
                    value: function(e) {
                        return {
                            fragmentType: this.CONVERSATION.FRAGMENT_TYPE.TEXT,
                            contentType: "text/html",
                            content: e.trim()
                        }
                    }
                }, {
                    key: "validateOfflineForm",
                    value: function(e, t) {
                        var n = this.contactInfo,
                            i = (0, O.checkReplyValidation)(n, e);
                        return t || i ? t ? !!i || (this.set("invalidContactInfo", !0), !1) : (this.set("invalidUserMessage", !0), this.element.querySelector(".user-message-reply").focus(), !1) : (this.set("invalidUserMessage", !0), this.set("invalidContactInfo", !0), this.element.querySelector(".user-message-reply").focus(), !1)
                    }
                }, {
                    key: "validateContactInfo",
                    value: function() {
                        var e = this.contactInfo,
                            t = this.contactDetail,
                            n = (0, O.checkReplyValidation)(e, t);
                        this.set("showValidationMark", n), n && this.set("invalidContactInfo", !1)
                    }
                }, {
                    key: "validateUserMessage",
                    value: function() {
                        this.userMessage && this.invalidUserMessage && this.set("invalidUserMessage", !1)
                    }
                }, {
                    key: "sendMessages",
                    value: function() {
                        var e = this.contactDetail,
                            t = this.userMessage;
                        if (this.validateOfflineForm(e, t)) {
                            this.set("offlineFormSubmitted", !0), "email" === this.contactInfo && this.set("session.user.email", e);
                            var n = this.createMessageFragment(e),
                                i = this.createMessageFragment(t),
                                o = [];
                            o.push(n), o.push(i), this.sendOfflineMessage(o)
                        }
                    }
                }]), n
            }(Ember.Component), h = (0, C.Z)(p.prototype, "isIOS", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, C.Z)(p.prototype, "contactInfo", [a], Object.getOwnPropertyDescriptor(p.prototype, "contactInfo"), p.prototype), (0, C.Z)(p.prototype, "contactInfoPlaceholder", [l], Object.getOwnPropertyDescriptor(p.prototype, "contactInfoPlaceholder"), p.prototype), (0, C.Z)(p.prototype, "validateContactInfo", [r], Object.getOwnPropertyDescriptor(p.prototype, "validateContactInfo"), p.prototype), (0, C.Z)(p.prototype, "validateUserMessage", [u], Object.getOwnPropertyDescriptor(p.prototype, "validateUserMessage"), p.prototype), (0, C.Z)(p.prototype, "sendMessages", [c], Object.getOwnPropertyDescriptor(p.prototype, "sendMessages"), p.prototype), d = p)) || d) || d)
        },
        90573: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(13418),
                s = n(50660),
                a = n(7259),
                l = n(475),
                r = n(68024);
            t.default = Ember.Component.extend(s.default, a.default, {
                PLACEHOLDERS: o.default.CONVERSATION.PLACEHOLDERS,
                CONVERSATION: o.default.CONVERSATION,
                DOM_ID: o.default.DOM_ID,
                classNames: ["h-reply-button", "custom-message-wrapper"],
                attributeBindings: ["tabindex"],
                tabindex: "-1",
                classNameBindings: ["dropdownOptions.length:h-reply-dropdown"],
                images: Ember.Object.create({
                    TickFeedbackSubmitted: r.Z
                }),
                isFeedbackReplyMessage: Ember.computed("message", {
                    get: function() {
                        var e;
                        return null == this || null === (e = this.message) || void 0 === e ? void 0 : e.isFeedbackResponse
                    }
                }),
                customTextComposer: Ember.computed("this.message.replyFragments", {
                    get: function() {
                        var e = this,
                            t = this.getReplyCollectionFragments(this.message);
                        return null == t ? void 0 : t.filter(function(t) {
                            var n = t.fragmentType;
                            return (0, i.Z)(this, e), n === o.default.CONVERSATION.FRAGMENT_TYPE.TEXT
                        }.bind(this))
                    }
                }),
                timeFragments: Ember.computed("message.replyFragments", {
                    get: function() {
                        var e, t, n, s, a, l = this,
                            r = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments,
                            u = null == r || null === (t = r[0]) || void 0 === t ? void 0 : t.templateType,
                            c = null == r || null === (n = r[0]) || void 0 === n || null === (s = n.sections) || void 0 === s || null === (a = s[0]) || void 0 === a ? void 0 : a.fragments;
                        if (null != c && c.length && u === o.default.TemplateType.TIME_PICKER) {
                            r[0].inputType = "time";
                            var d = {};
                            return r[0].sections.forEach(function(e) {
                                (0, i.Z)(this, l), "from_time" === e.name ? d.fromTime = e.fragments[0].content : "to_time" === e.name && (d.toTime = e.fragments[0].content)
                            }.bind(this)), d
                        }
                        return null
                    }
                }),
                dropdownOptions: Ember.computed("message", {
                    get: function() {
                        var e, t = this,
                            n = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments;
                        if (null != n && n.length && this.isDropDownMessage(n)) {
                            var s, a = null === (s = n[0]) || void 0 === s ? void 0 : s.sections;
                            if (!a || !a.length) return [];
                            var l = a.find(function(e) {
                                return (0, i.Z)(this, t), e.name === o.default.RICH_MESSAGES.SECTION_NAMES.OPTIONS
                            }.bind(this));
                            return null == l ? void 0 : l.fragments
                        }
                        return []
                    }
                }),
                isMultiSelectDropdown: Ember.computed("message", {
                    get: function() {
                        var e, t = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments;
                        return (null == t ? void 0 : t.length) && this.isDropDownMessage(t) && this.isMultiSelectDropDownMessage(t)
                    }
                }),
                didInsertElement: function() {
                    var e = this;
                    this._super.apply(this, arguments), Ember.run.later(function() {
                        (0, i.Z)(this, e), this.setChatWindowHeight(!1)
                    }.bind(this))
                },
                willDestroyElement: function() {
                    this._super.apply(this, arguments), this.setChatWindowHeight(!0)
                },
                didRender: function() {
                    var e = this;
                    this._super.apply(this, arguments), Ember.run.later(function() {
                        (0, i.Z)(this, e), this.resizeChatWindow()
                    }.bind(this))
                },
                feedbackData: Ember.computed("message", {
                    get: function() {
                        var e, t, n, s, a, l, r, u, c = this,
                            d = null === (e = this.message) || void 0 === e ? void 0 : e.replyFragments,
                            p = null == d || null === (t = d[0]) || void 0 === t ? void 0 : t.templateType,
                            h = null == d || null === (n = d[0]) || void 0 === n || null === (s = n.sections) || void 0 === s || null === (a = s[0]) || void 0 === a ? void 0 : a.fragments;
                        if (null != h && h.length) switch (p) {
                            case null === o.default || void 0 === o.default || null === (l = o.default.TemplateType) || void 0 === l ? void 0:
                                l.FEEDBACK_RATING: return {
                                    content: h.sort(function(e, t) {
                                        return (0, i.Z)(this, c), parseInt(e.displayOrder) - parseInt(t.displayOrder)
                                    }.bind(this)).reverse(),
                                    feedbackType: p
                                };
                            case null === o.default || void 0 === o.default || null === (r = o.default.TemplateType) || void 0 === r ? void 0:
                                r.FEEDBACK_OPINION_POLL:
                                    case null === o.default || void 0 === o.default || null === (u = o.default.TemplateType) || void 0 === u ? void 0:
                                u.FEEDBACK_COMMENT: return {
                                    content: h,
                                    feedbackType: p
                                }
                        }
                        return null
                    }
                }),
                actions: {
                    setNextFocus: function() {
                        var e = document.querySelector(".ic-back"),
                            t = document.querySelector(".fc-carousel");
                        event && event.target === t && event.keyCode === o.default.KEYCODES.TAB && event.shiftKey && e && (event.preventDefault(), e.focus())
                    },
                    dropdownSelectionHandler: function(e) {
                        var t = e,
                            n = {
                                replyTo: {
                                    originalMessageId: this.message.messageId
                                }
                            };
                        this.sendButtonMessage(t, n)
                    },
                    onTimePickerKeyDownHandler: function(e) {
                        this.onTimePickerKeyDown(e)
                    },
                    feedbackSelectionHandler: function(e) {
                        var t = [e];
                        this.sendButtonMessage(t, {})
                    },
                    sendButtonMessage: function(e, t) {
                        this.sendButtonMessage(e, t)
                    },
                    triggerSendButtonMessage: function(e, t) {
                        this.sendButtonMessage(e, t, !1, this.DOM_ID.appReplyComposerEditor)
                    },
                    keyPressDownLocal: function(e, t) {
                        if (13 === t.which) t.preventDefault(), (0, l.isSlashCmdMenuVisible)() || this.sendButtonMessage(null, null, !1, this.DOM_ID.appReplyComposerEditor)
                    },
                    setIsTextLimitExceeded: function() {}
                }
            })
        },
        86687: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(38422)
        },
        14991: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return E
                }
            });
            var i, o, s, a, l, r = n(35235),
                u = n(10935),
                c = n(34645),
                d = n(5660),
                p = n(69049),
                h = n(28433),
                f = n(58678),
                m = n(55411),
                g = n(79833),
                v = n(52626),
                b = n(13256),
                y = n(13418);

            function w(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, g.Z)(e);
                    if (t) {
                        var o = (0, g.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, m.Z)(this, n)
                }
            }
            var E = (i = Ember.inject.service("post-message"), o = Ember.inject.service("bot-action-events"), s = function(e) {
                (0, f.Z)(n, e);
                var t = w(n);

                function n() {
                    var e;
                    (0, c.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, u.Z)((0, p.Z)(e), "postMessage", a, (0, p.Z)(e)), (0, u.Z)((0, p.Z)(e), "botActionEvents", l, (0, p.Z)(e)), (0, v.Z)((0, p.Z)(e), "eventOnWidgetOpen", !1), e
                }
                return (0, d.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, h.Z)((0, g.Z)(n.prototype), "init", this).apply(this, arguments), this.executeWidgetActions(this.model.actions)
                    }
                }, {
                    key: "executeWidgetActions",
                    value: function(e) {
                        var t = this;
                        e.forEach(function(e) {
                            var n = this;
                            (0, r.Z)(this, t);
                            var i = e.name,
                                o = e.data,
                                s = void 0 === o ? {} : o,
                                a = e.sleepTime,
                                l = y.default.BOT_ACTIONS;
                            s.channelId = parseInt(this.channelId), this.model.isActionExecuted || (i !== l.WIDGET_OPENED || this.eventOnWidgetOpen || (a = 0, this.set("eventOnWidgetOpen", !0)), Ember.run.later(function() {
                                (0, r.Z)(this, n), this.model.isActionExecuted = !0, i === l.TRIGGER_JS_FUNCTION || i === l.OPEN_URL ? this.postMessage.post({
                                    action: i,
                                    data: s
                                }) : l[i] && this.botActionEvents.triggerEvent({
                                    name: i,
                                    data: s
                                })
                            }.bind(this), a))
                        }.bind(this))
                    }
                }]), n
            }(Ember.Component.extend()), a = (0, b.Z)(s.prototype, "postMessage", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), l = (0, b.Z)(s.prototype, "botActionEvents", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), s)
        },
        1958: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(68109)
        },
        94842: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(85774)
        },
        49162: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return g
                }
            });
            var i, o = n(34645),
                s = n(5660),
                a = n(69049),
                l = n(28433),
                r = n(58678),
                u = n(55411),
                c = n(79833),
                d = n(52626),
                p = n(18006),
                h = n(13418),
                f = n(44229);

            function m(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, c.Z)(e);
                    if (t) {
                        var o = (0, c.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, u.Z)(this, n)
                }
            }
            var g = (0, p.attributeBindings)("accept")(i = function(e) {
                (0, r.Z)(n, e);
                var t = m(n);

                function n() {
                    var e;
                    (0, o.Z)(this, n);
                    for (var i = arguments.length, s = new Array(i), l = 0; l < i; l++) s[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(s)), (0, d.Z)((0, a.Z)(e), "type", "file"), (0, d.Z)((0, a.Z)(e), "accept", "file"), (0, d.Z)((0, a.Z)(e), "multiple", !1), e
                }
                return (0, s.Z)(n, [{
                    key: "init",
                    value: function() {
                        (0, l.Z)((0, c.Z)(n.prototype), "init", this).apply(this, arguments);
                        var e = this.allowedFileTypes;
                        e && Ember.set(this, "accept", e)
                    }
                }, {
                    key: "getFileType",
                    value: function(e) {
                        var t, n = this.isAttachment,
                            i = this.allowedFileTypes,
                            o = this.blockedFileTypes,
                            s = i && i.split(",") || [],
                            a = o && o.split(",") || [],
                            l = e && e.lastIndexOf("."),
                            r = e && l >= 0 && e.substr(l) || "";
                        return r = r.toLowerCase(), f.default.checkValidFileExtension(r) && e && r ? (t = h.default.SupportedImageFileExtensions[r] ? h.default.FILETYPE.IMAGE : h.default.FILETYPE.FILE, t = n ? h.default.FILETYPE.FILE : t, i ? s.indexOf(r) >= 0 ? t : h.default.FILETYPE.INVALID : o && a.indexOf(r) >= 0 ? h.default.FILETYPE.INVALID : t) : h.default.FILETYPE.INVALID
                    }
                }, {
                    key: "isSupportedFileSize",
                    value: function(e, t) {
                        var n = this.attr || {},
                            i = n && n.size || (t === h.default.FILETYPE.IMAGE ? h.default.ImageAttr.size : h.default.FileAttr.size),
                            o = e.size <= i;
                        return o || this.set("parentView.content", {
                            error: this.intl.t("file_attachment_errors.invalid_file_size", {
                                attributeSize: i / 1048576
                            }),
                            timestamp: (new Date).getTime()
                        }), o
                    }
                }, {
                    key: "processFile",
                    value: function(e, t) {
                        var n = {
                            fileType: t,
                            fileData: e,
                            timestamp: (new Date).getTime(),
                            isShared: this.isShared,
                            markForQuickAccess: this.markForQuickAccess
                        };
                        this.set("parentView.content", n), this.set("imageData", n)
                    }
                }, {
                    key: "processImageFile",
                    value: function(e, t) {
                        var n = this,
                            i = this.attr || {},
                            o = new FileReader,
                            s = new Image;
                        o.onload = function(o) {
                            var a, l = o.target.result;
                            (i.width || i.height) && (s.src = l, s.onload = function() {
                                (this.width > i.width || this.height > i.height) && n.set("parentView.content", {
                                    error: n.get("intl").t("file_attachment_errors.invalid_image_resolution", {
                                        width: i.width,
                                        height: i.height
                                    }),
                                    timestamp: (new Date).getTime()
                                })
                            }), a = {
                                fileType: t,
                                fileData: e,
                                timestamp: (new Date).getTime(),
                                data: l,
                                attr: {
                                    width: this.width,
                                    height: this.height
                                }
                            }, n.set("parentView.content", a), n.set("imageData", a)
                        }, o.readAsDataURL(e)
                    }
                }, {
                    key: "change",
                    value: function(e) {
                        for (var t = e && e.target && e.target.files || [], n = t.length || 0, i = 0; i < n; i++) {
                            var o = t[i],
                                s = this.getFileType(o.name);
                            s !== h.default.FILETYPE.INVALID ? this.isSupportedFileSize(o, s) && (s === h.default.FILETYPE.FILE ? this.processFile(o, s) : s === h.default.FILETYPE.IMAGE && this.processImageFile(o, s)) : this.set("parentView.content", {
                                error: this.intl.t("file_attachment_errors.invalid_file_extension"),
                                timestamp: (new Date).getTime()
                            })
                        }
                        e.target.value = ""
                    }
                }]), n
            }(Ember.TextField)) || i
        },
        16136: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return b
                }
            });
            var i, o, s, a, l, r = n(34645),
                u = n(5660),
                c = n(69049),
                d = n(58678),
                p = n(55411),
                h = n(79833),
                f = n(52626),
                m = n(13256),
                g = n(18006);

            function v(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, h.Z)(e);
                    if (t) {
                        var o = (0, h.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, p.Z)(this, n)
                }
            }
            var b = (i = (0, g.tagName)("input"), o = (0, g.attributeBindings)("type", "id", "name", "value", "checked", "tabIndex:tabindex", "ariaHidden:aria-hidden"), s = Ember.computed("group", "value"), i(a = o((l = function(e) {
                (0, d.Z)(n, e);
                var t = v(n);

                function n() {
                    var e;
                    (0, r.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, f.Z)((0, c.Z)(e), "type", "radio"), e
                }
                return (0, u.Z)(n, [{
                    key: "checked",
                    get: function() {
                        return this.group === this.value
                    }
                }, {
                    key: "change",
                    value: function() {
                        this.group !== this.value && Ember.run.once(this, "changed")
                    }
                }, {
                    key: "changed",
                    value: function() {
                        this.onchange(this.value)
                    }
                }]), n
            }(Ember.Component), (0, m.Z)(l.prototype, "checked", [s], Object.getOwnPropertyDescriptor(l.prototype, "checked"), l.prototype), a = l)) || a) || a)
        },
        56407: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return k
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h = n(35235),
                f = n(10935),
                m = n(34645),
                g = n(5660),
                v = n(69049),
                b = n(28433),
                y = n(58678),
                w = n(55411),
                E = n(79833),
                T = n(52626),
                C = n(13256),
                S = n(76144),
                O = n(13418),
                M = n(96064);

            function I(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var o = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var k = (i = Ember._tracked, o = Ember.inject.service, s = Ember.inject.service, a = Ember.inject.service, l = Ember.computed("hotline.ui.{isFirstBotMessage,firstBotChannelId}", "channelId"), r = function(e) {
                (0, y.Z)(n, e);
                var t = I(n);

                function n(e, i) {
                    var o, s = this;
                    return (0, m.Z)(this, n), o = t.call(this, e, i), (0, f.Z)((0, v.Z)(o), "isAgentTyping", u, (0, v.Z)(o)), (0, T.Z)((0, v.Z)(o), "agentThread", void 0), (0, T.Z)((0, v.Z)(o), "freddyThread", void 0), (0, T.Z)((0, v.Z)(o), "chatWindow", document.querySelector(".h-conv-chat")), (0, T.Z)((0, v.Z)(o), "onRTSMessageCB", o.onRTSMessage.bind((0, v.Z)(o))), (0, f.Z)((0, v.Z)(o), "rts", c, (0, v.Z)(o)), (0, f.Z)((0, v.Z)(o), "hotline", d, (0, v.Z)(o)), (0, f.Z)((0, v.Z)(o), "session", p, (0, v.Z)(o)), Ember.addListener(o.rts, "didRTSMessage", o.onRTSMessageCB), setTimeout(function() {
                        var e;
                        (0, h.Z)(this, s), Ember.set(null === (e = o.hotline) || void 0 === e ? void 0 : e.ui, "isFirstBotMessage", !1)
                    }.bind(this), O.default.TYPING_INDICATOR_DURATION.FREDDY_BOT), o
                }
                return (0, g.Z)(n, [{
                    key: "channelId",
                    get: function() {
                        var e;
                        return null !== (e = this.args.channelId) && void 0 !== e ? e : void 0
                    }
                }, {
                    key: "showTypingIndForBots",
                    get: function() {
                        var e, t, n, i;
                        return (null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t ? void 0 : t.isFirstBotMessage) && (null === (n = this.hotline) || void 0 === n || null === (i = n.ui) || void 0 === i ? void 0 : i.firstBotChannelId) === this.channelId
                    }
                }, {
                    key: "willDestroy",
                    value: function() {
                        (0, b.Z)((0, E.Z)(n.prototype), "willDestroy", this).apply(this, arguments), Ember.removeListener(this.rts, "didRTSMessage", this.onRTSMessageCB)
                    }
                }, {
                    key: "hideTypingIndicator",
                    value: function() {
                        var e = this.agentThread,
                            t = this.freddyThread;
                        this.isAgentTyping = !1, e && clearTimeout(e), t && clearTimeout(t)
                    }
                }, {
                    key: "showTypingIndicator",
                    value: function(e) {
                        var t = this,
                            n = this.chatWindow,
                            i = this.agentThread;
                        this.isAgentTyping = !0, n && n.scrollTop >= n.scrollHeight - n.offsetHeight - 30 && !document.querySelector(".h-conv-chat .notification-container") && M.default.scrollTo(n, n.scrollHeight, 1500), i && clearTimeout(i), this.agentThread = setTimeout(function() {
                            (0, h.Z)(this, t), this.isDestroying || this.isDestroyed || (this.isAgentTyping = !1)
                        }.bind(this), e)
                    }
                }, {
                    key: "onRTSMessage",
                    value: function(e) {
                        var t, n = this,
                            i = e && e.userId,
                            o = this.channelId,
                            s = this.session.user.id;
                        if (Ember.set(null === (t = this.hotline) || void 0 === t ? void 0 : t.ui, "isFirstBotMessage", !1), "is_typing" === e.action && e.channelId && e.channelId === o && s && s !== parseInt(i, 10)) this.showTypingIndicator(O.default.TYPING_INDICATOR_DURATION.AGENT);
                        else if ("MESSAGE_RECEIVED" === e.type && e.conversation && e.conversation.channelId === o) {
                            s === (e.conversation && e.conversation.messages && e.conversation.messages.length && e.conversation.messages[0].messageUserId) ? e.conversation && e.conversation.status === O.default.CONVERSATION.CONVERSATION_STATUS.FREDDY_BOT && (this.hideTypingIndicator(), this.freddyThread = setTimeout(function() {
                                (0, h.Z)(this, n), this.showTypingIndicator(O.default.TYPING_INDICATOR_DURATION.FREDDY_BOT)
                            }.bind(this), 1e3)) : this.hideTypingIndicator()
                        }
                    }
                }]), n
            }(S.default), u = (0, C.Z)(r.prototype, "isAgentTyping", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), c = (0, C.Z)(r.prototype, "rts", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), d = (0, C.Z)(r.prototype, "hotline", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), p = (0, C.Z)(r.prototype, "session", [a], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, C.Z)(r.prototype, "showTypingIndForBots", [l], Object.getOwnPropertyDescriptor(r.prototype, "showTypingIndForBots"), r.prototype), r)
        },
        34607: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return V
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h, f, m, g, v, b, y, w = n(35235),
                E = n(10935),
                T = n(34645),
                C = n(5660),
                S = n(69049),
                O = n(58678),
                M = n(55411),
                I = n(79833),
                k = n(52626),
                _ = n(13256),
                A = n(18006),
                P = n(42410),
                R = n(13418),
                D = n(22126),
                N = n(6682),
                Z = n(62471),
                x = n(16686);

            function B(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, i)
                }
                return n
            }

            function F(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? B(Object(n), !0).forEach((function(t) {
                        (0, k.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : B(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function L(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, I.Z)(e);
                    if (t) {
                        var o = (0, I.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, M.Z)(this, n)
                }
            }
            var U = R.default.CONVERSATION,
                V = (i = (0, A.tagName)("button"), o = (0, A.classNameBindings)("selected:btn-selected"), s = (0, A.classNames)("h-img-button"), a = (0, A.attributeBindings)("data-test-id", "title"), l = Ember.inject.service(), r = Ember.computed.readOnly("hotline.ui.isIPhone"), u = Ember.computed.alias("hotlineUI.config.betaFeatures"), c = Ember.computed, d = Ember._action, p = Ember._action, h = Ember._action, f = Ember._action, i(m = o(m = s(m = a((g = function(e) {
                    (0, O.Z)(n, e);
                    var t = L(n);

                    function n() {
                        var e;
                        (0, T.Z)(this, n);
                        for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                        return e = t.call.apply(t, [this].concat(o)), (0, E.Z)((0, S.Z)(e), "hotline", v, (0, S.Z)(e)), (0, E.Z)((0, S.Z)(e), "isIPhone", b, (0, S.Z)(e)), (0, E.Z)((0, S.Z)(e), "enabledBetaFeatures", y, (0, S.Z)(e)), e
                    }
                    return (0, C.Z)(n, [{
                        key: "generatedHTML",
                        get: function() {
                            var e, t, n = (0, x.sanitizeHTML)(this, this.model.label, "strict"),
                                i = null !== (e = this.hotline) && void 0 !== e && null !== (t = e.ui) && void 0 !== t && t.isDesktop ? (0, N.default)(n, Z.default.EmberENV.cdnUrl) : n;
                            return Ember.String.htmlSafe(i)
                        }
                    }, {
                        key: "click",
                        value: function(e) {
                            e.preventDefault();
                            var t = this.model;
                            switch (t.fragmentType) {
                                case U.FRAGMENT_TYPE.DYNAMIC_TEMPLATE_CONTENT:
                                    this.sendButtonMessage(t);
                                    break;
                                case U.FRAGMENT_TYPE.QUICKREPLY:
                                    this.send("sendReplyMessage", t.customReplyText || t.label);
                                    break;
                                case U.FRAGMENT_TYPE.CALLBACK:
                                    this.performArticleFeedbackCallback(t), this.send("sendReplyMessage", t.label, U.MESSAGE_TYPE.FEEDBACK_RESPONSE);
                                    break;
                                case U.FRAGMENT_TYPE.BUTTON:
                                    "_blank" === t.target ? this.send("openExternalTab", t.content) : "_self" === t.target ? this.send("openExternalLink", t.content) : this.send("openInternalLink", t.content)
                            }
                        }
                    }, {
                        key: "openExternalTab",
                        value: function(e) {
                            window.open(e, "_blank")
                        }
                    }, {
                        key: "openInternalLink",
                        value: function(e) {
                            var t;
                            if (null !== (t = this.session) && void 0 !== t && t.isKbaseEnabled) {
                                var n = {
                                    articleId: (0, P.getParameterByName)("article_id", e),
                                    categoryId: (0, P.getParameterByName)("category_id", e)
                                };
                                this.router.send("gotoFAQArticle", n)
                            } else {
                                var i, o, s = null === (i = this.faqs) || void 0 === i ? void 0 : i.content.serialize();
                                s && (o = (0, P.getArticleToShow)(s.dsCategories, e)) && this.router.send("gotoFAQArticle", o)
                            }
                        }
                    }, {
                        key: "openExternalLink",
                        value: function(e) {
                            var t, n = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                            Ember.set(n, "modalOpen", !0), Ember.set(n, "modal", {
                                thirdPartyURL: e,
                                title: ""
                            }), Ember.set(n, "openArticleFromMessage", !0)
                        }
                    }, {
                        key: "sendReplyMessage",
                        value: function(e, t) {
                            var n = {
                                    fragmentType: U.FRAGMENT_TYPE.TEXT,
                                    contentType: "text/html",
                                    content: e
                                },
                                i = [];
                            this.enabledBetaFeatures[R.default.enabledisplayorder] ? i.push(F(F({}, n), {}, {
                                displayOrder: this.model.displayOrder,
                                label: this.model.label,
                                fragmentType: U.FRAGMENT_TYPE.QUICKREPLY
                            })) : i.push(F({}, n)), this.sendButtonMessage(i, t ? {
                                messageType: t
                            } : null, this.isQuickActionButton)
                        }
                    }, {
                        key: "performArticleFeedbackCallback",
                        value: function(e) {
                            var t, n, i = this,
                                o = this.message && (null === (t = this.message) || void 0 === t ? void 0 : t.alias),
                                s = R.default.EmberModelUrl.getTemplateArticle.postBackURL;
                            s = s.replace("{token}", null === (n = this.session) || void 0 === n ? void 0 : n.token).replace("{messageAlias}", o).replace("/{referenceId}", ""), this.axios.makeRequest({
                                method: "POST",
                                url: s,
                                contentType: "application/json",
                                data: e
                            }).then(function(e) {
                                (0, w.Z)(this, i), this.logger.log(e)
                            }.bind(this), function(e) {
                                (0, w.Z)(this, i), this.logger.log(e && e.response)
                            }.bind(this))
                        }
                    }]), n
                }(Ember.Component.extend(R.default, D.default)), v = (0, _.Z)(g.prototype, "hotline", [l], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), b = (0, _.Z)(g.prototype, "isIPhone", [r], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), y = (0, _.Z)(g.prototype, "enabledBetaFeatures", [u], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: null
                }), (0, _.Z)(g.prototype, "generatedHTML", [c], Object.getOwnPropertyDescriptor(g.prototype, "generatedHTML"), g.prototype), (0, _.Z)(g.prototype, "openExternalTab", [d], Object.getOwnPropertyDescriptor(g.prototype, "openExternalTab"), g.prototype), (0, _.Z)(g.prototype, "openInternalLink", [p], Object.getOwnPropertyDescriptor(g.prototype, "openInternalLink"), g.prototype), (0, _.Z)(g.prototype, "openExternalLink", [h], Object.getOwnPropertyDescriptor(g.prototype, "openExternalLink"), g.prototype), (0, _.Z)(g.prototype, "sendReplyMessage", [f], Object.getOwnPropertyDescriptor(g.prototype, "sendReplyMessage"), g.prototype), m = g)) || m) || m) || m) || m)
        },
        70122: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return f
                }
            });
            var i, o, s, a = n(34645),
                l = n(5660),
                r = n(58678),
                u = n(55411),
                c = n(79833),
                d = n(13256),
                p = n(70387);

            function h(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, c.Z)(e);
                    if (t) {
                        var o = (0, c.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, u.Z)(this, n)
                }
            }
            var f = (i = Ember.computed("model"), o = Ember._action, s = function(e) {
                (0, r.Z)(n, e);
                var t = h(n);

                function n() {
                    return (0, a.Z)(this, n), t.apply(this, arguments)
                }
                return (0, l.Z)(n, [{
                    key: "daysWithSlotsAsQuads",
                    get: function() {
                        for (var e = [], t = this.model, n = t && t.get("length"), i = 0; i < n; i++) {
                            var o = t.objectAt(i),
                                s = o && o.morningSlots,
                                a = o && o.afternoonSlots,
                                l = o && o.eveningSlots,
                                r = o && o.nightSlots,
                                u = {
                                    date: o.date,
                                    weekday: o.weekday
                                };
                            s && (u.morningSlots = this.convertSlotsIntoQuads(s), u.morningSlotsCount = s.length), a && (u.afternoonSlots = this.convertSlotsIntoQuads(a), u.afternoonSlotsCount = a.length), l && (u.eveningSlots = this.convertSlotsIntoQuads(l), u.eveningSlotsCount = l.length), r && (u.nightSlots = this.convertSlotsIntoQuads(r), u.nightSlotsCount = r.length), e.push(u)
                        }
                        return e
                    }
                }, {
                    key: "convertSlotsIntoQuads",
                    value: function(e) {
                        for (var t = e && e.length, n = [], i = 0; i < t; i += 4) t >= i + 4 ? n.push([e[i], e[i + 1], e[i + 2], e[i + 3]]) : t === i + 3 ? n.push([e[i], e[i + 1], e[i + 2]]) : t === i + 2 ? n.push([e[i], e[i + 1]]) : n.push([e[i]]);
                        return n
                    }
                }, {
                    key: "openConfirmationView",
                    value: function(e) {
                        this.openConfirmationScreen(e), p.default.moveFocusTo(".calendar-picker-minified")
                    }
                }]), n
            }(Ember.Component), (0, d.Z)(s.prototype, "daysWithSlotsAsQuads", [i], Object.getOwnPropertyDescriptor(s.prototype, "daysWithSlotsAsQuads"), s.prototype), (0, d.Z)(s.prototype, "openConfirmationView", [o], Object.getOwnPropertyDescriptor(s.prototype, "openConfirmationView"), s.prototype), s)
        },
        46616: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return S
                }
            });
            var i, o, s, a, l, r, u, c, d, p = n(34645),
                h = n(5660),
                f = n(69049),
                m = n(58678),
                g = n(55411),
                v = n(79833),
                b = n(52626),
                y = n(13256),
                w = n(18006),
                E = n(13418),
                T = n(11731);

            function C(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, v.Z)(e);
                    if (t) {
                        var o = (0, v.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, g.Z)(this, n)
                }
            }
            var S = (i = (0, w.classNames)("cal-picker-weekday"), o = Ember.computed("isLoading"), s = Ember.computed("slotsForMinifiedView.{session,slots}"), a = Ember.computed("slotsForMinifiedView.session"), l = Ember.computed("slotsForMinifiedView.slots"), r = Ember.computed("model"), u = Ember._action, i((d = function(e) {
                (0, m.Z)(n, e);
                var t = C(n);

                function n() {
                    var e;
                    (0, p.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, b.Z)((0, f.Z)(e), "CALENDAR", E.default.CALENDAR), e
                }
                return (0, h.Z)(n, [{
                    key: "mockSlots",
                    get: function() {
                        return [
                            [1, 2, 3],
                            [4, 5]
                        ]
                    }
                }, {
                    key: "tripletSessionWithCount",
                    get: function() {
                        var e = this.slotsForMinifiedView,
                            t = e && e.session,
                            n = "",
                            i = (e && e.slots).length;
                        return t === E.default.CALENDAR.SESSIONS.MORNING ? n = this.intl.t("calendar.morn") : t === E.default.CALENDAR.SESSIONS.AFTERNOON ? n = this.intl.t("calendar.afternoon") : t === E.default.CALENDAR.SESSIONS.EVENING ? n = this.intl.t("calendar.evening") : t === E.default.CALENDAR.SESSIONS.NIGHT && (n = this.intl.t("calendar.night")), n + "(" + i + ")"
                    }
                }, {
                    key: "tripletSessionIconClass",
                    get: function() {
                        var e = this.slotsForMinifiedView.session;
                        return e && this.getCSSClassForSession(e)
                    }
                }, {
                    key: "slotsAsTriplets",
                    get: function() {
                        for (var e, t = null === (e = this.slotsForMinifiedView) || void 0 === e ? void 0 : e.slots, n = t && t.length, i = [], o = 0; o < n; o += 3) n >= o + 3 ? i.push([t[o], t[o + 1], t[o + 2]]) : n === o + 2 ? i.push([t[o], t[o + 1]]) : i.push([t[o]]);
                        return i
                    }
                }, {
                    key: "slotsForMinifiedView",
                    get: function() {
                        return this.getFirstAvailableSessionFromDayObject(this.model)
                    }
                }, {
                    key: "getFirstAvailableSessionFromDayObject",
                    value: function(e) {
                        var t;
                        if (e) return e.morningSlots ? t = {
                            session: E.default.CALENDAR.SESSIONS.MORNING,
                            slots: e.morningSlots
                        } : e.afternoonSlots ? t = {
                            slots: e.afternoonSlots,
                            session: E.default.CALENDAR.SESSIONS.AFTERNOON
                        } : e.eveningSlots ? t = {
                            slots: e.eveningSlots,
                            session: E.default.CALENDAR.SESSIONS.EVENING
                        } : e.nightSlots && (t = {
                            slots: e.nightSlots,
                            session: E.default.CALENDAR.SESSIONS.NIGHT
                        }), t.slots && t.slots.length > 6 && (t.slots = t.slots.slice(0, 6)), t
                    }
                }, {
                    key: "bookSlot",
                    value: function(e) {
                        this.setSlot(e)
                    }
                }]), n
            }(Ember.Component.extend(T.default)), (0, y.Z)(d.prototype, "mockSlots", [o], Object.getOwnPropertyDescriptor(d.prototype, "mockSlots"), d.prototype), (0, y.Z)(d.prototype, "tripletSessionWithCount", [s], Object.getOwnPropertyDescriptor(d.prototype, "tripletSessionWithCount"), d.prototype), (0, y.Z)(d.prototype, "tripletSessionIconClass", [a], Object.getOwnPropertyDescriptor(d.prototype, "tripletSessionIconClass"), d.prototype), (0, y.Z)(d.prototype, "slotsAsTriplets", [l], Object.getOwnPropertyDescriptor(d.prototype, "slotsAsTriplets"), d.prototype), (0, y.Z)(d.prototype, "slotsForMinifiedView", [r], Object.getOwnPropertyDescriptor(d.prototype, "slotsForMinifiedView"), d.prototype), (0, y.Z)(d.prototype, "bookSlot", [u], Object.getOwnPropertyDescriptor(d.prototype, "bookSlot"), d.prototype), c = d)) || c)
        },
        29882: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return v
                }
            });
            var i, o, s, a, l, r = n(34645),
                u = n(5660),
                c = n(58678),
                d = n(55411),
                p = n(79833),
                h = n(13256),
                f = n(18006),
                m = n(11731);

            function g(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, p.Z)(e);
                    if (t) {
                        var o = (0, p.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, d.Z)(this, n)
                }
            }
            var v = (i = (0, f.classNames)("maximized-slots"), o = Ember._action, s = Ember._action, i((l = function(e) {
                (0, c.Z)(n, e);
                var t = g(n);

                function n() {
                    return (0, r.Z)(this, n), t.apply(this, arguments)
                }
                return (0, u.Z)(n, [{
                    key: "closeCalendarPickerMaxMode",
                    value: function() {
                        this.closeCalendarPicker()
                    }
                }, {
                    key: "openConfirmationScreen",
                    value: function(e) {
                        this.openConfirmationScreenForCalPicker(e, this.calendarMessage)
                    }
                }]), n
            }(Ember.Component.extend(m.default)), (0, h.Z)(l.prototype, "closeCalendarPickerMaxMode", [o], Object.getOwnPropertyDescriptor(l.prototype, "closeCalendarPickerMaxMode"), l.prototype), (0, h.Z)(l.prototype, "openConfirmationScreen", [s], Object.getOwnPropertyDescriptor(l.prototype, "openConfirmationScreen"), l.prototype), a = l)) || a)
        },
        94101: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return ie
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h, f, m, g, v, b, y, w, E, T, C, S, O, M, I, k, _, A, P, R = n(35235),
                D = n(10935),
                N = n(34645),
                Z = n(5660),
                x = n(69049),
                B = n(28433),
                F = n(58678),
                L = n(55411),
                U = n(79833),
                V = n(52626),
                j = n(13256),
                H = n(18006),
                q = n(72857),
                z = n(89567),
                G = n(44229),
                Y = n(13418),
                W = n(11731),
                K = n(50660),
                Q = n(79956),
                J = n(70387),
                X = n(97051),
                $ = n(71259),
                ee = n(62309),
                te = n(8495);

            function ne(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, U.Z)(e);
                    if (t) {
                        var o = (0, U.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, L.Z)(this, n)
                }
            }
            var ie = (i = (0, H.classNames)("cal-picker"), o = Ember.computed("isLoadingSlots", "firstFreeTimeSlots"), s = Ember.computed("messageMetaData", "messageMetaData.calendarMessageMeta.calendarAgentAlias"), a = Ember.computed("messageMetaData.calendarMessageMeta.calendarAgentAlias"), l = Ember.computed("session.user.{profilePicThumbUrl.isNameGenerated}"), r = Ember.computed.match("userInputEmail", G.default._EMAIL_REGEX), u = Ember.computed("message", "message.internalMeta.meetingStartTime", "meetingLength", "userTimeZoneToUse"), c = Ember.computed("message", "message.internalMeta.meetingStartTime", "userTimeZoneToUse"), d = Ember.computed, p = Ember.computed("timeZoneFilterValue"), h = Ember.computed("userInputEmailIsValid", "showValidationCrossMarkExplicit", "userInputEmail"), f = Ember.computed("userInputEmailIsValid", "showValidationCrossMarkExplicit", "userInputEmail"), m = Ember.computed("session.user.email", "userInputEmail"), g = Ember.computed.alias("hotline.ui.userCustomTz"), v = Ember._action, b = Ember._action, y = Ember._action, w = Ember._action, E = Ember._action, T = Ember._action, C = Ember._action, S = Ember._action, O = Ember._action, M = Ember._action, I = Ember._action, i((_ = function(e) {
                (0, F.Z)(n, e);
                var t = ne(n);

                function n() {
                    var e;
                    (0, N.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, V.Z)((0, x.Z)(e), "images", {
                        AgentDefault: ee.Z,
                        CalUser: te.Z
                    }), (0, D.Z)((0, x.Z)(e), "userInputEmailIsValid", A, (0, x.Z)(e)), (0, D.Z)((0, x.Z)(e), "userCustomTimeZone", P, (0, x.Z)(e)), e
                }
                return (0, Z.Z)(n, [{
                    key: "init",
                    value: function() {
                        var e, t, i, o;
                        (0, B.Z)((0, U.Z)(n.prototype), "init", this).apply(this, arguments), this.set("isLoadingSlots", !0), this.set("userEmailSubmitted", !1);
                        var s = (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (i = this.session) || void 0 === i || null === (o = i.user) || void 0 === o ? void 0 : o.workEmail);
                        s && this.set("userInputEmail", s)
                    }
                }, {
                    key: "noSlotsAvailable",
                    get: function() {
                        return !this.isLoadingSlots && !this.firstFreeTimeSlots
                    }
                }, {
                    key: "getCalendarData",
                    value: function() {
                        var e, t = this,
                            n = null === (e = this.messageMetaData) || void 0 === e ? void 0 : e.calendarMessageMeta,
                            i = n && n.calendarAgentAlias,
                            o = n && n.calendarProviderType;
                        this.store.findRecord("calendarAvailInfo", i, {
                            adapterOptions: {
                                calendarProviderType: o
                            },
                            reload: !0
                        }).then(function(e) {
                            (0, R.Z)(this, t), Ember.setProperties(this, {
                                isLoadingSlots: !1,
                                freeSlots: e.get("calendarTimeSlots"),
                                meetingLength: e.get("meetingLength"),
                                bufferTime: e.get("bufferTime"),
                                minNoticeTime: e.get("minNoticeTime"),
                                calendarType: e.get("calendarType")
                            })
                        }.bind(this))
                    }
                }, {
                    key: "agentData",
                    get: function() {
                        var e, t = null === (e = this.messageMetaData) || void 0 === e ? void 0 : e.calendarMessageMeta,
                            n = t && t.calendarAgentAlias;
                        return n ? this.agentService.getAgentInfo(n) : null
                    }
                }, {
                    key: "freshIdAgentPic",
                    get: function() {
                        var e, t, n, i, o, s = null === (e = this.messageMetaData) || void 0 === e || null === (t = e.calendarMessageMeta) || void 0 === t ? void 0 : t.calendarAgentAlias;
                        return null !== (n = this.hotlineUI) && void 0 !== n && null !== (i = n.config) && void 0 !== i && i.sales360App ? (0, $.freshIdAgentPicUrl)(null === (o = this.session) || void 0 === o ? void 0 : o.token, s) : ""
                    }
                }, {
                    key: "userPicUrl",
                    get: function() {
                        var e, t, n, i;
                        return null !== (e = this.session) && void 0 !== e && null !== (t = e.user) && void 0 !== t && t.isNameGenerated ? null : null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.profilePicThumbUrl
                    }
                }, {
                    key: "timeSlotToBeBooked",
                    get: function() {
                        var e, t, n = this.userTimeZoneToUse,
                            i = null === (e = this.message) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.meetingStartTime,
                            o = this.meetingLengthAsMillis;
                        if (i && o) {
                            var s = (0, z.default)(q.default.convert(i + o, n)).format("LT");
                            return (0, z.default)(q.default.convert(i, n)).format("LT") + " - " + s
                        }
                        return ""
                    }
                }, {
                    key: "dateToBeBooked",
                    get: function() {
                        var e, t, n = null === (e = this.message) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.meetingStartTime,
                            i = this.userTimeZoneToUse;
                        return n && (0, z.default)(q.default.convert(n, i)).format("dddd") + ", " + (0, z.default)(q.default.convert(n, i)).format("LL")
                    }
                }, {
                    key: "createCalendarBookingFrag",
                    value: function(e, t) {
                        var n = this.meetingLengthAsMillis + e,
                            i = this.calendarType;
                        return {
                            fragmentType: Y.default.CONVERSATION.FRAGMENT_TYPE.MEETING,
                            startMillis: e,
                            endMillis: n,
                            eventProviderType: i,
                            userTimeZone: t,
                            isPendingCreation: !0
                        }
                    }
                }, {
                    key: "createCalendarCancelledFrag",
                    value: function() {
                        return {
                            fragmentType: Y.default.CONVERSATION.FRAGMENT_TYPE.TEXT,
                            content: this.intl.t("calendar.user_cancelled")
                        }
                    }
                }, {
                    key: "markCalendarInviteAsBooked",
                    value: function(e) {
                        Ember.set(e, "isCalendarInviteBooked", !0), e.save()
                    }
                }, {
                    key: "allTimeZones",
                    get: function() {
                        return q.default.listTimeZones()
                    }
                }, {
                    key: "filteredTimeZones",
                    get: function() {
                        var e = this.timeZoneFilterValue,
                            t = this.allTimeZones;
                        if (e) {
                            var n = [],
                                i = t && t.length;
                            e = e.toLowerCase();
                            for (var o = 0; o < i; o++) {
                                var s = t[o] && t[o].toLowerCase();
                                s && s.indexOf(e) > -1 && n.push(t[o])
                            }
                            return n
                        }
                        return t
                    }
                }, {
                    key: "emailIconClass",
                    get: function() {
                        return this.userInputEmailIsValid ? "ic-goto-next-screen icon-chevron_right_regular" : this.showValidationCrossMarkExplicit ? "ic-invalid-input icon-times_circle_solid" : "ic-empty-input icon-chevron_right_solid"
                    }
                }, {
                    key: "emailTooltip",
                    get: function() {
                        return this.userInputEmailIsValid ? this.intl.t("calendar.tooltips.valid_email") : this.showValidationCrossMarkExplicit ? this.intl.t("calendar.tooltips.invalid_email") : this.intl.t("calendar.tooltips.no_email")
                    }
                }, {
                    key: "updateUserEmail",
                    value: function() {
                        var e, t, n, i, o, s, a, l = this,
                            r = Y.default.EmberModelUrl.updateUser,
                            u = this.store,
                            c = {
                                user: {
                                    email: this.userInputEmail,
                                    id: null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.id,
                                    alias: null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.alias
                                }
                            };
                        u.putRequest(r.model, (0, X.default)({
                            url: r.url,
                            token: null === (o = this.session) || void 0 === o ? void 0 : o.token,
                            alias: null === (s = this.session) || void 0 === s || null === (a = s.user) || void 0 === a ? void 0 : a.alias
                        }, this.session, this.isJWTEnabled()), c).then(function(e) {
                            (0, R.Z)(this, l), this.set("session.user.email", e.email), this.getCalendarData(), this.scrollToLastCalendarPicker(20)
                        }.bind(this)).catch(function() {
                            (0, R.Z)(this, l)
                        }.bind(this))
                    }
                }, {
                    key: "shouldUpdateUserEmail",
                    get: function() {
                        var e, t, n, i;
                        return ((null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) || (null === (n = this.session) || void 0 === n || null === (i = n.user) || void 0 === i ? void 0 : i.workEmail)) !== this.userInputEmail
                    }
                }, {
                    key: "maximizeCalendarPicker",
                    value: function() {
                        this.send("resetSlot");
                        var e = {
                            slotsData: this.sessionalizedCalendarSlots,
                            meetingLength: this.meetingLength,
                            message: this.message
                        };
                        this.openCalendarPickerMaximized(e), J.default.moveFocusTo(".cal-weekday-details")
                    }
                }, {
                    key: "resetSlot",
                    value: function() {
                        var e = this.message;
                        Ember.set(e, "internalMeta.meetingStartTime", null), e.save(), J.default.moveFocusTo(".calendar-picker-minified")
                    }
                }, {
                    key: "cancelInvite",
                    value: function() {
                        var e = [];
                        e.push(this.createCalendarCancelledFrag()), this.markCalendarInviteAsBooked(this.message), this.sendMessageFromAppConversation(e, {
                            internalMeta: this.messageMetaData,
                            messageType: Y.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.CANCELLED_BY_USER
                        }), J.default.moveFocusTo("#app-conversation-editor")
                    }
                }, {
                    key: "setSlot",
                    value: function(e) {
                        var t = this.message;
                        Ember.set(t, "internalMeta.meetingStartTime", e.from), t.save()
                    }
                }, {
                    key: "userEmailNextPress",
                    value: function() {
                        this.userInputEmail && this.send("userEmailEnterPress")
                    }
                }, {
                    key: "userEmailEnterPress",
                    value: function() {
                        this.userInputEmailIsValid ? (this.set("showValidationCheckMark", !0), this.set("userEmailSubmitted", !0), this.shouldUpdateUserEmail ? this.updateUserEmail(this.userInputEmail) : (this.getCalendarData(), this.scrollToLastCalendarPicker(20))) : this.set("showValidationCrossMarkExplicit", !0), J.default.moveFocusTo(".calendar-picker-minified")
                    }
                }, {
                    key: "bookSlot",
                    value: function() {
                        var e, t, n, i, o, s, a = this.userInputEmail;
                        a != (null === (e = this.session) || void 0 === e || null === (t = e.user) || void 0 === t ? void 0 : t.email) && this.set("session.user.email", a);
                        var l = this.messageMetaData,
                            r = null === (n = this.message) || void 0 === n || null === (i = n.internalMeta) || void 0 === i ? void 0 : i.meetingStartTime,
                            u = a || (null === (o = this.session) || void 0 === o || null === (s = o.user) || void 0 === s ? void 0 : s.email),
                            c = this.userTimeZoneToUse,
                            d = [];
                        l && l.calendarMessageMeta && u && (l.calendarMessageMeta.calendarBookingEmail = u), d.push(this.createCalendarBookingFrag(r, c)), this.markCalendarInviteAsBooked(this.message), this.sendMessageFromAppConversation(d, {
                            internalMeta: l
                        }), J.default.moveFocusTo("#app-conversation-editor"), this.scrollToBottomWithDelay(20)
                    }
                }, {
                    key: "setUserCustomTimezone",
                    value: function(e) {
                        this.set("hotline.ui.userCustomTz", e), this.set("isTimeZoneSelectMode", !1)
                    }
                }, {
                    key: "switchToTimeZoneSelectMode",
                    value: function() {
                        this.set("isTimeZoneSelectMode", !0), J.default.onDropDownOpen(".time-zone-list-item", ".time-zone-input", !0)
                    }
                }, {
                    key: "dropDownKeyboardEvent",
                    value: function() {
                        J.default.hideDropDownOnFocusOut(event, "closeTimeZoneSelectMode", this), J.default.changeFocusOnArrowKeyPress(event, null, {
                            sourceElem: ".time-zone-input",
                            optionsSelector: ".time-zone-list-item",
                            scrollContainer: ".time-zones-container",
                            arrowTypes: "up-down",
                            isDropDown: !0
                        })
                    }
                }, {
                    key: "closeTimeZoneSelectMode",
                    value: function() {
                        this.set("isTimeZoneSelectMode", !1)
                    }
                }]), n
            }(Ember.Component.extend(W.default, K.default, Q.default)), (0, j.Z)(_.prototype, "noSlotsAvailable", [o], Object.getOwnPropertyDescriptor(_.prototype, "noSlotsAvailable"), _.prototype), (0, j.Z)(_.prototype, "agentData", [s], Object.getOwnPropertyDescriptor(_.prototype, "agentData"), _.prototype), (0, j.Z)(_.prototype, "freshIdAgentPic", [a], Object.getOwnPropertyDescriptor(_.prototype, "freshIdAgentPic"), _.prototype), (0, j.Z)(_.prototype, "userPicUrl", [l], Object.getOwnPropertyDescriptor(_.prototype, "userPicUrl"), _.prototype), A = (0, j.Z)(_.prototype, "userInputEmailIsValid", [r], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, j.Z)(_.prototype, "timeSlotToBeBooked", [u], Object.getOwnPropertyDescriptor(_.prototype, "timeSlotToBeBooked"), _.prototype), (0, j.Z)(_.prototype, "dateToBeBooked", [c], Object.getOwnPropertyDescriptor(_.prototype, "dateToBeBooked"), _.prototype), (0, j.Z)(_.prototype, "allTimeZones", [d], Object.getOwnPropertyDescriptor(_.prototype, "allTimeZones"), _.prototype), (0, j.Z)(_.prototype, "filteredTimeZones", [p], Object.getOwnPropertyDescriptor(_.prototype, "filteredTimeZones"), _.prototype), (0, j.Z)(_.prototype, "emailIconClass", [h], Object.getOwnPropertyDescriptor(_.prototype, "emailIconClass"), _.prototype), (0, j.Z)(_.prototype, "emailTooltip", [f], Object.getOwnPropertyDescriptor(_.prototype, "emailTooltip"), _.prototype), (0, j.Z)(_.prototype, "shouldUpdateUserEmail", [m], Object.getOwnPropertyDescriptor(_.prototype, "shouldUpdateUserEmail"), _.prototype), P = (0, j.Z)(_.prototype, "userCustomTimeZone", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, j.Z)(_.prototype, "maximizeCalendarPicker", [v], Object.getOwnPropertyDescriptor(_.prototype, "maximizeCalendarPicker"), _.prototype), (0, j.Z)(_.prototype, "resetSlot", [b], Object.getOwnPropertyDescriptor(_.prototype, "resetSlot"), _.prototype), (0, j.Z)(_.prototype, "cancelInvite", [y], Object.getOwnPropertyDescriptor(_.prototype, "cancelInvite"), _.prototype), (0, j.Z)(_.prototype, "setSlot", [w], Object.getOwnPropertyDescriptor(_.prototype, "setSlot"), _.prototype), (0, j.Z)(_.prototype, "userEmailNextPress", [E], Object.getOwnPropertyDescriptor(_.prototype, "userEmailNextPress"), _.prototype), (0, j.Z)(_.prototype, "userEmailEnterPress", [T], Object.getOwnPropertyDescriptor(_.prototype, "userEmailEnterPress"), _.prototype), (0, j.Z)(_.prototype, "bookSlot", [C], Object.getOwnPropertyDescriptor(_.prototype, "bookSlot"), _.prototype), (0, j.Z)(_.prototype, "setUserCustomTimezone", [S], Object.getOwnPropertyDescriptor(_.prototype, "setUserCustomTimezone"), _.prototype), (0, j.Z)(_.prototype, "switchToTimeZoneSelectMode", [O], Object.getOwnPropertyDescriptor(_.prototype, "switchToTimeZoneSelectMode"), _.prototype), (0, j.Z)(_.prototype, "dropDownKeyboardEvent", [M], Object.getOwnPropertyDescriptor(_.prototype, "dropDownKeyboardEvent"), _.prototype), (0, j.Z)(_.prototype, "closeTimeZoneSelectMode", [I], Object.getOwnPropertyDescriptor(_.prototype, "closeTimeZoneSelectMode"), _.prototype), k = _)) || k)
        },
        74902: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(70387);
            t.default = Ember.Component.extend({
                actions: {
                    bookSlot: function(e) {
                        this.bookSlot(e), i.default.moveFocusTo(".calendar-picker-minified")
                    },
                    openConfirmationView: function(e) {
                        this.openConfirmationView(e)
                    }
                }
            })
        },
        45102: function(e, t, n) {
            "use strict";
            n.r(t), t.default = Ember.Component.extend({
                classNames: ["chip"]
            })
        },
        52515: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return f
                }
            });
            var i, o, s, a, l = n(34645),
                r = n(5660),
                u = n(58678),
                c = n(55411),
                d = n(79833),
                p = n(13256);

            function h(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, d.Z)(e);
                    if (t) {
                        var o = (0, d.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, c.Z)(this, n)
                }
            }
            var f = (i = Ember.computed("fromDate"), o = Ember.computed("toDate"), s = Ember._action, a = function(e) {
                (0, u.Z)(n, e);
                var t = h(n);

                function n() {
                    return (0, l.Z)(this, n), t.apply(this, arguments)
                }
                return (0, r.Z)(n, [{
                    key: "minDate",
                    get: function() {
                        return new Date(this.fromDate)
                    }
                }, {
                    key: "maxDate",
                    get: function() {
                        return new Date(this.toDate)
                    }
                }, {
                    key: "onChangeDate",
                    value: function(e, t) {
                        this.onSelect(e, t)
                    }
                }]), n
            }(Ember.Component.extend()), (0, p.Z)(a.prototype, "minDate", [i], Object.getOwnPropertyDescriptor(a.prototype, "minDate"), a.prototype), (0, p.Z)(a.prototype, "maxDate", [o], Object.getOwnPropertyDescriptor(a.prototype, "maxDate"), a.prototype), (0, p.Z)(a.prototype, "onChangeDate", [s], Object.getOwnPropertyDescriptor(a.prototype, "onChangeDate"), a.prototype), a)
        },
        34354: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return w
                }
            });
            var i, o, s, a, l, r, u = n(10935),
                c = n(34645),
                d = n(5660),
                p = n(69049),
                h = n(58678),
                f = n(55411),
                m = n(79833),
                g = n(52626),
                v = n(13256),
                b = n(76144);

            function y(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, m.Z)(e);
                    if (t) {
                        var o = (0, m.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, f.Z)(this, n)
                }
            }
            var w = (i = Ember._tracked, o = Ember._action, s = Ember._action, a = Ember._action, l = function(e) {
                (0, h.Z)(n, e);
                var t = y(n);

                function n() {
                    var e;
                    (0, c.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, g.Z)((0, p.Z)(e), "bindLabel", "label"), (0, u.Z)((0, p.Z)(e), "activeClassIndex", r, (0, p.Z)(e)), e
                }
                return (0, d.Z)(n, [{
                    key: "updateActiveClass",
                    value: function(e) {
                        this.activeClassIndex = e
                    }
                }, {
                    key: "onSelect",
                    value: function(e) {
                        return this.handleSeletion(e)
                    }
                }, {
                    key: "onEnter",
                    value: function(e) {
                        var t = this.args.items[e];
                        return this.handleSeletion(t)
                    }
                }, {
                    key: "handleSeletion",
                    value: function(e) {
                        var t, n, i;
                        return null === (t = this.args.dropdown) || void 0 === t || t.actions.close(), null === (n = (i = this.args).selectionHandler) || void 0 === n ? void 0 : n.call(i, e)
                    }
                }]), n
            }(b.default), r = (0, v.Z)(l.prototype, "activeClassIndex", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }), (0, v.Z)(l.prototype, "updateActiveClass", [o], Object.getOwnPropertyDescriptor(l.prototype, "updateActiveClass"), l.prototype), (0, v.Z)(l.prototype, "onSelect", [s], Object.getOwnPropertyDescriptor(l.prototype, "onSelect"), l.prototype), (0, v.Z)(l.prototype, "onEnter", [a], Object.getOwnPropertyDescriptor(l.prototype, "onEnter"), l.prototype), l)
        },
        38471: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return b
                }
            });
            var i, o, s, a, l, r = n(10935),
                u = n(34645),
                c = n(5660),
                d = n(69049),
                p = n(58678),
                h = n(55411),
                f = n(79833),
                m = n(13256),
                g = n(76144);

            function v(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, f.Z)(e);
                    if (t) {
                        var o = (0, f.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, h.Z)(this, n)
                }
            }
            var b = (i = Ember._tracked, o = Ember._action, s = Ember._action, a = function(e) {
                (0, p.Z)(n, e);
                var t = v(n);

                function n() {
                    var e;
                    (0, u.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, r.Z)((0, d.Z)(e), "editorText", l, (0, d.Z)(e)), e
                }
                return (0, c.Z)(n, [{
                    key: "slashQuickActionsText",
                    get: function() {
                        var e = this.editorText;
                        return e && 0 === e.trim().indexOf("/") ? e : ""
                    }
                }, {
                    key: "keyPressUp",
                    value: function(e, t) {
                        this.editorText = t
                    }
                }, {
                    key: "handleSelectionHandler",
                    value: function(e) {
                        var t, n;
                        null === (t = (n = this.args).onQuickActionSelect) || void 0 === t || t.call(n, e), this.editorText = ""
                    }
                }]), n
            }(g.default), l = (0, m.Z)(a.prototype, "editorText", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }), (0, m.Z)(a.prototype, "keyPressUp", [o], Object.getOwnPropertyDescriptor(a.prototype, "keyPressUp"), a.prototype), (0, m.Z)(a.prototype, "handleSelectionHandler", [s], Object.getOwnPropertyDescriptor(a.prototype, "handleSelectionHandler"), a.prototype), a)
        },
        15611: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return h
                }
            });
            var i, o, s = n(34645),
                a = n(5660),
                l = n(58678),
                r = n(55411),
                u = n(79833),
                c = n(13256),
                d = n(76144);

            function p(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, r.Z)(this, n)
                }
            }
            var h = (i = Ember.computed(), o = function(e) {
                (0, l.Z)(n, e);
                var t = p(n);

                function n() {
                    return (0, s.Z)(this, n), t.apply(this, arguments)
                }
                return (0, a.Z)(n, [{
                    key: "ellipsisAlignemnt",
                    get: function() {
                        var e = "";
                        return "horizontal" === this.args.alignment && (e = "M10 8.44995C10.8561 8.44995 11.55 9.14391 11.55 9.99995C11.55 10.856 10.8561 11.55 10 11.55C9.14397 11.55 8.45001 10.856 8.45001 9.99995C8.45001 9.14391 9.14397 8.44995 10 8.44995ZM5.09 9.99995C5.08473 9.59681 4.91951 9.21228 4.6307 8.93097C4.34188 8.64965 3.95314 8.49461 3.55 8.49995C3.14514 8.49192 2.75382 8.64578 2.46283 8.92738C2.17184 9.20898 2.00525 9.59505 2 9.99995C2.00525 10.4049 2.17184 10.7909 2.46283 11.0725C2.75382 11.3541 3.14514 11.508 3.55 11.5C3.95314 11.5053 4.34188 11.3502 4.6307 11.0689C4.91951 10.7876 5.08473 10.4031 5.09 9.99995ZM16.45 8.49995C16.8549 8.49192 17.2462 8.64577 17.5372 8.92738C17.8282 9.20898 17.9948 9.59505 18 9.99995C17.9352 10.8051 17.2628 11.4256 16.455 11.4256C15.6472 11.4256 14.9748 10.8051 14.91 9.99995C14.9153 9.59681 15.0805 9.21228 15.3693 8.93097C15.6581 8.64965 16.0469 8.49461 16.45 8.49995Z"), "vertical" === this.args.alignment && (e = "M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"), e
                    }
                }]), n
            }(d.default), (0, c.Z)(o.prototype, "ellipsisAlignemnt", [i], Object.getOwnPropertyDescriptor(o.prototype, "ellipsisAlignemnt"), o.prototype), o)
        },
        11262: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return k
                }
            });
            var i, o, s, a, l, r, u, c, d, p = n(10935),
                h = n(34645),
                f = n(5660),
                m = n(69049),
                g = n(28433),
                v = n(58678),
                b = n(55411),
                y = n(79833),
                w = n(52626),
                E = n(13256),
                T = n(18006),
                C = n(475),
                S = n(13418),
                O = n(7259),
                M = n(57041);

            function I(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, y.Z)(e);
                    if (t) {
                        var o = (0, y.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, b.Z)(this, n)
                }
            }
            var k = (i = (0, T.tagName)("div"), o = (0, T.classNames)("fc-feedback"), s = Ember._tracked, a = Ember._action, l = Ember._action, r = Ember._action, i(u = o((c = function(e) {
                (0, v.Z)(n, e);
                var t = I(n);

                function n() {
                    var e;
                    (0, h.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, p.Z)((0, m.Z)(e), "isValueInEditor", d, (0, m.Z)(e)), (0, w.Z)((0, m.Z)(e), "images", {
                        ValidationErrorIcon: M.Z
                    }), e
                }
                return (0, f.Z)(n, [{
                    key: "init",
                    value: function() {
                        for (var e, t = arguments.length, i = new Array(t), o = 0; o < t; o++) i[o] = arguments[o];
                        (e = (0, g.Z)((0, y.Z)(n.prototype), "init", this)).call.apply(e, [this].concat(i));
                        var s = S.default.TemplateType,
                            a = s.FEEDBACK_RATING,
                            l = s.FEEDBACK_OPINION_POLL,
                            r = s.FEEDBACK_COMMENT;
                        this.setProperties({
                            FEEDBACK_RATING: a,
                            FEEDBACK_OPINION_POLL: l,
                            FEEDBACK_COMMENT: r,
                            isFeedbackCommentTextLengthExceeded: !1
                        })
                    }
                }, {
                    key: "hasValueInEditor",
                    value: function(e) {
                        this.isValueInEditor = e
                    }
                }, {
                    key: "sendMessageFromMobile",
                    value: function() {
                        if (this.isValueInEditor) {
                            var e = document.querySelector("#".concat(this.feedbackCommentId));
                            this.keyPressDownFeedbackComment(null, null == e ? void 0 : e.innerText, !0), this.isValueInEditor = !1
                        }
                    }
                }, {
                    key: "submitBotFeedback",
                    value: function(e) {
                        var t = S.default.TemplateType,
                            n = t.FEEDBACK_RATING,
                            i = t.FEEDBACK_OPINION_POLL,
                            o = t.FEEDBACK_COMMENT,
                            s = "";
                        this.feedbackType === n ? s = null == e ? void 0 : e.displayOrder : this.feedbackType === i ? s = null == e ? void 0 : e.label : this.feedbackType === o && (s = null == e ? void 0 : e.content), this.onSelect({
                            fragmentType: 1,
                            contentType: "text/html",
                            content: s,
                            isFeedbackMessage: !0
                        })
                    }
                }, {
                    key: "keyPressDownFeedbackComment",
                    value: function(e, t) {
                        var n, i, o, s = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
                            a = s ? t : null == t || null === (n = t.target) || void 0 === n ? void 0 : n.innerText,
                            l = null != a && a.length ? a.replace(/<[^>]*>?/gm, "") : "",
                            r = (null == l ? void 0 : l.length) && (null == l ? void 0 : l.length) <= 500;
                        null != l && l.length && !r ? null === (i = this.parentView) || void 0 === i || i.set("isFeedbackCommentTextLengthExceeded", !0) : null === (o = this.parentView) || void 0 === o || o.set("isFeedbackCommentTextLengthExceeded", !1);
                        var u = {
                            content: l
                        };
                        if (s)(0, C.isSlashCmdMenuVisible)() || null == this || this.submitBotFeedback(u);
                        else if (t.which === S.default.KEYCODES.ENTER && r) {
                            var c;
                            if (t.preventDefault(), !(0, C.isSlashCmdMenuVisible)()) null == this || null === (c = this.parentView) || void 0 === c || c.submitBotFeedback(u)
                        }
                    }
                }]), n
            }(Ember.Component.extend(O.default)), d = (0, E.Z)(c.prototype, "isValueInEditor", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), (0, E.Z)(c.prototype, "hasValueInEditor", [a], Object.getOwnPropertyDescriptor(c.prototype, "hasValueInEditor"), c.prototype), (0, E.Z)(c.prototype, "sendMessageFromMobile", [l], Object.getOwnPropertyDescriptor(c.prototype, "sendMessageFromMobile"), c.prototype), (0, E.Z)(c.prototype, "submitBotFeedback", [r], Object.getOwnPropertyDescriptor(c.prototype, "submitBotFeedback"), c.prototype), u = c)) || u) || u)
        },
        95124: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(89567),
                s = n(13418),
                a = n(22126),
                l = n(7259),
                r = n(11731),
                u = n(50660),
                c = n(90123),
                d = n(71259),
                p = n(95984),
                h = n(16686);
            t.default = Ember.Component.extend(a.default, l.default, c.default, r.default, u.default, {
                CONVERSATION: s.default.CONVERSATION,
                MESSAGE_STATUS: s.default.MESSAGE_STATUS,
                CO_BROWSING_SUPPORT_URL: s.default.SUPPORT_URLS.CO_BROWSING,
                tagName: "li",
                classNames: ["fc-ui-message", "message-container"],
                screenshare: Ember.inject.service(),
                classNameBindings: ["model.userMessage:odd", "isGrpEnd:grp-ended", "isGrpStart:grp-started", "model.userMessage::agent-msg"],
                liveTranslation: Ember.inject.service(),
                postMessage: Ember.inject.service("post-message"),
                enabledBetaFeatures: Ember.computed.alias("hotlineUI.config.betaFeatures"),
                init: function() {
                    var e, t, n, o = this;
                    this._super.apply(this, arguments);
                    var a = this.model,
                        l = a.get("messageFragments") && a.get("messageFragments")[0],
                        r = a.get("messageFragments") && a.get("messageFragments").length,
                        u = null === (e = this.model) || void 0 === e ? void 0 : e.createdMillis,
                        c = this.readMillis,
                        d = null === (t = this.model) || void 0 === t ? void 0 : t.messageUserType,
                        p = null === (n = this.model) || void 0 === n ? void 0 : n.messageType,
                        f = this.messagesArray;
                    Ember.setProperties(this, {
                        showTranslatedText: !1,
                        isMuted: !1
                    }), l && 1 === r && l.fragmentType !== s.default.CONVERSATION.FRAGMENT_TYPE.IMAGE && a.set("emojisCount", this.getConsecutiveEmojisCount((0, h.sanitizeHTML)(this, l.content, "strict"))), 0 === d && f && f.isAny("hasReadReceipt", !0) && setTimeout(function() {
                        (0, i.Z)(this, o), f.setEach("hasReadReceipt", !1)
                    }.bind(this), 1), c && c < u && 0 !== d && p !== s.default.CONVERSATION.MESSAGE_TYPE.SCREEN_SHARE && f && !f.isAny("hasReadReceipt", !0) && setTimeout(Ember.set(this.model, "hasReadReceipt", !0), 1)
                },
                isCalendarInviteMessage: Ember.computed.equal("model.messageType", s.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT),
                isFlowCalendarInviteMessage: Ember.computed("isCalendarInviteMessage", {
                    get: function() {
                        var e;
                        return this.isCalendarInviteMessage && (null === (e = this.model) || void 0 === e ? void 0 : e.flowStepId)
                    }
                }),
                isUserPrivateMessage: Ember.computed("model.messageType", "enabledBetaFeatures", {
                    get: function() {
                        var e;
                        return (null === (e = this.model) || void 0 === e ? void 0 : e.messageType) === s.default.CONVERSATION.MESSAGE_TYPE.USER_PRIVATE_MESSAGE && this.enabledBetaFeatures[s.default.widgetReOpenEvent]
                    }
                }),
                messageMetaData: Ember.computed("isCalendarInviteMessage", {
                    get: function() {
                        var e;
                        return this.isCalendarInviteMessage ? null === (e = this.model) || void 0 === e ? void 0 : e.internalMeta : null
                    }
                }),
                shouldDisplayCalendarPicker: Ember.computed("isCalendarInviteMessage", "iscalendarMessageResponded", {
                    get: function() {
                        var e;
                        return !!this.isCalendarInviteMessage && !(null !== (e = this.model) && void 0 !== e && e.isCalendarInviteBooked || this.iscalendarMessageResponded)
                    }
                }),
                flowCalendarResponded: Ember.computed("shouldDisplayCalendarPicker", "isFlowCalendarInviteMessage", {
                    get: function() {
                        return !this.shouldDisplayCalendarPicker && this.isFlowCalendarInviteMessage
                    }
                }),
                iscalendarMessageResponded: Ember.computed("shouldDisplayCalendarPicker", "calendarMessages", {
                    get: function() {
                        var e, t, n = this.calendarMessages,
                            i = null === (e = this.model) || void 0 === e || null === (t = e.internalMeta) || void 0 === t ? void 0 : t.calendarInviteId;
                        if (i) {
                            var o = n && n.filterBy("internalMeta.calendarInviteId", i);
                            if (o && o.length > 1) return !0
                        }
                        return !1
                    }
                }),
                isFreddyLiveTranslateEnabled: Ember.computed("hotline.ui.config.freddyLiveTranslationConfig.enabled", {
                    get: function() {
                        var e, t, n, i;
                        return null === (e = this.hotline) || void 0 === e || null === (t = e.ui) || void 0 === t || null === (n = t.config) || void 0 === n || null === (i = n.freddyLiveTranslationConfig) || void 0 === i ? void 0 : i.enabled
                    }
                }),
                showOfflineForm: Ember.computed("model", "model.{hasBeenRepliedToOffline,offlineMessage}", {
                    get: function() {
                        var e = this.model,
                            t = e && e.get("hasBeenRepliedToOffline");
                        return !(!e || !e.get("offlineMessage") || t)
                    }
                }),
                yesterdayMillis: Ember.computed({
                    get: function() {
                        return (0, o.default)().subtract(1, "day").startOf("day").valueOf()
                    }
                }),
                hideName: Ember.computed.alias("session.config.agent.hideName"),
                hidePic: Ember.computed.alias("session.config.agent.hidePic"),
                isAwayMessage: Ember.computed("model", "model.source", {
                    get: function() {
                        var e, t = null === (e = this.model) || void 0 === e ? void 0 : e.source;
                        return t === s.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE || t === s.default.CONVERSATION.MESSAGE_SOURCE.OFFLINE_THANK_MESSAGE || t === s.default.CONVERSATION.MESSAGE_SOURCE.BH_AWAY_MESSAGE
                    }
                }),
                agentName: Ember.computed("model", "model.{messageUserType,messageType}", "hideName", {
                    get: function() {
                        var e, t, n, i, o, a = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserType,
                            l = null === (t = this.model) || void 0 === t ? void 0 : t.messageType,
                            r = null === (n = this.session) || void 0 === n ? void 0 : n.appDisplayName,
                            u = null === (i = this.model) || void 0 === i ? void 0 : i.messageUserFirstName,
                            c = a && a === s.default.CONVERSATION.USER_TYPE.CHANNEL,
                            d = a && a !== s.default.CONVERSATION.USER_TYPE.USER,
                            p = l === s.default.CONVERSATION.MESSAGE_TYPE.BOT || l === s.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT || l === s.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT && (null === (o = this.model) || void 0 === o ? void 0 : o.flowId),
                            h = this.hideName,
                            f = this.isAwayMessage;
                        return c || f ? r : d ? h && !p ? r : u : null
                    }
                }),
                freshIdAgentPic: Ember.computed("model.{messageUserId,messageUserAlias}", {
                    get: function() {
                        var e, t, n, i, o = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserAlias;
                        return null !== (t = this.hotlineUI) && void 0 !== t && null !== (n = t.config) && void 0 !== n && n.sales360App ? (0, d.freshIdAgentPicUrl)(null === (i = this.session) || void 0 === i ? void 0 : i.token, o) : ""
                    }
                }),
                agentPic: Ember.computed("model", "model.{messageUserId,messageUserAlias}", "hideName", "hidePic", "session.config.headerProperty.appLogo", {
                    get: function() {
                        var e, t, n, i, o = null === (e = this.model) || void 0 === e ? void 0 : e.messageUserAlias,
                            a = this.hidePic,
                            l = null === (t = this.model) || void 0 === t ? void 0 : t.messageType,
                            r = l === s.default.CONVERSATION.MESSAGE_TYPE.BOT || l === s.default.CONVERSATION.MESSAGE_TYPE.FREDDY_BOT || l === s.default.CONVERSATION.MESSAGE_TYPE.CALENDAR.SENT_BY_AGENT && (null === (n = this.model) || void 0 === n ? void 0 : n.flowId),
                            u = this.isAwayMessage;
                        return !o || a && !r || u ? null !== (i = this.session) && void 0 !== i && i.appLogoUrl ? Ember.Object.create({
                            profilePicThumbUrl: this.session.appLogoUrl
                        }) : Ember.Object.create({
                            profilePicThumbUrl: ""
                        }) : this.agentService.getAgentInfo(o)
                    }
                }),
                screenshareControl: Ember.computed("model.messageFragments.[]", {
                    get: function() {
                        var e = this.model;
                        return (e.get("messageFragments") && e.get("messageFragments").length && e.get("messageFragments")[0] && e.get("messageFragments")[0].content) !== this.intl.t("screenShare.screen_share_compare").toString()
                    }
                }),
                isArticleView: Ember.computed("model", "messageFragments.[]", {
                    get: function() {
                        var e = this.model,
                            t = !1;
                        if (e) {
                            var n = e.messageFragments,
                                i = n && n.length;
                            if (i > 0)
                                for (var o = 0; o < i; o++) {
                                    var s = n[o];
                                    if (s && s.fragmentType === this.CONVERSATION.FRAGMENT_TYPE.COLLECTION) {
                                        t = !0;
                                        break
                                    }
                                }
                        }
                        return t
                    }
                }),
                isGrpStart: Ember.computed("lastMessage", "model", "lastMessage.{messageUserId,messageUserType,messageType}", "model.{messageUserId,messageUserType,messageType}", {
                    get: function() {
                        var e = this.lastMessage,
                            t = this.model,
                            n = e && t.get("createdMillis") - e.get("createdMillis");
                        return !e || n > 3e5 || e.get("messageUserType") !== t.get("messageUserType") || t.get("messageType") !== e.get("messageType") || t.get("messageUserId") !== e.get("messageUserId") || !0 === t.hasReadReceipt
                    }
                }),
                isGrpEnd: Ember.computed("nextMessage", "model", "nextMessage.{messageUserId,messageUserType,messageType}", "model.{messageUserId,messageUserType,messageType}", {
                    get: function() {
                        var e = this.nextMessage,
                            t = this.model,
                            n = e && e.get("createdMillis") - t.get("createdMillis");
                        return !e || n > 3e5 || e.get("messageUserType") !== t.get("messageUserType") || t.get("messageType") !== e.get("messageType") || t.get("messageUserId") !== e.get("messageUserId")
                    }
                }),
                showDayStamp: Ember.computed("model.createdMillis", "lastMessage", "nextMessage", {
                    get: function() {
                        var e = this.model,
                            t = this.lastMessage,
                            n = e.get("createdMillis"),
                            i = t && t.get("createdMillis"),
                            s = i && (0, o.default)(i).startOf("day").valueOf(),
                            a = i && (0, o.default)(i).endOf("day").valueOf();
                        return s && a && !(n >= s && n <= a)
                    }
                }),
                showTimeStamp: Ember.computed("isGrpEnd", "model.userMessage", {
                    get: function() {
                        var e;
                        return !(!this.isGrpEnd || null === (e = this.model) || void 0 === e || !e.userMessage)
                    }
                }),
                containsTranslations: Ember.computed("liveTranslation.isLiveTranslationEnabled", {
                    get: function() {
                        var e, t, n = this.model;
                        return (null === (e = this.liveTranslation) || void 0 === e ? void 0 : e.isLiveTranslationEnabled) && (null === (t = this.liveTranslation) || void 0 === t ? void 0 : t.containsTranslatedContent(n))
                    }
                }),
                getConsecutiveEmojisCount: function(e) {
                    var t, n, i = 0,
                        o = 0,
                        s = p.unicodeRegExp;
                    return e && (n = (t = e.replace(/\s/g, "")).match(s)) && n.length <= 3 && n.length > 0 && (n.forEach((function(e) {
                        i += e.length
                    })), i === t.length && (o = n.length)), o
                },
                actions: {
                    resendMessage: function(e) {
                        this.resendMessage(e)
                    },
                    sendOfflineMessage: function(e) {
                        this.sendOfflineMessage(e)
                    },
                    enlargeImage: function(e) {
                        var t, n = null === (t = this.hotline) || void 0 === t ? void 0 : t.ui;
                        Ember.set(n, "modalOpen", !0), Ember.set(n, "modal", {
                            imageUrl: e
                        }), parent.focus(), this.postMessage.post({
                            action: "expand_all",
                            picUrl: e
                        })
                    },
                    allowScreenShare: function() {
                        var e, t, n, o, a, l, r, u, c, d, p = this;
                        if (null !== (e = this.session) && void 0 !== e && null !== (t = e.config) && void 0 !== t && t.isFCSDKWebView) return this.flash.showMessage(this.intl.t("screenShare.not_supported_mobile")), !1;
                        var h = s.default.EmberModelUrl.cobrowsingSettings,
                            f = null === (n = this.model) || void 0 === n ? void 0 : n.messageId,
                            m = null === (o = this.model) || void 0 === o ? void 0 : o.cobrowsingId,
                            g = null === (a = this.model) || void 0 === a ? void 0 : a.channelId,
                            v = null === (l = this.session) || void 0 === l ? void 0 : l.user,
                            b = this.agentPic,
                            y = b && b.get("profilePicThumbUrl"),
                            w = v.appId,
                            E = v.name,
                            T = v.id,
                            C = null === (r = this.model) || void 0 === r ? void 0 : r.conversationId,
                            S = null === (u = this.model) || void 0 === u ? void 0 : u.messageUserId,
                            O = v.cobrowsingSessionData,
                            M = null === (c = this.model) || void 0 === c ? void 0 : c.messageUserName,
                            I = h.url.replace("{token}", null === (d = this.session) || void 0 === d ? void 0 : d.token),
                            k = {
                                messageId: f,
                                app_alias: w,
                                name: E,
                                role: "visitor",
                                viewerId: T,
                                conversationId: C,
                                sdata: O,
                                messageUserId: S,
                                agentName: M,
                                isMuted: !1,
                                cobrowsingId: m,
                                channelId: g,
                                pic: y
                            },
                            _ = function(e) {
                                (0, i.Z)(this, p), k.cobrowsingSettings = e.data ? e.data : e.response.data, this.postMessage.post({
                                    action: "startScreenShare",
                                    cbData: k
                                })
                            }.bind(this);
                        this.axios.makeRequest({
                            method: "GET",
                            url: I,
                            contentType: "application/json; charset=UTF-8"
                        }).then(_, _)
                    },
                    denyScreensShare: function() {
                        var e, t, n, i, o = null === (e = this.model) || void 0 === e ? void 0 : e.conversationId,
                            s = null === (t = this.session) || void 0 === t ? void 0 : t.token,
                            a = (null === (n = this.session) || void 0 === n ? void 0 : n.user).appId,
                            l = null === (i = this.model) || void 0 === i ? void 0 : i.messageId;
                        this.screenshare.deny({
                            token: s,
                            messageId: l,
                            app_alias: a,
                            conversationId: o
                        })
                    },
                    openCalendarPickerMaximized: function(e) {
                        this.openCalendarPickerMaximized(e)
                    },
                    sendMessage: function(e, t) {
                        this.sendMessage(e, t)
                    },
                    toggleTranslatedTextView: function() {
                        this.liveTranslation.isLiveTranslationEnabled && this.toggleProperty("showTranslatedText")
                    }
                }
            })
        },
        8233: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return O
                }
            });
            var i, o, s, a, l, r, u, c, d, p = n(5660),
                h = n(69049),
                f = n(58678),
                m = n(55411),
                g = n(79833),
                v = n(35235),
                b = n(10935),
                y = n(34645),
                w = n(52626),
                E = n(13256),
                T = n(76144);

            function C(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, g.Z)(e);
                    if (t) {
                        var o = (0, g.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, m.Z)(this, n)
                }
            }
            var S = (i = Ember._tracked, o = function e(t) {
                    var n = this;
                    (0, y.Z)(this, e), (0, b.Z)(this, "selected", s, this);
                    var i = t.sections.find(function(e) {
                        return (0, v.Z)(this, n), "label" === e.name
                    }.bind(this));
                    this.templateType = t.templateType, this.fragmentType = t.fragmentType, this.position = t.position, this.sections = t.sections, this.label = i.fragments[0].content
                }, s = (0, E.Z)(o.prototype, "selected", [i], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: function() {
                        return !1
                    }
                }), o),
                O = (a = Ember._tracked, l = Ember._action, r = Ember._action, u = Ember._action, c = function(e) {
                    (0, f.Z)(n, e);
                    var t = C(n);

                    function n() {
                        var e, i = this;
                        (0, y.Z)(this, n);
                        for (var o = arguments.length, s = new Array(o), a = 0; a < o; a++) s[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(s)), (0, w.Z)((0, h.Z)(e), "selectedButtons", []), (0, b.Z)((0, h.Z)(e), "count", d, (0, h.Z)(e)), (0, w.Z)((0, h.Z)(e), "buttonsData", e.args.buttons.map(function(e) {
                            return (0, v.Z)(this, i), new S(e)
                        }.bind(this))), e
                    }
                    return (0, p.Z)(n, [{
                        key: "deselectAll",
                        value: function() {
                            var e = this;
                            this.selectedButtons = [], this.count = 0, this.args.buttons.forEach(function(t, n) {
                                (0, v.Z)(this, e), this.buttonsData[n].selected = !1
                            }.bind(this))
                        }
                    }, {
                        key: "sendMessage",
                        value: function() {
                            this.args.sendMessage(this.selectedButtons)
                        }
                    }, {
                        key: "onSelect",
                        value: function(e, t) {
                            var n = this,
                                i = t.label,
                                o = function(e) {
                                    var t = this;
                                    return (0, v.Z)(this, n), e.find(function(e) {
                                        return (0, v.Z)(this, t), "label" === e.name
                                    }.bind(this))
                                }.bind(this),
                                s = function(e) {
                                    var t = this;
                                    return (0, v.Z)(this, n), e.find(function(e) {
                                        return (0, v.Z)(this, t), o(e.sections).fragments[0].content === i
                                    }.bind(this))
                                }.bind(this),
                                a = s(this.selectedButtons);
                            if (this.buttonsData[e].selected = !this.buttonsData[e].selected, a) this.selectedButtons = this.selectedButtons.filter(function(e) {
                                return (0, v.Z)(this, n), o(e.sections).fragments[0].content !== i
                            }.bind(this));
                            else {
                                var l = s(this.args.buttons);
                                this.selectedButtons.push(l)
                            }
                            this.count = this.selectedButtons.length
                        }
                    }]), n
                }(T.default), d = (0, E.Z)(c.prototype, "count", [a], {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    initializer: function() {
                        return 0
                    }
                }), (0, E.Z)(c.prototype, "deselectAll", [l], Object.getOwnPropertyDescriptor(c.prototype, "deselectAll"), c.prototype), (0, E.Z)(c.prototype, "sendMessage", [r], Object.getOwnPropertyDescriptor(c.prototype, "sendMessage"), c.prototype), (0, E.Z)(c.prototype, "onSelect", [u], Object.getOwnPropertyDescriptor(c.prototype, "onSelect"), c.prototype), c)
        },
        91313: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return I
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h = n(29436),
                f = n(35235),
                m = n(10935),
                g = n(34645),
                v = n(5660),
                b = n(69049),
                y = n(58678),
                w = n(55411),
                E = n(79833),
                T = n(52626),
                C = n(13256),
                S = n(76144),
                O = n(13418);

            function M(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, E.Z)(e);
                    if (t) {
                        var o = (0, E.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, w.Z)(this, n)
                }
            }
            var I = (i = Ember.inject.service, o = Ember.inject.service, s = Ember._tracked, a = Ember._action, l = Ember._action, r = Ember._action, u = function(e) {
                (0, y.Z)(i, e);
                var t = M(i);

                function i() {
                    var e;
                    (0, g.Z)(this, i);
                    for (var n = arguments.length, o = new Array(n), s = 0; s < n; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, T.Z)((0, b.Z)(e), "DOM_ID", O.default.DOM_ID), (0, m.Z)((0, b.Z)(e), "intl", c, (0, b.Z)(e)), (0, m.Z)((0, b.Z)(e), "hotline", d, (0, b.Z)(e)), (0, m.Z)((0, b.Z)(e), "isValueInEditor", p, (0, b.Z)(e)), e
                }
                return (0, v.Z)(i, [{
                    key: "initiateInput",
                    value: function() {
                        var e = this,
                            t = document.querySelector("#".concat(this.DOM_ID.phoneNumberWithCode));
                        Promise.all([n.e(9681).then(n.t.bind(n, 79681, 23)), n.e(6338).then(n.t.bind(n, 56338, 23))]).then(function(n) {
                            var i = this;
                            (0, f.Z)(this, e);
                            var o = (0, h.Z)(n, 1)[0].default(t, {
                                initialCountry: "US",
                                separateDialCode: !0,
                                dropdownContainer: document.querySelector("#append-country-list-ul"),
                                customPlaceholder: function() {
                                    return (0, f.Z)(this, i), this.intl.t(O.default.VALIDATION_PLACEHOLDER_MESSAGE.phone.placeholder)
                                }.bind(this)
                            });
                            Ember.set(this, "intlPhoneInput", o), this.args.setIntlPhoneInput(o), t.addEventListener("countrychange", function() {
                                (0, f.Z)(this, i);
                                var e = this.intlPhoneInput.getNumber();
                                if (e) {
                                    var t = [{
                                        content: e,
                                        contentType: "text/html",
                                        fragmentType: O.default.CONVERSATION.FRAGMENT_TYPE.TEXT
                                    }];
                                    this.args.sendButtonMessage(t, null, this.DOM_ID.phoneNumberWithCode)
                                }
                            }.bind(this))
                        }.bind(this))
                    }
                }, {
                    key: "changePhoneNumber",
                    value: function() {
                        var e = [{
                            content: this.intlPhoneInput.getNumber(),
                            contentType: "text/html",
                            fragmentType: O.default.CONVERSATION.FRAGMENT_TYPE.TEXT
                        }];
                        this.args.sendButtonMessage(e, null, this.DOM_ID.phoneNumberWithCode)
                    }
                }, {
                    key: "checkInput",
                    value: function() {
                        var e, t = null === (e = this.intlPhoneInput) || void 0 === e ? void 0 : e.getNumber();
                        this.isValueInEditor = !!t
                    }
                }]), i
            }(S.default), c = (0, C.Z)(u.prototype, "intl", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), d = (0, C.Z)(u.prototype, "hotline", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), p = (0, C.Z)(u.prototype, "isValueInEditor", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), (0, C.Z)(u.prototype, "initiateInput", [a], Object.getOwnPropertyDescriptor(u.prototype, "initiateInput"), u.prototype), (0, C.Z)(u.prototype, "changePhoneNumber", [l], Object.getOwnPropertyDescriptor(u.prototype, "changePhoneNumber"), u.prototype), (0, C.Z)(u.prototype, "checkInput", [r], Object.getOwnPropertyDescriptor(u.prototype, "checkInput"), u.prototype), u)
        },
        20202: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return S
                }
            });
            var i, o, s, a, l, r, u, c, d = n(35235),
                p = n(10935),
                h = n(34645),
                f = n(5660),
                m = n(69049),
                g = n(58678),
                v = n(55411),
                b = n(79833),
                y = n(52626),
                w = n(13256),
                E = n(76144),
                T = n(13418);

            function C(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, b.Z)(e);
                    if (t) {
                        var o = (0, b.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, v.Z)(this, n)
                }
            }
            var S = (i = Ember.inject.service(), o = Ember.computed.readOnly("hotline.ui.isIPhone"), s = Ember.computed("primaryActions"), a = Ember.computed("canStartTimer", "isResendButtonDisabled"), l = Ember._action, r = function(e) {
                (0, g.Z)(n, e);
                var t = C(n);

                function n() {
                    var e;
                    (0, h.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, y.Z)((0, m.Z)(e), "limit", 2), (0, y.Z)((0, m.Z)(e), "resendOtpLimit", 1), (0, y.Z)((0, m.Z)(e), "defaultCounterValue", "00"), (0, y.Z)((0, m.Z)(e), "counter", 30), (0, y.Z)((0, m.Z)(e), "isResendButtonDisabled", !0), (0, p.Z)((0, m.Z)(e), "hotline", u, (0, m.Z)(e)), (0, p.Z)((0, m.Z)(e), "isIPhone", c, (0, m.Z)(e)), e
                }
                return (0, f.Z)(n, [{
                    key: "primaryActions",
                    get: function() {
                        var e, t;
                        return this.isResendOtpAction(this.args.quickActions) ? null === (e = this.args.quickActions) || void 0 === e ? void 0 : e.slice(0, this.resendOtpLimit) : null === (t = this.args.quickActions) || void 0 === t ? void 0 : t.slice(0, this.limit)
                    }
                }, {
                    key: "restActions",
                    get: function() {
                        var e;
                        return null === (e = this.args.quickActions) || void 0 === e ? void 0 : e.slice(this.limit)
                    }
                }, {
                    key: "canStartTimer",
                    get: function() {
                        var e = this.isResendOtpAction(this.primaryActions);
                        return e && this.startResendOtpCounter(), e
                    }
                }, {
                    key: "resendOtpButton",
                    get: function() {
                        return this.canStartTimer && this.isResendButtonDisabled
                    }
                }, {
                    key: "isResendOtpAction",
                    value: function(e) {
                        var t = this,
                            n = T.default.QUICK_ACTIONS_TYPE.resendOtpIdentifier;
                        return null == e ? void 0 : e.find(function(e) {
                            return (0, d.Z)(this, t), e.label == n
                        }.bind(this))
                    }
                }, {
                    key: "clearExistingTimer",
                    value: function() {
                        clearInterval(this.interval), this.interval = void 0, this.reInitialiseCounterValue()
                    }
                }, {
                    key: "startResendOtpCounter",
                    value: function() {
                        var e = this;
                        this.interval = setInterval(function() {
                            (0, d.Z)(this, e), this.decrementCounterValue();
                            var t = this.constructDoubleDigit(this.counter);
                            !this.isDestroyed && Ember.set(this, "displayCounter", t), 0 == this.counter && (clearInterval(this.interval), !this.isDestroyed && Ember.set(this, "isResendButtonDisabled", !1))
                        }.bind(this), 1e3)
                    }
                }, {
                    key: "reInitialiseCounterValue",
                    value: function() {
                        return this.counter = 30, this.counter
                    }
                }, {
                    key: "constructDoubleDigit",
                    value: function(e) {
                        return e / 10 < 1 ? "0" + e : e
                    }
                }, {
                    key: "decrementCounterValue",
                    value: function() {
                        return this.counter = this.counter - 1, this.counter
                    }
                }]), n
            }(E.default), u = (0, w.Z)(r.prototype, "hotline", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), c = (0, w.Z)(r.prototype, "isIPhone", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), (0, w.Z)(r.prototype, "canStartTimer", [s], Object.getOwnPropertyDescriptor(r.prototype, "canStartTimer"), r.prototype), (0, w.Z)(r.prototype, "resendOtpButton", [a], Object.getOwnPropertyDescriptor(r.prototype, "resendOtpButton"), r.prototype), (0, w.Z)(r.prototype, "clearExistingTimer", [l], Object.getOwnPropertyDescriptor(r.prototype, "clearExistingTimer"), r.prototype), r)
        },
        47838: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return f
                }
            });
            var i, o, s = n(34645),
                a = n(5660),
                l = n(58678),
                r = n(55411),
                u = n(79833),
                c = n(13256),
                d = n(76144),
                p = n(11769);

            function h(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, r.Z)(this, n)
                }
            }
            var f = (i = Ember._action, o = function(e) {
                (0, l.Z)(n, e);
                var t = h(n);

                function n() {
                    return (0, s.Z)(this, n), t.apply(this, arguments)
                }
                return (0, a.Z)(n, [{
                    key: "handleSelection",
                    value: function(e) {
                        var t, n;
                        return null === (t = (n = this.args).selectionHandler) || void 0 === t ? void 0 : t.call(n, (0, p.frameQuickActionsFragment)(e))
                    }
                }]), n
            }(d.default), (0, c.Z)(o.prototype, "handleSelection", [i], Object.getOwnPropertyDescriptor(o.prototype, "handleSelection"), o.prototype), o)
        },
        5957: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return b
                }
            });
            var i, o, s = n(35235),
                a = n(34645),
                l = n(5660),
                r = n(69049),
                u = n(58678),
                c = n(55411),
                d = n(79833),
                p = n(52626),
                h = n(13256),
                f = n(76144),
                m = n(13418),
                g = n(11769);

            function v(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, d.Z)(e);
                    if (t) {
                        var o = (0, d.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, c.Z)(this, n)
                }
            }
            var b = (i = Ember._action, o = function(e) {
                (0, u.Z)(n, e);
                var t = v(n);

                function n() {
                    var e;
                    (0, a.Z)(this, n);
                    for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)), (0, p.Z)((0, r.Z)(e), "slashCmdId", m.default.DOM_ID.slashCommands), e
                }
                return (0, l.Z)(n, [{
                    key: "searchText",
                    get: function() {
                        return this.args.search ? this.args.search.slice(1) : ""
                    }
                }, {
                    key: "filteredQuickActions",
                    get: function() {
                        var e = this,
                            t = this.searchText.toLowerCase();
                        return this.args.quickActions.filter(function(n) {
                            var i = n.label;
                            return (0, s.Z)(this, e), i.toLowerCase().includes(t)
                        }.bind(this))
                    }
                }, {
                    key: "handleSelection",
                    value: function(e) {
                        var t, n;
                        return null === (t = (n = this.args).selectionHandler) || void 0 === t ? void 0 : t.call(n, (0, g.frameQuickActionsFragment)(e))
                    }
                }]), n
            }(f.default), (0, h.Z)(o.prototype, "handleSelection", [i], Object.getOwnPropertyDescriptor(o.prototype, "handleSelection"), o.prototype), o)
        },
        21572: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return N
                }
            });
            var i, o, s, a, l, r, u, c, d, p, h, f, m, g, v, b, y = n(35235),
                w = n(10935),
                E = n(34645),
                T = n(5660),
                C = n(69049),
                S = n(58678),
                O = n(55411),
                M = n(79833),
                I = n(52626),
                k = n(13256),
                _ = n(76144),
                A = n.p + "dropdown_arrow.77949ef85f5f93473c2d5a6e78e18856.svg",
                P = n(10699),
                R = n(13418);

            function D(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, M.Z)(e);
                    if (t) {
                        var o = (0, M.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, O.Z)(this, n)
                }
            }
            var N = (i = Ember.inject.service, o = Ember._tracked, s = Ember._tracked, a = Ember._tracked, l = Ember.computed("selectionModel.selected.[]"), r = Ember._action, u = Ember._action, c = Ember._action, d = Ember._action, p = Ember._action, h = Ember._action, f = function(e) {
                (0, S.Z)(n, e);
                var t = D(n);

                function n() {
                    var e;
                    return (0, E.Z)(this, n), e = t.apply(this, arguments), (0, w.Z)((0, C.Z)(e), "intl", m, (0, C.Z)(e)), (0, I.Z)((0, C.Z)(e), "images", {
                        DropdownArrow: A
                    }), (0, I.Z)((0, C.Z)(e), "bindValue", "label"), (0, I.Z)((0, C.Z)(e), "bindLabel", "label"), (0, w.Z)((0, C.Z)(e), "isDropdownOpen", g, (0, C.Z)(e)), (0, w.Z)((0, C.Z)(e), "focusInput", v, (0, C.Z)(e)), (0, w.Z)((0, C.Z)(e), "searchText", b, (0, C.Z)(e)), e.selectionModel = new P.SelectionModel(e.args.multiple, [], e.onChangeCB.bind((0, C.Z)(e))), e
                }
                return (0, T.Z)(n, [{
                    key: "onChangeCB",
                    value: function() {
                        this.focusInput = !0
                    }
                }, {
                    key: "dropdownPlaceholder",
                    get: function() {
                        var e = this.intl.t("conversation.ce.placeholders.dropdown");
                        return e || "Select option(s)"
                    }
                }, {
                    key: "filteredOptions",
                    get: function() {
                        var e = this,
                            t = this.searchText.trim().toLowerCase();
                        return this.args.options.filter(function(n) {
                            return (0, y.Z)(this, e), n[this.bindLabel].toLowerCase().includes(t)
                        }.bind(this))
                    }
                }, {
                    key: "selectedOptions",
                    get: function() {
                        var e = this;
                        return this.args.options.filter(function(t) {
                            return (0, y.Z)(this, e), this.isSelected(t)
                        }.bind(this))
                    }
                }, {
                    key: "isSelected",
                    value: function(e) {
                        return this.selectionModel.isSelected(e[this.bindValue])
                    }
                }, {
                    key: "showDropdown",
                    value: function() {
                        this.isDropdownOpen = !0
                    }
                }, {
                    key: "toggleDD",
                    value: function() {
                        this.toggleDropdown()
                    }
                }, {
                    key: "handleKeyPressDown",
                    value: function(e) {
                        e.keyCode !== R.default.KEYCODES.ENTER || this.isDropdownOpen || (this.toggleDropdown(), e.stopPropagation())
                    }
                }, {
                    key: "toggleDropdown",
                    value: function() {
                        this.isDropdownOpen = !this.isDropdownOpen
                    }
                }, {
                    key: "selectionHandler",
                    value: function(e) {
                        this.args.multiple ? this.selectionModel.toggle(e[this.bindValue]) : this.triggerOnChange([e]), this.searchText = ""
                    }
                }, {
                    key: "removeItem",
                    value: function(e, t) {
                        t.stopPropagation(), this.selectionModel.deselect(e[this.bindValue])
                    }
                }, {
                    key: "onMultiSubmit",
                    value: function() {
                        this.triggerOnChange(this.selectedOptions)
                    }
                }, {
                    key: "triggerOnChange",
                    value: function(e) {
                        this.isDropdownOpen = !1, this.selectionModel.clear(), this.args.onChange(e)
                    }
                }]), n
            }(_.default), m = (0, k.Z)(f.prototype, "intl", [i], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }), g = (0, k.Z)(f.prototype, "isDropdownOpen", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }), v = (0, k.Z)(f.prototype, "focusInput", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !0
                }
            }), b = (0, k.Z)(f.prototype, "searchText", [a], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }), (0, k.Z)(f.prototype, "selectedOptions", [l], Object.getOwnPropertyDescriptor(f.prototype, "selectedOptions"), f.prototype), (0, k.Z)(f.prototype, "showDropdown", [r], Object.getOwnPropertyDescriptor(f.prototype, "showDropdown"), f.prototype), (0, k.Z)(f.prototype, "toggleDD", [u], Object.getOwnPropertyDescriptor(f.prototype, "toggleDD"), f.prototype), (0, k.Z)(f.prototype, "handleKeyPressDown", [c], Object.getOwnPropertyDescriptor(f.prototype, "handleKeyPressDown"), f.prototype), (0, k.Z)(f.prototype, "selectionHandler", [d], Object.getOwnPropertyDescriptor(f.prototype, "selectionHandler"), f.prototype), (0, k.Z)(f.prototype, "removeItem", [p], Object.getOwnPropertyDescriptor(f.prototype, "removeItem"), f.prototype), (0, k.Z)(f.prototype, "onMultiSubmit", [h], Object.getOwnPropertyDescriptor(f.prototype, "onMultiSubmit"), f.prototype), f)
        },
        18149: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return w
                }
            });
            var i, o, s, a, l, r, u = n(34645),
                c = n(5660),
                d = n(69049),
                p = n(58678),
                h = n(55411),
                f = n(79833),
                m = n(52626),
                g = n(13256),
                v = n(18006);

            function b(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, f.Z)(e);
                    if (t) {
                        var o = (0, f.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, h.Z)(this, n)
                }
            }
            var y = n(13418).default.CONVERSATION.FRAGMENT_TYPE.TEXT,
                w = (i = (0, v.tagName)("div"), o = Ember.computed("options"), s = Ember._action, a = Ember._action, i((r = function(e) {
                    (0, p.Z)(n, e);
                    var t = b(n);

                    function n() {
                        var e;
                        (0, u.Z)(this, n);
                        for (var i = arguments.length, o = new Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                        return e = t.call.apply(t, [this].concat(o)), (0, m.Z)((0, d.Z)(e), "timeInterval", 15), e
                    }
                    return (0, c.Z)(n, [{
                        key: "timeOptions",
                        get: function() {
                            return this.splitTimeAsArrays()
                        }
                    }, {
                        key: "calculatePosition",
                        value: function(e, t) {
                            var n = e.getBoundingClientRect(),
                                i = n.top,
                                o = n.left,
                                s = n.width,
                                a = n.height;
                            return {
                                style: {
                                    left: o,
                                    width: s,
                                    top: i - (t.getBoundingClientRect().height - a) - 52
                                }
                            }
                        }
                    }, {
                        key: "splitTimeAsArrays",
                        value: function() {
                            for (var e = new Date(this.fromTime), t = new Date(this.toTime), n = e.getMinutes(), i = n % this.timeInterval == 0 ? n : n + (this.timeInterval - n % this.timeInterval), o = t.getMinutes(), s = e.getHours(), a = t.getHours(), l = 60, r = []; s <= a;)
                                if (s === a && (l = o + 1), i < l) {
                                    var u = s < 10 ? "0".concat(s) : s,
                                        c = 0 === i ? "0".concat(i) : i;
                                    r.push({
                                        label: "".concat(u, ":").concat(c),
                                        value: "".concat(u, ":").concat(c)
                                    }), i += this.timeInterval
                                } else s += 1, i = 0;
                            return r
                        }
                    }, {
                        key: "onInputKeyDown",
                        value: function(e, t) {
                            this.onKeyDown(e), 13 === t.which && (t.preventDefault(), this.onSelect([{
                                fragmentType: y,
                                contentType: "text/html",
                                content: e,
                                shouldValidate: !0
                            }]), t.target.focus())
                        }
                    }, {
                        key: "onSelectDropdown",
                        value: function(e) {
                            this.onSelect([{
                                fragmentType: y,
                                contentType: "text/html",
                                content: e.label,
                                shouldValidate: !0
                            }])
                        }
                    }]), n
                }(Ember.Component.extend()), (0, g.Z)(r.prototype, "timeOptions", [o], Object.getOwnPropertyDescriptor(r.prototype, "timeOptions"), r.prototype), (0, g.Z)(r.prototype, "onInputKeyDown", [s], Object.getOwnPropertyDescriptor(r.prototype, "onInputKeyDown"), r.prototype), (0, g.Z)(r.prototype, "onSelectDropdown", [a], Object.getOwnPropertyDescriptor(r.prototype, "onSelectDropdown"), r.prototype), l = r)) || l)
        },
        52892: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(7259),
                o = n(13418);
            t.default = Ember.Component.extend(i.default, {
                classNames: ["h-reply", "h-attachment-reply-composer"],
                attributeBindings: ["testId:data-test-id"],
                testId: "attachment-reply-composer",
                actions: {
                    onClickHandler: function() {
                        this.file.fileData || this.imageSelect()
                    },
                    onFileEdit: function(e) {
                        var t, n;
                        e.keyCode === o.default.KEYCODES.ENTER && (e.preventDefault(), null !== (t = this.file) && void 0 !== t && null !== (n = t.fileData) && void 0 !== n && n.name && this.sendAttachment())
                    },
                    onEnterFileUpload: function(e, t) {
                        var n, i;
                        t.keyCode === o.default.KEYCODES.ENTER && (t.preventDefault(), null !== (n = this.file) && void 0 !== n && null !== (i = n.fileData) && void 0 !== i && i.name ? this.sendAttachment() : this.imageSelect())
                    }
                }
            })
        },
        11219: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(22838);
            t.default = i.default.extend({})
        },
        72847: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(35235),
                o = n(29436),
                s = n(89567);

            function a(e, t, n) {
                return (e - t) * (e - n) <= 0
            }
            t.default = Ember.Helper.extend({
                compute: function(e, t) {
                    var n = this,
                        l = (0, o.Z)(e, 2),
                        r = l[0],
                        u = l[1];
                    if (r && !isNaN(r)) {
                        var c, d = 0,
                            p = (0, s.default)(r).diff((0, s.default)(), "seconds"),
                            h = !0;
                        if (t && t.updateOnInterval && (h = Boolean(t.updateOnInterval)), u) c = (0, s.default)(r).format(u);
                        else try {
                            c = p < 44 ? (0, s.default)(r).fromNow() : (0, s.default)().fromNow()
                        } catch (e) {
                            c = (0, s.default)(r).format("ddd, LT")
                        }
                        return h && (this.clearTimer(), d = function(e) {
                            return a(e, -89, 89) ? 3 : a(e, -5340, 5340) ? 120 : a(e, -86400, 86400) ? 1800 : 86400
                        }(p), this.intervalTimer = setInterval(function() {
                            var e = this;
                            (0, i.Z)(this, n), Ember.run(function() {
                                return (0, i.Z)(this, e), this.recompute()
                            }.bind(this))
                        }.bind(this), parseInt(1e3 * d, 10))), c
                    }
                    return ""
                },
                clearTimer: function() {
                    clearInterval(this.intervalTimer)
                },
                destroy: function() {
                    this.clearTimer()
                }
            })
        },
        16713: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                getNextElement: function() {
                    return o
                }
            });
            var i = n(29436);

            function o(e) {
                var t = (0, i.Z)(e, 2),
                    n = t[0],
                    o = t[1];
                return "undefined" === Ember.typeOf(o) ? null : n.objectAt(o + 1)
            }
            t.default = Ember.Helper.helper(o)
        },
        66558: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                getPreviousElement: function() {
                    return o
                }
            });
            var i = n(29436);

            function o(e) {
                var t = (0, i.Z)(e, 2),
                    n = t[0],
                    o = t[1];
                return "undefined" === Ember.typeOf(o) || 0 === o ? null : n.objectAt(o - 1)
            }
            t.default = Ember.Helper.helper(o)
        },
        82370: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                },
                gte: function() {
                    return i.gte
                }
            });
            var i = n(1905)
        },
        56480: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                isSame: function() {
                    return s
                }
            });
            var i = n(29436),
                o = n(89567);

            function s(e, t) {
                var n = (0, i.Z)(e, 2),
                    s = n[0],
                    a = n[1],
                    l = "milliseconds";
                if (s && a) return s = (0, o.default)("now" === s ? void 0 : s), a = (0, o.default)("now" === a ? void 0 : a), t && (l = t.precision ? t.precision : l), s.isSame(a, l)
            }
            t.default = Ember.Helper.helper(s)
        },
        46750: function(e, t, n) {
            "use strict";

            function i(e) {
                var t = e[0],
                    n = e[1],
                    i = e[2];
                return 0 != t && 1 != n ? i ? "maximize-triplet-slot" : "maximize-quad-slot" : ""
            }
            n.r(t), n.d(t, {
                canMaximizeSlots: function() {
                    return i
                }
            }), t.default = Ember.Helper.helper(i)
        },
        60451: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return m
                }
            });
            var i = n(35235),
                o = n(34645),
                s = n(5660),
                a = n(28433),
                l = n(58678),
                r = n(55411),
                u = n(79833),
                c = n(87643),
                d = n(22126),
                p = n(62766),
                h = n(13418);

            function f(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, i = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        n = Reflect.construct(i, arguments, o)
                    } else n = i.apply(this, arguments);
                    return (0, r.Z)(this, n)
                }
            }
            var m = function(e) {
                (0, l.Z)(r, e);
                var t = f(r);

                function r() {
                    return (0, o.Z)(this, r), t.apply(this, arguments)
                }
                return (0, s.Z)(r, [{
                    key: "init",
                    value: function() {
                        (0, a.Z)((0, u.Z)(r.prototype), "init", this).apply(this, arguments), this.conversationStatus = []
                    }
                }, {
                    key: "model",
                    value: function(e) {
                        var t, o, s = this,
                            a = h.default.EmberModelUrl.conversationStatus,
                            l = this.getParentRouteName(),
                            r = l ? this.modelFor(l) : null,
                            u = parseInt(e.channel_id);
                        if ((r && (t = r.channels, o = r.offlineExperience), o && o.offlineExpEnabled) && this.offlineExperienceEnabledChannel(u, o.channelIds)) {
                            var c, d, p, f = t.findBy("channelId", u),
                                m = null === (c = this.session) || void 0 === c ? void 0 : c.token,
                                g = null === (d = this.hotline) || void 0 === d || null === (p = d.ui) || void 0 === p ? void 0 : p.awayMessage,
                                v = f.operatingHoursId,
                                b = g.findBy("operatingHoursId", v);
                            if ((!b || b && !b.enabled) && (b = g.findBy("defaultBhr", !0)), b && b.awayMessage) {
                                var y = this.conversations.findBy("channelId", u),
                                    w = y && y.get("conversationId"),
                                    E = this.session,
                                    T = E && E.user,
                                    C = T && T.alias;
                                if (w) {
                                    var S, O = this.channelInfoAvailable(u, this.conversationStatus);
                                    if (O && (S = this.shouldUpdateChannelInfo(u, this.conversationStatus)), !O || O && S) return Ember.RSVP.hash({
                                        channelId: e.channel_id,
                                        conversationStatus: this.store.getRequest(a.model, a.url.replace("{token}", m).replace("{userAlias}", C) + "?conversationId=" + w + "&excludeMessages=true").then(function(e) {
                                            var t = this;
                                            (0, i.Z)(this, s), O ? O && S && this.conversationStatus && this.conversationStatus.forEach(function(n) {
                                                (0, i.Z)(this, t), n.channelId === u && (n.lastRequestedTime = (new Date).getTime(), n.conversationStatus = e.status, y.set("status", e.status), this.send("save"))
                                            }.bind(this)) : (this.conversationStatus.push({
                                                channelId: u,
                                                conversationStatus: e.status,
                                                lastRequestedTime: (new Date).getTime()
                                            }), y.set("status", e.status), this.send("save"))
                                        }.bind(this))
                                    })
                                }
                            }
                        }
                        var M = Promise.all([n.e(7873).then(n.bind(n, 57873)), n.e(6653).then(n.t.bind(n, 6653, 23))]);
                        return Ember.RSVP.hash({
                            channelId: e.channel_id,
                            flatpickr: M
                        })
                    }
                }, {
                    key: "afterModel",
                    value: function(e) {
                        var t = this.getParentRouteName(),
                            n = t ? this.modelFor(t) : null;
                        e.isRoutedFromHistory = this.transition.to.queryParams.isRoutedFromHistory, e.fromPage = this.transition.to.queryParams.fromPage, e.isStartNew = this.transition.to.queryParams.isStartNew, e.conversationId = this.transition.to.queryParams.conversationId, n && (e.channels = n.channels, e.operatingHours = n.hours, e.offlineExperience = n.offlineExperience), (0, a.Z)((0, u.Z)(r.prototype), "afterModel", this).call(this)
                    }
                }, {
                    key: "channelInfoAvailable",
                    value: function(e, t) {
                        return t && t.findBy("channelId", e)
                    }
                }, {
                    key: "shouldUpdateChannelInfo",
                    value: function(e, t) {
                        var n = t.findBy("channelId", e);
                        return !(!n || !n.lastRequestedTime) && (new Date).getTime() - n.lastRequestedTime > 3e5
                    }
                }, {
                    key: "offlineExperienceEnabledChannel",
                    value: function(e, t) {
                        return (t && t.indexOf(e)) >= 0
                    }
                }]), r
            }(c.default.extend(d.default, p.default))
        },
        8964: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i.default
                }
            });
            var i = n(82781)
        },
        68516: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = O(n(92945)),
                o = O(n(70234)),
                s = O(n(83973)),
                a = O(n(52310)),
                l = O(n(33401)),
                r = O(n(95124)),
                u = O(n(48692)),
                c = O(n(12076)),
                d = O(n(66558)),
                p = O(n(16713)),
                h = O(n(14991)),
                f = O(n(86923)),
                m = O(n(93829)),
                g = O(n(73734)),
                v = O(n(34607)),
                b = O(n(13734)),
                y = O(n(52515)),
                w = O(n(78910)),
                E = O(n(8233)),
                T = O(n(44587)),
                C = O(n(56407)),
                S = O(n(98661));

            function O(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/or", (function() {
                return i.default
            })), window.define("hotline-web/components/app-loader/template", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            })), window.define("hotline-web/helpers/contain-valid-text-fragment", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-message/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-message/component", (function() {
                return r.default
            })), window.define("hotline-web/helpers/and", (function() {
                return u.default
            })), window.define("hotline-web/helpers/not", (function() {
                return c.default
            })), window.define("hotline-web/helpers/get-previous-element", (function() {
                return d.default
            })), window.define("hotline-web/helpers/get-next-element", (function() {
                return p.default
            })), window.define("hotline-web/components/bot-action-handler/component", (function() {
                return h.default
            })), window.define("hotline-web/components/ui-carousel/template", (function() {
                return f.default
            })), window.define("hotline-web/components/ui-carousel/component", (function() {
                return m.default
            })), window.define("hotline-web/components/ui-button-composer/template", (function() {
                return g.default
            })), window.define("hotline-web/components/ui-button-composer/component", (function() {
                return v.default
            })), window.define("hotline-web/components/ui-date-picker/template", (function() {
                return b.default
            })), window.define("hotline-web/components/ui-date-picker/component", (function() {
                return y.default
            })), window.define("hotline-web/components/ui-multi-select-buttons/template", (function() {
                return w.default
            })), window.define("hotline-web/components/ui-multi-select-buttons/component", (function() {
                return E.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/template", (function() {
                return T.default
            })), window.define("hotline-web/components/ui-agent-typing-indicator/component", (function() {
                return C.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return S.default
            }));
            var M = (0, Ember.HTMLBars.template)({
                id: "Whlvfiht",
                block: '[[[41,[28,[37,1],[[30,0,["isLoadingOlderMessages"]],[30,0,["isLoadingConversations"]]],null],[[[1,"  "],[10,"li"],[15,0,[52,[30,0,["isLoadingConversations"]],"app-loader-bottom","app-loader-top"]],[12],[1,"\\n    "],[8,[39,2],null,[["@isVertical","@label"],["true",[28,[37,3],["help_text.loading_older_conversations"],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[28,[37,4],[[30,0,["channelWrapedMessage"]]],null],[[[1,"  "],[8,[39,5],null,[["@model","@isOpen","@messagesArray"],[[30,0,["channelMessage"]],[30,0,["isOpen"]],[30,0,["channelWrapedMessage"]]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[42,[28,[37,7],[[28,[37,7],[[30,0,["messages"]]],null]],null],null,[[[41,[28,[37,8],[[28,[37,4],[[30,1]],null],[28,[37,9],[[30,1,["isFeedbackResponse"]]],null]],null],[[[1,"    "],[8,[39,5],null,[["@messagesArray","@model","@lastMessage","@nextMessage","@calendarMessages","@isOpen","@extraParams","@cobrowsingAccepted","@cobrowsingDenied","@openCalendarPickerMaximized","@sendMessage","@sendOfflineMessage","@resendMessage","@readMillis"],[[30,0,["messages"]],[30,1],[28,[37,10],[[30,0,["messages"]],[30,2]],null],[28,[37,11],[[30,0,["messages"]],[30,2]],null],[30,0,["calendarMessages"]],[30,0,["isOpen"]],[30,0,["extraParams"]],"cobrowsingAccepted","cobrowsingDenied",[28,[37,12],[[30,0],"openCalendarPickerMaximized"],null],[28,[37,12],[[30,0],"sendMessage"],null],[28,[37,12],[[30,0],"sendOfflineMessage"],null],[28,[37,12],[[30,0],"resendMessage"],null],[30,0,["readMillis"]]]],null],[1,"\\n"]],[]],null],[41,[30,1,["actions"]],[[[1,"    "],[8,[39,13],null,[["@model","@channelId"],[[30,1],[30,0,["model","channelId"]]]],null],[1,"\\n"]],[]],null]],[1,2]],null],[41,[30,0,["carousel","cards","length"]],[[[1,"  "],[10,0],[14,0,"message-container fc-carousel-wrapper"],[15,"onkeydown",[28,[37,12],[[30,0],"setNextFocus"],null]],[12],[1,"\\n    "],[8,[39,14],null,[["@title","@cards","@isMultiple","@onSelect"],[[30,0,["carousel","title","firstObject"]],[30,0,["carousel","cards"]],[30,0,["carousel","multiSelect"]],[28,[37,12],[[30,0],"carouselSelectionHandler"],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[41,[30,0,["customButtonComposer"]],[[[1,"  "],[10,0],[14,0,"message-container button-region resize-fragments margin-reply-fragments"],[12],[1,"\\n"],[42,[28,[37,7],[[28,[37,7],[[30,0,["customButtonComposer"]]],null]],null],null,[[[1,"      "],[8,[39,15],null,[["@sendButtonMessage","@model"],[[28,[37,12],[[30,0],[30,0,["sendButtonMessage"]]],null],[30,3]]],null],[1,"\\n"]],[3,4]],null],[1,"  "],[13],[1,"\\n"]],[]],null],[41,[30,0,["articleFeedbackComposer"]],[[[1,"  "],[10,0],[14,0,"message-container button-region margin-reply-fragments"],[12],[1,"\\n"],[42,[28,[37,7],[[28,[37,7],[[30,0,["articleFeedbackComposer"]]],null]],null],null,[[[1,"      "],[8,[39,15],null,[["@sendButtonMessage","@model","@message"],[[28,[37,12],[[30,0],[30,0,["sendButtonMessage"]]],null],[30,5],[30,0,["message"]]]],null],[1,"\\n"]],[5,6]],null],[1,"  "],[13],[1,"\\n"]],[]],null],[41,[30,0,["dateFragments"]],[[[1,"  "],[8,[39,16],null,[["@fromDate","@toDate","@onSelect","@dateFormat"],[[30,0,["dateFragments","fromDate"]],[30,0,["dateFragments","toDate"]],[28,[37,12],[[30,0],"dateSelectionHandler"],null],"d M Y"]],null],[1,"\\n"]],[]],null],[41,[30,0,["multiSelectButtons","length"]],[[[1,"  "],[8,[39,17],null,[["@buttons","@sendMessage"],[[30,0,["multiSelectButtons"]],[28,[37,12],[[30,0],[30,0,["sendButtonMessage"]]],null]]],null],[1,"\\n"]],[]],null],[41,[30,0,["session","isMultiWidget"]],[[[41,[30,0,["hotline","ui","config","advancedOptionsConfig","enableShowTypingIndicator"]],[[[1,"    "],[10,"li"],[14,0,"ui-agent-typing-indicator-wrap"],[12],[1,"\\n      "],[8,[39,18],null,[["@channelId"],[[30,0,["channelId"]]]],null],[1,"     \\n\\n    "],[13],[1,"\\n"]],[]],null]],[]],[[[41,[30,0,["hotlineUI","config","enabledAgentTypingIndicator"]],[[[1,"   "],[10,"li"],[14,0,"ui-agent-typing-indicator-wrap"],[12],[1,"\\n    "],[8,[39,18],null,[["@channelId"],[[30,0,["channelId"]]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],[]]],[41,[28,[37,8],[[30,0,["showPushOptions"]],[28,[37,9],[[30,0,["session","config","disableNotifications"]]],null]],null],[[[1,"  "],[10,"li"],[14,0,"notification-container animated fadeIn"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","push_notification"]],[[[1,"      "],[1,[28,[35,19],[[30,0,["session","config","content","headers","push_notification"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"      "],[1,[28,[35,3],["conversation.push_notification.message"],null]],[1,"\\n"]],[]]],[1,"    "],[10,0],[14,0,"btn-container"],[12],[1,"\\n      "],[11,1],[24,0,"btn-left"],[24,"role","button"],[24,"tabindex","0"],[4,[38,12],[[30,0],"askPermission"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","push_notify_yes"]],[[[1,"          "],[1,[30,0,["session","config","content","actions","push_notify_yes"]]],[1,"\\n"]],[]],[[[1,"          "],[1,[28,[35,3],["conversation.push_notification.yes"],null]],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n      "],[11,1],[24,0,"btn-right"],[24,"role","button"],[24,"tabindex","0"],[4,[38,12],[[30,0],"clearPermission"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","push_notify_no"]],[[[1,"          "],[1,[30,0,["session","config","content","actions","push_notify_no"]]],[1,"\\n"]],[]],[[[1,"          "],[1,[28,[35,3],["conversation.push_notification.no"],null]],[1,"\\n"]],[]]],[1,"      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],["message","index","button","index","button","index"],false,["if","or","app-loader","t","contain-valid-text-fragment","ui-message","each","-track-array","and","not","get-previous-element","get-next-element","action","bot-action-handler","ui-carousel","ui-button-composer","ui-date-picker","ui-multi-select-buttons","ui-agent-typing-indicator","sanitize-html"]]',
                moduleName: "hotline-web/components/app-conversation-message/template.hbs",
                isStrictMode: !1
            });
            t.default = M
        },
        55357: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = F(n(12076)),
                o = F(n(83973)),
                s = F(n(48692)),
                a = F(n(98661)),
                l = F(n(54119)),
                r = F(n(47838)),
                u = F(n(20961)),
                c = F(n(15611)),
                d = F(n(70234)),
                p = F(n(92482)),
                h = F(n(45102)),
                f = F(n(66171)),
                m = F(n(23738)),
                g = F(n(29882)),
                v = F(n(26207)),
                b = F(n(51996)),
                y = F(n(68516)),
                w = F(n(71968)),
                E = F(n(3066)),
                T = F(n(34835)),
                C = F(n(92945)),
                S = F(n(66895)),
                O = F(n(91313)),
                M = F(n(47273)),
                I = F(n(20202)),
                k = F(n(67157)),
                _ = F(n(98862)),
                A = F(n(38471)),
                P = F(n(49162)),
                R = F(n(8964)),
                D = F(n(86687)),
                N = F(n(94842)),
                Z = F(n(19390)),
                x = F(n(8087)),
                B = F(n(90573));

            function F(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/not", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-quick-action-menu/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-quick-action-menu/component", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/component", (function() {
                return c.default
            })), window.define("hotline-web/components/app-loader/template", (function() {
                return d.default
            })), window.define("hotline-web/components/ui-chip/template", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-chip/component", (function() {
                return h.default
            })), window.define("hotline-web/helpers/gt", (function() {
                return f.default
            })), window.define("hotline-web/components/ui-calendar-picker-max/template", (function() {
                return m.default
            })), window.define("hotline-web/components/ui-calendar-picker-max/component", (function() {
                return g.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return v.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return b.default
            })), window.define("hotline-web/components/app-conversation-message/template", (function() {
                return y.default
            })), window.define("hotline-web/components/app-conversation-message/component", (function() {
                return w.default
            })), window.define("hotline-web/components/app-csat-form/template", (function() {
                return E.default
            })), window.define("hotline-web/components/app-csat-form/component", (function() {
                return T.default
            })), window.define("hotline-web/helpers/or", (function() {
                return C.default
            })), window.define("hotline-web/components/ui-phone-number/template", (function() {
                return S.default
            })), window.define("hotline-web/components/ui-phone-number/component", (function() {
                return O.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/template", (function() {
                return M.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/component", (function() {
                return I.default
            })), window.define("hotline-web/components/ui-attachment-preview/template", (function() {
                return k.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return _.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return A.default
            })), window.define("hotline-web/components/file-upload/component", (function() {
                return P.default
            })), window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return R.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return D.default
            })), window.define("hotline-web/components/emoji-picker/component", (function() {
                return N.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return Z.default
            })), window.define("hotline-web/components/app-reply-composer/template", (function() {
                return x.default
            })), window.define("hotline-web/components/app-reply-composer/component", (function() {
                return B.default
            }));
            var L = (0, Ember.HTMLBars.template)({
                id: "k2qzN1+7",
                block: '[[[10,0],[14,0,"fc-conversation-view"],[12],[1,"\\n  "],[10,0],[15,0,[29,["h-header ",[52,[30,0,["isChannelOffline"]],"offline-header"]," ",[52,[30,0,["isSingleChannel"]],"single-channel-header"]," ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"single-channel-no-desc"]]]],[12],[1,"\\n    "],[10,0],[15,0,[29,["title fadeIn ",[30,0,["headerStyle"]]]]],[12],[1,"\\n"],[41,[30,0,["isSingleChannel"]],[[[1,"        "],[10,0],[14,0,"logo"],[12],[1,"\\n"],[41,[30,0,["getBrandLogo"]],[[[1,"            "],[10,"img"],[14,0,"animated zoomIn faster"],[15,"src",[30,0,["getBrandLogo"]]],[15,"alt",[28,[37,2],["alt.logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"            "],[10,"img"],[14,0,"animated zoomIn faster"],[15,"src",[30,0,["images","FCLine"]]],[15,"alt",[28,[37,2],["alt.product_name"],null]],[12],[13],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n"]],[]],[[[41,[51,[30,0,["isConversationRefIdPresent"]]],[[[1,"          "],[11,0],[24,0,"ic-back animated fadeIn faster"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,2],["aria_labels.back"],null]],[16,"onkeydown",[28,[37,4],[[30,0],"setNextFocus"],null]],[4,[38,4],[[30,0],"toggleBack"],null],[12],[1,"\\n            "],[10,"i"],[14,0,"icon icon-ic_back"],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null]],[]]],[1,"      "],[10,0],[15,0,[29,["channel-info animated fadeIn faster ",[52,[30,0,["isConversationRefIdPresent"]],"no-back-button"]," ",[52,[30,0,["isCompact"]],"channel-info-compact-width","channel-info-width"]]]],[12],[1,"\\n        "],[10,"h1"],[15,0,[29,["channel-title\\n        ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"no-desc"],"\\n        ",[52,[28,[37,5],[[30,0,["isChannelOffline"]],[28,[37,5],[[28,[37,1],[[30,0,["showAgentProfile"]]],null]],null]],null],"offline"]]]],[12],[1,"\\n          "],[1,[28,[35,6],[[30,0,["channel","name"]],"strict"],null]],[1,"\\n        "],[13],[1,"\\n"],[41,[30,0,["isChannelOffline"]],[[[1,"          "],[10,1],[14,0,"away-icon"],[12],[1,"\\n            "],[10,"img"],[15,"src",[30,0,["images","ICOffline"]]],[15,"alt",[28,[37,2],["alt.away_icon"],null]],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["conversationDescription"]],[[[1,"          "],[10,2],[15,0,[29,["channel-desc ",[52,[30,0,["isChannelOffline"]],"offline-description"]]]],[12],[1,[30,0,["conversationDescription"]]],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"],[41,[28,[37,5],[[30,0,["quickActionsMenu"]],[28,[37,1],[[30,0,["isChannelOffline"]]],null]],null],[[[1,"        "],[8,[39,7],null,[["@menuPosition","@quickActions","@selectionHandler"],[[28,[37,4],[[30,0],"menuPosition"],null],[30,0,["quickActionsMenu"]],[28,[37,4],[[30,0],"sendButtonMessage"],null]]],[["default"],[[[[1,"\\n          "],[10,3],[15,0,[29,["animated fadeIn faster ic-ellipsis-vertical ",[52,[30,0,["conversationDescription"]],"ellipsis-with-desc","ellipsis-no-desc"]]]],[14,"role","button"],[15,"aria-label",[28,[37,2],["aria_labels.ellipsis_quick_action"],null]],[14,6,"javascript:void(0);"],[12],[1,"\\n            "],[8,[39,8],null,[["@fillColor","@height","@alignment"],["#FFFFFF","1.7rem","vertical"]],null],[1,"\\n          "],[13],[1,"\\n        "]],[]]]]],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[28,[37,5],[[30,0,["isDynamicFlowLoading"]],[30,0,["widgetInitFeatureEnabled"]]],null],[[[1,"  "],[10,0],[14,0,"loading-article"],[12],[1,"\\n    "],[8,[39,9],null,null,null],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[1,"  "],[10,0],[15,0,[29,["body\\n    ",[52,[28,[37,1],[[30,0,["isFAQAvailable"]]],null],"no-articles"]," ",[52,[30,0,["isSingleChannel"]],"single-channel-section"]," ",[52,[28,[37,1],[[30,0,["conversationDescription"]]],null],"single-channel-no-desc"]]]],[12],[1,"\\n"],[41,[30,0,["showUnreadToast"]],[[[1,"        "],[11,0],[16,0,[29,[[30,0,["toastMessageClass"]]," bottom-68 position--absolute align--center animated fadeInUp faster"]]],[24,"tabindex","0"],[24,"role","button"],[4,[38,4],[[30,0],"scrollToRecentMessages"],null],[12],[1,"\\n          "],[8,[39,10],null,[["@label"],[[52,[28,[37,11],[[30,0,["unreadCount"]],1],null],[28,[37,2],["conversation.chat_headers.new_msg_other"],[["count"],[[30,0,["unreadCount"]]]]],[28,[37,2],["conversation.chat_headers.new_msg_one"],null]]]],null],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"    "],[10,0],[15,0,[29,["h-chat-window ",[30,0,["chatWindowClass"]]]]],[15,"data-conversationId",[30,0,["model","conversationId"]]],[12],[1,"\\n"],[1,"      "],[10,0],[15,0,[29,["cal-picker-maximized ",[52,[51,[30,0,["showCalPicker"]]],"hide-cal-picker"]]]],[12],[1,"\\n        "],[8,[39,12],null,[["@slotsData","@meetingLength","@calendarMessage","@openConfirmationScreenForCalPicker","@closeCalendarPicker"],[[30,0,["slotsData"]],[30,0,["meetingLength"]],[30,0,["calendarMessage"]],[28,[37,4],[[30,0],"openConfirmationScreenForCalPicker"],null],[28,[37,4],[[30,0],"closeCalendarPicker"],null]]],null],[1,"\\n      "],[13],[1,"\\n      "],[10,0],[14,0,"expand"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["showAgentProfile"]],[28,[37,1],[[30,0,["isFocusInput"]]],null]],null],[[[1,"          "],[10,0],[15,0,[29,["fc-agent-profile shadow ",[52,[30,0,["isAgentProfileExpand"]],"profile-expand"]," ",[52,[30,0,["showCalPicker"]],"hide"]]]],[12],[1,"\\n            "],[10,0],[14,0,"u-profile-info"],[12],[1,"\\n              "],[11,0],[16,0,[29,["user-details ",[30,0,["agentProfileClass"]]]]],[4,[38,4],[[30,0],"toggleProfileSize"],null],[12],[1,"\\n                "],[10,0],[14,0,"u-agent-avatar"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["canShowFreshIdAgentPic"]],[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null]],null],[[[1,"                    "],[10,1],[15,0,[29,[[52,[28,[37,1],[[30,0,["freshIdAgentPic"]]],null],"avatar-content-wrap","no-avatar"]," agent-circle"]]],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[30,0,["currentAgent","profilePicUrl"]],[[[41,[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null],[[[41,[28,[37,5],[[30,0,["hideName"]],[30,0,["hidePic"]]],null],[[[41,[30,0,["session","appLogoUrl"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,2],["alt.app_logo"],null]],[12],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,13],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                "],[1,[28,[35,14],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]],[[[41,[30,0,["hidePic"]],[[[41,[30,0,["session","appLogoUrl"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,2],["alt.app_logo"],null]],[12],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["currentAgent","displayName"]],[[[1,"                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,13],[[30,0,["currentAgent","displayName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                  "],[1,[28,[35,14],[[30,0,["currentAgent","displayName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,13],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                "],[1,[28,[35,14],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]]]],[]],[[[1,"                        "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                          "],[10,"img"],[15,"src",[30,0,["currentAgent","profilePicUrl"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                        "],[13],[1,"\\n                      "]],[]]]],[]]]],[]],[[[1,"                      "],[10,1],[15,0,[29,[[52,[30,0,["currentAgent","profilePicUrl"]],"no-avatar","avatar-content-wrap"]," agent-circle"]]],[12],[1,"\\n                        "],[10,"img"],[15,"src",[30,0,["currentAgent","profilePicUrl"]]],[15,"alt",[28,[37,2],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["currentAgent","displayName"]],[[[41,[30,0,["hideName"]],[[[1,"                      "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                        "],[10,1],[15,0,[29,["theme-bg ",[28,[37,13],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                          "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                            "],[1,[28,[35,14],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                          "],[13],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                        "],[10,1],[15,0,[29,["theme-bg ",[28,[37,13],[[30,0,["currentAgent","displayName"]]],null]]]],[12],[1,"\\n                          "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                            "],[1,[28,[35,14],[[30,0,["currentAgent","displayName"]]],null]],[1,"\\n                          "],[13],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n"]],[]]],[1,"                  "]],[]],null]],[]]]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"u-agent-info"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["hideName"]],[28,[37,1],[[30,0,["isLastAgentMessageFromBot"]]],null]],null],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                      "],[10,2],[14,0,"u-agent-name"],[12],[1,"\\n                        "],[1,[28,[35,6],[[30,0,["session","appDisplayName"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]],[[[1,"                    "],[10,2],[14,0,"u-agent-name"],[12],[1,"\\n                      "],[1,[28,[35,6],[[30,0,["currentAgent","firstName"]],"strict"],null]],[1,"\\n                    "],[13],[1,"\\n"],[41,[30,0,["currentAgent","title"]],[[[1,"                      "],[10,2],[14,0,"u-agent-designation"],[12],[1,"\\n                        "],[10,"img"],[14,0,"designation-icon"],[15,"src",[30,0,["images","BCReg"]]],[15,"alt",[28,[37,2],["alt.designation_icon"],null]],[12],[13],[1,"\\n                        "],[1,[28,[35,6],[[30,0,["currentAgent","title"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n"],[41,[30,0,["showAgentBio"]],[[[1,"                "],[10,0],[14,0,"bio-details"],[12],[1,"\\n                  "],[10,0],[14,0,"u-agent-bio"],[12],[1,"\\n                    "],[10,2],[12],[1,[28,[35,6],[[30,0,["currentAgent","bio"]],"strict"],null]],[13],[1,"\\n                  "],[13],[1,"\\n"],[41,[51,[30,0,["hideBio"]]],[[[41,[30,0,["isSocialLinkPresent"]],[[[1,"                      "],[10,0],[14,0,"u-social-network"],[12],[1,"\\n"],[41,[30,0,["currentAgent","socialInfo","twitter"]],[[[1,"                          "],[10,3],[15,6,[29,["https://twitter.com/",[30,0,["currentAgent","socialInfo","twitter"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-twitter"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_twitter social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["currentAgent","socialInfo","facebook"]],[[[1,"                          "],[10,3],[15,6,[29,["https://facebook.com/",[30,0,["currentAgent","socialInfo","facebook"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-fb"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_facebook social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["currentAgent","socialInfo","linkedIn"]],[[[1,"                          "],[10,3],[15,6,[29,["https://linkedin.com/",[30,0,["currentAgent","socialInfo","linkedIn"]]]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,"\\n                            "],[10,0],[14,0,"u-linked-in"],[12],[1,"\\n                              "],[10,"i"],[14,0,"icon-ic_logo_linkedin social-icon"],[12],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],null],[1,"                      "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"                "],[13],[1,"\\n"]],[]],null],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["showPrivacyPolicy"]],[[[1,"          "],[11,0],[24,0,"privacy-policy-container"],[4,[38,15],[[30,0,["updateConversationElement"]]],null],[12],[1,"\\n            "],[10,1],[14,0,"privacy-policy-text"],[12],[1,[30,0,["privacyPolicy","message"]]],[13],[1,"\\n"],[41,[30,0,["privacyPolicy","linkURL"]],[[[1,"              "],[10,3],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[15,6,[30,0,["privacyPolicy","linkURL"]]],[14,0,"privacy-policy-link"],[12],[1,"\\n                "],[1,[30,0,["privacyPolicy","linkText"]]],[1,"\\n                "],[10,"img"],[15,"src",[30,0,["images","ExternalLink"]]],[15,"alt",[28,[37,2],["alt.external_link"],null]],[14,"height","10px"],[14,"width","11px"],[12],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],null],[1,"          "],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"],[41,[30,0,["channelEventReminder","eventDateTime"]],[[[1,"        "],[10,0],[15,0,[29,["calendar-event-reminder ",[52,[30,0,["showCalPicker"]],"hide"]]]],[12],[1,"\\n          "],[10,0],[14,0,"reminder-details"],[12],[1,"\\n            "],[10,"i"],[14,0,"ic-calendar icon-ic_schedule_meeting"],[12],[13],[1,"\\n            "],[10,1],[14,0,"reminder-time-date"],[12],[1,"\\n              "],[1,[30,0,["channelEventReminder","eventDateTime"]]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n          "],[10,0],[14,0,"invite-more-icon"],[12],[1,"\\n"],[41,[30,0,["channelEventReminder","eventLink"]],[[[1,"              "],[10,3],[14,"target","_blank"],[14,"rel","noreferrer noopener"],[15,6,[30,0,["channelEventReminder","eventLink"]]],[12],[1,[28,[35,2],["calendar.view_details"],null]],[13],[1,"\\n"]],[]],null],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"      "],[10,0],[15,0,[29,["h-conv-chat h-theme-bg-",[30,0,["hotline","ui","config","backgroundImage"]]," animated fadeInUp speed scroll-section ",[30,0,["chatSectionClass"]]," ",[52,[30,0,["showCalPicker"]],"hide"]]]],[14,"tabindex","0"],[14,"role","status"],[14,"aria-live","assertive"],[14,"aria-relevant","additions"],[14,"aria-atomic","false"],[12],[1,"\\n        "],[8,[39,16],null,[["@model","@updateReadReceipt","@isOpen","@extraParams","@sendOfflineMessage","@sendMessage","@resendMessage","@sendButtonMessage","@openCalendarPickerMaximized","@isLoadingOlderMessages","@isLoadingConversations"],[[30,0,["model"]],[28,[37,4],[[30,0],"updateReadReceipt"],null],[30,0,["parentView","isOpen"]],[30,0,["extraParams"]],[28,[37,4],[[30,0],"sendOfflineMessage"],null],[28,[37,4],[[30,0],"sendMessage"],null],[28,[37,4],[[30,0],"resendMessage"],null],[28,[37,4],[[30,0],"sendButtonMessage"],null],[28,[37,4],[[30,0],"openCalendarPickerMaximized"],null],[30,0,["isOldConvRequestPending"]],[30,0,["shouldDisableUserInput"]]]],null],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n    "],[8,[39,17],null,[["@model","@agent","@canShowFreshIdAgentPic","@freshIdAgentPic"],[[30,0,["model"]],[30,0,["currentAgent"]],[30,0,["canShowFreshIdAgentPic"]],[30,0,["freshIdAgentPic"]]]],null],[1,"\\n"],[41,[51,[28,[37,18],[[30,0,["shouldHideEditorWrapper"]],[30,0,["awaitingBotResponse"]]],null]],[[[1,"      "],[10,0],[15,0,[29,["h-reply-wrapper ",[30,0,["replyWrapperClass"]]]]],[12],[1,"\\n"],[1,"        "],[10,0],[15,0,[29,["h-reply ",[30,0,["replyEditorClass"]]]]],[12],[1,"\\n"],[41,[28,[37,18],[[30,0,["validationMsg"]],[30,0,["exampletextMessage"]]],null],[[[1,"            "],[10,0],[15,0,[29,["h-reply-validation ",[52,[30,0,["showValidationMsg"]],"validation-error"]]]],[12],[1,"\\n"],[41,[30,0,["showValidationMsg"]],[[[1,"                "],[10,1],[14,0,"validation-error-info"],[12],[1,"\\n                  "],[10,"img"],[14,0,"validation-error-icon"],[15,"src",[30,0,["images","ValidationErrorIcon"]]],[15,"alt",[28,[37,2],["alt.invalid_input"],null]],[12],[13],[1,"\\n                  "],[10,1],[12],[1,[30,0,["validationMsg"]]],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[1,"                "],[10,1],[12],[1,"\\n                  "],[1,[30,0,["exampletextMessage"]]],[1,"\\n                "],[13],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n"]],[]],null],[41,[30,0,["isPhoneNumberWithCode"]],[[[1,"            "],[8,[39,19],null,[["@showValidationMsg","@intlPhoneInput","@setIntlPhoneInput","@sendButtonMessage","@message"],[[30,0,["showValidationMsg"]],[30,0,["intlPhoneInput"]],[28,[37,4],[[30,0],"setIntlPhoneInput"],null],[28,[37,4],[[30,0],"sendButtonMessage"],null],[30,0,["message"]]]],null],[1,"\\n"],[41,[30,0,["quickActionButtons"]],[[[1,"              "],[8,[39,20],null,[["@quickActions","@sendButtonMessage"],[[30,0,["quickActionButtons"]],[28,[37,4],[[30,0],"sendButtonMessage"],null]]],null],[1,"\\n"]],[]],null]],[]],null],[41,[51,[30,0,["shouldHideReplyEditor"]]],[[[41,[30,0,["data","fileData","name"]],[[[1,"              "],[8,[39,21],null,[["@fileData","@imageSelect","@clearImage"],[[30,0,["data"]],[28,[37,4],[[30,0],"imageSelect"],null],[28,[37,4],[[30,0],"clearImage"],null]]],null],[1,"\\n"]],[]],null],[1,"              "],[8,[39,22],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["quickActionsSlashCommandOptions"]],[28,[37,4],[[30,0],"sendButtonMessage"],null]]],[["default"],[[[[1,"\\n                "],[8,[30,1,["editor"]],null,[["@placeholder","@onBlur","@onFocus","@onKeyDown","@content","@isValidationError","@isTextLimitExceeded","@exceedAction","@hasValueInEditor","@id","@contentEditable","@editorHasContent"],[[30,0,["getPlaceholderMessage"]],[28,[37,4],[[30,0],"focusOut"],null],[28,[37,4],[[30,0],"focusIn"],null],[28,[37,4],[[30,0],"keyPressDown"],null],[30,0,["content"]],[30,0,["showValidationMsg"]],[30,0,["isTextLimitExceeded"]],[28,[37,4],[[30,0],"setIsTextLimitExceeded"],null],[28,[37,4],[[30,0],"hasValueInEditor"],null],[30,0,["DOM_ID","appConversationEditor"]],true,[30,0,["editorHasContent"]]]],null],[1,"\\n"],[41,[30,0,["quickActionButtons"]],[[[1,"                  "],[8,[39,20],null,[["@quickActions","@sendButtonMessage"],[[30,0,["quickActionButtons"]],[28,[37,4],[[30,0],"sendButtonMessage"],null]]],null],[1,"\\n"]],[]],null],[1,"              "]],[1]]]]],[1,"\\n"],[41,[30,0,["isAttachmentRequested"]],[[[1,"                "],[8,[39,23],null,[["@value","@id","@blockedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],[30,0,["blockedFileTypes"]]]],null],[1,"\\n"]],[]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[41,[30,0,["uploadFilesEnabled"]],[[[1,"                    "],[8,[39,23],null,[["@value","@id","@blockedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],[30,0,["blockedFileTypes"]]]],null],[1,"\\n"]],[]],[[[1,"                    "],[8,[39,23],null,[["@value","@id","@allowedFileTypes"],[[30,0,["fileReset"]],[30,0,["fileId"]],".png,.jpg,.jpeg,.gif"]],null],[1,"\\n"]],[]]]],[]],null]],[]]],[41,[30,0,["hotline","ui","isDesktop"]],[[[41,[51,[30,0,["isBotConversation"]]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[1,"                  "],[11,3],[24,6,"#"],[16,0,[29,[[52,[30,0,["checkIfRtlIE"]],"h-reply-attach no-emoji","h-reply-attach"],"\\n                      ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]," test-class"]]],[24,"role","button"],[16,"aria-label",[28,[37,2],["aria_labels.file_attachment"],null]],[4,[38,4],[[30,0],"imageSelect"],null],[12],[1,"\\n                    "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n                  "],[13],[1,"\\n"]],[]],null],[41,[51,[30,0,["checkIfRtlIE"]]],[[[1,"                  "],[8,[39,24],null,[["@calculatePosition","@onOpen"],[[30,0,["calculatePosition"]],[30,0,["dropDownOpen"]]]],[["default"],[[[[1,"\\n                    "],[8,[30,2,["Trigger"]],[[16,0,[29,["h-reply-smiley ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[16,"onclick",[28,[37,4],[[30,0],"focusTextEditor"],null]]],null,[["default"],[[[[1,"\\n                      "],[11,0],[16,0,[29,["emoji-pic ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]]]],[16,"aria-label",[28,[37,2],["aria_labels.emoji_picker"],null]],[4,[38,4],[[30,0],"setConfig",[30,2]],null],[12],[1,"\\n                        "],[10,"i"],[14,0,"icons icon-ic_smiley"],[12],[13],[1,"\\n                      "],[13],[1,"\\n                    "]],[]]]]],[1,"\\n                    "],[8,[30,2,["Content"]],null,null,[["default"],[[[[1,"\\n                      "],[10,0],[15,"onkeydown",[28,[37,4],[[30,0],"emojiKeyboardEvent",[30,2]],null]],[15,"onmouseover",[28,[37,4],[[30,0],"setAriaSelected"],null]],[14,0,"emoji-picker-wrapper"],[12],[1,"\\n                        "],[8,[39,25],null,[["@selector","@updateHandler","@filePath","@updateContent"],["#app-conversation-editor",[28,[37,4],[[30,0],"updateEditorContent"],null],[30,0,["cdnUrl"]],false]],null],[1,"\\n                      "],[13],[1,"\\n                    "]],[]]]]],[1,"\\n                  "]],[2]]]]],[1,"\\n"]],[]],null]],[]],null]],[]],[[[1,"              "],[11,3],[16,0,[29,["h-reply-container ",[52,[30,0,["hasValueInEditor"]],"active","disabled"]]]],[24,6,"#"],[4,[38,4],[[30,0],"sendMessageFromMobile"],null],[12],[1,"\\n                "],[10,0],[15,0,[29,["h-reply-send ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[12],[1,"\\n                  "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"],[41,[51,[28,[37,18],[[28,[37,26],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","BOT"]]],null],[28,[37,26],[[30,0,["lastAgentMessage","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","FREDDY_BOT"]]],null]],null]],[[[41,[51,[30,0,["hideFileUpload"]]],[[[1,"                  "],[11,3],[24,6,"#"],[24,"role","button"],[16,"aria-label",[28,[37,2],["aria_labels.file_attachment"],null]],[4,[38,4],[[30,0],"imageSelect"],null],[12],[1,"\\n                    "],[10,0],[15,0,[29,["h-reply-attach ",[52,[30,0,["isTextLimitExceeded"]],"text-preview-message"]," ",[52,[30,0,["data","fileData","name"]],"fileAttached"]]]],[12],[1,"\\n                      "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n                    "],[13],[1,"\\n                  "],[13],[1,"\\n"]],[]],null]],[]],null]],[]]],[41,[30,0,["isTextLimitExceeded"]],[[[1,"              "],[10,0],[15,0,[29,["size-exceed-msg position-message-over\\n                ",[52,[30,0,["disableHugeMessageSending"]],"disable-send"]]]],[12],[1,"\\n                "],[10,"i"],[14,0,"icon-ic_alert"],[12],[13],[1,"\\n"],[41,[30,0,["disableHugeMessageSending"]],[[[1,"                  "],[1,[28,[35,2],["size_exceeded_msg.info_msg_sprout"],null]],[1,"\\n"]],[]],[[[1,"                  "],[2,[28,[37,2],["size_exceeded_msg.info_msg"],null]],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"        "],[13],[1,"\\n"],[41,[51,[30,0,["defaultComposer"]]],[[[41,[30,0,["validationMsg"]],[[[1,"            "],[10,0],[15,0,[29,["h-reply-validation ",[52,[30,0,["showValidationMsg"]],"validation-error"]]]],[12],[1,"\\n"],[41,[30,0,["showValidationMsg"]],[[[1,"                "],[10,1],[14,0,"validation-error-info"],[12],[1,"\\n                  "],[10,"img"],[14,0,"validation-error-icon"],[15,"src",[30,0,["images","ValidationErrorIcon"]]],[15,"alt",[28,[37,2],["alt.invalid_input"],null]],[12],[13],[1,"\\n                  "],[10,1],[12],[1,[30,0,["validationMsg"]]],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],null],[1,"            "],[13],[1,"\\n"]],[]],null],[1,"          "],[8,[39,27],null,[["@isAttachmentRequested","@file","@imageSelect","@clearImage","@message","@sendButtonMessage","@resizeChatWindow","@quickActionButtons","@setIsTextLimitExceeded","@quickActionsSlashCommandOptions","@isValidationError","@onTimePickerKeyDown"],[[30,0,["isAttachmentRequested"]],[30,0,["data"]],[28,[37,4],[[30,0],"imageSelect"],null],[28,[37,4],[[30,0],"clearImage"],null],[30,0,["lastMessage"]],[28,[37,4],[[30,0],"sendButtonMessage"],null],[28,[37,4],[[30,0],"resizeChatWindow"],null],[30,0,["quickActionButtons"]],[28,[37,4],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["quickActionsSlashCommandOptions"]],[30,0,["showValidationMsg"]],[28,[37,4],[[30,0],"onTimePickerKeyDown"],null]]],null],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"]],[]],null],[41,[30,0,["isParallelConversationResolved"]],[[[1,"      "],[10,0],[14,0,"start-new-conversation"],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","advancedOptionsConfig","closedConversationResponse"]],[[[1,"          "],[10,2],[12],[1,[30,0,["hotline","ui","config","advancedOptionsConfig","closedConversationResponse"]]],[13],[1,"\\n"]],[]],[[[1,"          "],[10,2],[12],[1,[28,[35,2],["channel.conversation_closed"],null]],[13],[1,"\\n"]],[]]],[1,"        "],[11,"button"],[24,0,"h-img-button"],[24,4,"button"],[4,[38,4],[[30,0],"goToAllTopicsRoute",true],null],[12],[1,"\\n"],[41,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]],[[[1,"            "],[10,1],[14,0,"btn-content"],[12],[1,[30,0,["hotline","ui","config","advancedOptionsConfig","buttonText"]]],[13],[1,"\\n"]],[]],[[[1,"            "],[10,1],[14,0,"btn-content"],[12],[1,[28,[35,2],["channel.start_new_conversation"],null]],[13],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[41,[30,0,["displayUnreadToastBubble"]],[[[1,"      "],[11,0],[16,0,[29,[[30,0,["toastMessageClass"]]," bottom-68 position--absolute align--center animated fadeInUp faster"]]],[24,"role","button"],[4,[38,4],[[30,0],"scrollToRecentMessages"],null],[12],[1,"\\n        "],[8,[39,10],null,[["@label"],[[52,[28,[37,11],[[30,0,["unreadCount"]],1],null],[28,[37,2],["conversation.chat_headers.new_msg_other"],[["count"],[[30,0,["unreadCount"]]]]],[28,[37,2],["conversation.chat_headers.new_msg_one"],null]]]],null],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"  "],[13],[1,"\\n"]],[]]],[1,"  "],[10,1],[14,"aria-live","assertive"],[14,0,"aria-live-region"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["wrapper","dd"],false,["if","not","t","unless","action","and","sanitize-html","ui-quick-action-menu","ui-ellipsis-icon","app-loader","ui-chip","gt","ui-calendar-picker-max","choose-theme","avatar-content","did-insert","app-conversation-message","app-csat-form","or","ui-phone-number","ui-quick-action-buttons","ui-attachment-preview","ui-editor-wrapper","file-upload","basic-dropdown","emoji-picker","eq","app-reply-composer"]]',
                moduleName: "hotline-web/components/app-conversation/template.hbs",
                isStrictMode: !1
            });
            t.default = L
        },
        3066: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = h(n(98661)),
                o = h(n(12076)),
                s = h(n(83973)),
                a = h(n(48692)),
                l = h(n(26207)),
                r = h(n(51996)),
                u = h(n(16136)),
                c = h(n(19390)),
                d = h(n(82370)),
                p = h(n(92945));

            function h(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/sanitize-html", (function() {
                return i.default
            })), window.define("hotline-web/helpers/not", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            })), window.define("hotline-web/helpers/and", (function() {
                return a.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return l.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return r.default
            })), window.define("hotline-web/components/radio-button/component", (function() {
                return u.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return c.default
            })), window.define("hotline-web/helpers/gte", (function() {
                return d.default
            })), window.define("hotline-web/helpers/or", (function() {
                return p.default
            }));
            var f = (0, Ember.HTMLBars.template)({
                id: "v2PreHtX",
                block: '[[[41,[30,0,["showCsatForm"]],[[[1,"  "],[10,0],[14,0,"csat-rating animated fadeIn speed"],[14,"tabindex","0"],[15,"onkeydown",[28,[37,1],[[30,0],"csatKeyboardEvent"],null]],[12],[1,"\\n"],[41,[30,0,["conversation","resolvedConversationYes"]],[[[1,"      "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n          "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n            "],[10,0],[14,0,"comment-header"],[12],[1,"\\n              "],[10,1],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_yes_question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_yes_question"]],"strict"],null]],[1,"\\n"]],[]],[[[41,[30,0,["conversation","csat","question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["conversation","csat","question"]],"strict"],null]],[1,"\\n                "]],[]],null]],[]]],[1,"              "],[13],[1,"\\n              "],[11,0],[16,0,[29,["csat-minimize ",[52,[28,[37,3],[[30,0,["allowCsatSubmit"]]],null],"disabled"]]]],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,4],["aria_labels.close_csat"],null]],[4,[38,1],[[30,0],"submitCsatRating","true","true"],null],[12],[1,"\\n                "],[10,"i"],[14,0,"close_search_input icon-ic_close_small mild"],[12],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"align-middle"],[12],[1,"\\n              "],[10,0],[14,0,"voting-section"],[12],[1,"\\n                "],[10,0],[14,0,"user-logo"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                     "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,4],["aria-label.agent_profile_pic"],null]],[15,"onerror",[30,0,["handleProfileImageError"]]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["hidePic"]],[30,0,["session","appLogoUrl"]]],null],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,4],["alt.app_logo"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["agent","profilePicUrl"]],[28,[37,3],[[30,0,["hidePic"]]],null]],null],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,"img"],[15,"src",[30,0,["agent","profilePicUrl"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "],[13],[1,"\\n"]],[]],[[[41,[30,0,["agent","displayName"]],[[[1,"                    "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                      "],[10,1],[15,0,[29,["theme-bg ",[28,[37,6],[[30,0,["agent","displayName"]]],null]]]],[12],[1,"\\n                        "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                          "],[1,[28,[35,7],[[30,0,["agent","displayName"]]],null]],[1,"\\n                        "],[13],[1,"\\n                      "],[13],[1,"\\n                    "],[13],[1,"\\n                  "]],[]],null]],[]]]],[]]]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"rate"],[12],[1,"\\n                  "],[10,"h2"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_rate_here"]],[[[1,"                      "],[1,[30,0,["session","config","content","headers","csat_rate_here"]]],[1,"\\n"]],[]],[[[1,"                      "],[1,[28,[35,4],["csat.rate_here"],null]],[1,"\\n"]],[]]],[1,"                  "],[13],[1,"\\n                  "],[10,"fieldset"],[14,0,"rating"],[14,"role","radiogroup"],[12],[1,"\\n                      "],[8,[39,8],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star5","rating","5","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star5"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,9],[[30,0,["csatRatings","star"]],"5"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["5"]]]],[15,"aria-checked",[29,[[28,[37,10],[[30,0,["csatRatings","star"]],5],null]]]],[12],[13],[1," \\n                     "],[8,[39,8],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star4","rating","4","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star4"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,9],[[30,0,["csatRatings","star"]],"4"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["4"]]]],[15,"aria-checked",[29,[[28,[37,10],[[30,0,["csatRatings","star"]],4],null]]]],[12],[13],[1,"\\n                    "],[8,[39,8],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star3","rating","3","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star3"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,9],[[30,0,["csatRatings","star"]],"3"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["3"]]]],[15,"aria-checked",[29,[[28,[37,10],[[30,0,["csatRatings","star"]],3],null]]]],[12],[13],[1,"\\n                    "],[8,[39,8],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star2","rating","2","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star2"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,9],[[30,0,["csatRatings","star"]],"2"],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["2"]]]],[15,"aria-checked",[29,[[28,[37,10],[[30,0,["csatRatings","star"]],2],null]]]],[12],[13],[1,"\\n                      "],[8,[39,8],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],["star1","rating","1","-1","true",[30,0,["csatRatings","star"]],[28,[37,1],[[30,0],"setCsatStars"],null]]],null],[1,"\\n                    "],[10,"label"],[14,"for","star1"],[14,0,"star-label"],[15,"tabindex",[52,[28,[37,11],[[28,[37,3],[[30,0,["csatRatings","star"]]],null],[28,[37,9],[[30,0,["csatRatings","star"]],"1"],null]],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,4],["aria_labels.star"],[["star"],["1"]]]],[15,"aria-checked",[29,[[28,[37,10],[[30,0,["csatRatings","star"]],1],null]]]],[12],[13],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"comment"],[12],[1,"\\n                  "],[10,0],[12],[1,"\\n"],[41,[30,0,["conversation","csat","mobileUserCommentsAllowed"]],[[[1,"                      "],[8,[39,12],[[24,0,"csat-comments"],[16,"placeholder",[30,0,["csatComments"]]],[16,"aria-label",[30,0,["csatComments"]]]],[["@value","@rows","@autofocus","@maxlength"],[[30,0,["csatRatings","comment"]],"3",true,200]],null],[1,"                    "]],[]],null],[1,"                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"submit-rating"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["enableSubmitButtonForResolvedConversationYes"]],[28,[37,3],[[30,0,["disableCsatVoting"]]],null]],null],[[[1,"                    "],[11,1],[24,0,"btn submit"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"submitCsatRating","true"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],[[[1,"                    "],[10,1],[14,0,"btn submit disabled"],[14,"role","button"],[14,"tabindex","0"],[14,"aria-disabled","true"],[12],[1,"\\n"],[41,[30,0,["isJwtAuthInProgressing"]],[[[1,"                        "],[1,[28,[35,4],["common.button.submitting"],null]],[1,"\\n"]],[]],[[[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n                      "]],[]]]],[]]],[1,"                    "],[13],[1,"\\n"]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["conversation","resolvedConversationNo"]],[[[1,"      "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n          "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n            "],[10,0],[14,0,"comment-header"],[12],[1,"\\n              "],[10,1],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_no_question"]],[[[1,"                  "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_no_question"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                  "],[1,[28,[35,4],["csat.csat_no_comment"],null]],[1,"\\n"]],[]]],[1,"              "],[13],[1,"\\n              "],[11,0],[16,0,[29,["csat-minimize ",[52,[28,[37,3],[[30,0,["allowCsatSubmit"]]],null],"disabled"]]]],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,4],["aria_labels.close_csat"],null]],[16,"aria-disabled",[52,[51,[30,0,["allowCsatSubmit"]]],"true"]],[4,[38,1],[[30,0],"submitCsatRating","false","true"],null],[12],[1,"\\n                "],[10,"i"],[14,0,"close_search_input icon-ic_close_small mild"],[12],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"align-middle"],[12],[1,"\\n              "],[10,0],[14,0,"voting-section"],[12],[1,"\\n                "],[10,0],[14,0,"comment"],[12],[1,"\\n                  "],[10,0],[12],[1,"\\n                    "],[8,[39,12],[[24,0,"csat-comments"],[16,"placeholder",[30,0,["csatComments"]]],[16,"aria-label",[30,0,["csatComments"]]]],[["@value","@rows","@autofocus","@maxlength"],[[30,0,["csatRatings","comment"]],"3",true,200]],null],[1,"                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,0],[14,0,"submit-rating"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["enableSubmitButtonForResolvedConversationNo"]],[28,[37,3],[[30,0,["disableCsatVoting"]]],null]],null],[[[1,"                    "],[11,1],[24,0,"btn submit"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"submitCsatRating","false"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],[[[1,"                    "],[10,1],[14,0,"btn submit disabled"],[12],[1,"\\n"],[41,[30,0,["isJwtAuthInProgressing"]],[[[1,"                        "],[1,[28,[35,4],["common.button.submitting"],null]],[1,"\\n"]],[]],[[[41,[30,0,["session","config","content","actions","csat_submit"]],[[[1,"                        "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_submit"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                        "],[1,[28,[35,4],["csat.submit"],null]],[1,"\\n                      "]],[]]]],[]]],[1,"                    "],[13],[1,"\\n"]],[]]],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["showCsat"]],[28,[37,3],[[30,0,["conversation","resolvedConversationYes"]]],null],[28,[37,3],[[30,0,["conversation","resolvedConversationNo"]]],null]],null],[[[1,"      "],[10,0],[14,0,"csat-inner animated delay-1 slideInUp speed"],[12],[1,"\\n        "],[10,1],[14,0,"text"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_question"]],[[[1,"            "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_question"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"            "],[1,[28,[35,4],["csat.csat_question"],null]],[1,"\\n"]],[]]],[1,"        "],[13],[1,"\\n        "],[10,0],[14,0,"btn-csat-wrapper"],[12],[1,"\\n          "],[11,1],[24,0,"btn-csat btn-csat-yes"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"csatVotingYes"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_yes"]],[[[1,"              "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_yes"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,4],["conversation.push_notification.yes"],null]],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n          "],[11,1],[24,0,"btn-csat btn-csat-no"],[24,"role","button"],[24,"tabindex","0"],[4,[38,1],[[30,0],"csatVotingNo"],null],[12],[1,"\\n"],[41,[30,0,["session","config","content","actions","csat_no"]],[[[1,"              "],[1,[28,[35,2],[[30,0,["session","config","content","actions","csat_no"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,4],["conversation.push_notification.no"],null]],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],[[[41,[30,0,["feedbackSubmitted"]],[[[1,"      "],[10,0],[14,0,"csat-inner animated slideInUp speed"],[12],[1,"\\n        "],[10,0],[14,0,"thank-you-feedback"],[12],[1,"\\n          "],[10,0],[14,0,"thank-you-content"],[12],[1,"\\n            "],[10,0],[14,0,"user-logo"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[15,"onerror",[30,0,["handleProfileImageError"]]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["hidePic"]],[30,0,["session","appLogoUrl"]]],null],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[15,"alt",[28,[37,4],["alt.app_logo"],null]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["agent","profilePicUrl"]],[28,[37,3],[[30,0,["hidePic"]]],null]],null],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,"img"],[15,"src",[30,0,["agent","profilePicUrl"]]],[15,"alt",[28,[37,4],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                "],[13],[1,"\\n"]],[]],[[[41,[30,0,["agent","displayName"]],[[[1,"                "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                  "],[10,1],[15,0,[29,["theme-bg ",[28,[37,6],[[30,0,["agent","displayName"]]],null]]]],[12],[1,"\\n                    "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                      "],[1,[28,[35,7],[[30,0,["agent","displayName"]]],null]],[1,"\\n                    "],[13],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "]],[]],null]],[]]]],[]]]],[]]],[1,"            "],[13],[1,"\\n            "],[10,"h2"],[12],[1,[28,[35,4],["csat.submitted"],null]],[13],[1,"\\n            "],[10,1],[14,0,"thank-you"],[12],[1,"\\n"],[41,[30,0,["session","config","content","headers","csat_thankyou"]],[[[1,"                "],[1,[28,[35,2],[[30,0,["session","config","content","headers","csat_thankyou"]],"strict"],null]],[1,"\\n"]],[]],[[[1,"                "],[1,[28,[35,4],["csat.thank_you"],null]],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "]],[]],null]],[]]]],[]]]],[]]],[1,"  "],[13],[1,"\\n"]],[]],null]],[],false,["if","action","sanitize-html","not","t","and","choose-theme","avatar-content","radio-button","eq","gte","or","textarea","unless"]]',
                moduleName: "hotline-web/components/app-csat-form/template.hbs",
                isStrictMode: !1
            });
            t.default = f
        },
        37452: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(83973)),
                o = a(n(48692)),
                s = a(n(12076));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/and", (function() {
                return o.default
            })), window.define("hotline-web/helpers/not", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "k0Pnx+nV",
                block: '[[[10,0],[15,0,[29,["email-input ",[52,[30,0,["invalidContactInfo"]],"has-error"]]]],[12],[1,"\\n  "],[8,[39,1],[[24,0,"contact-detail"],[16,"placeholder",[30,0,["contactInfoPlaceholder"]]],[16,"aria-label",[30,0,["contactInfoPlaceholder"]]]],[["@value","@type","@key-up"],[[30,0,["contactDetail"]],"text",[28,[37,2],[[30,0],"validateContactInfo"],null]]],null],[1,"\\n"],[41,[30,0,["showValidationMark"]],[[[1,"    "],[10,"img"],[14,0,"input-state"],[15,"src",[30,0,["images","ValidInput"]]],[15,"alt",[28,[37,3],["alt.valid_input"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[30,0,["invalidContactInfo"]],[[[1,"    "],[10,"img"],[14,0,"input-state"],[15,"src",[30,0,["images","InvalidInput"]]],[15,"alt",[28,[37,3],["alt.invalid_input"],null]],[12],[13],[1,"\\n  "]],[]],null]],[]]],[13],[1,"\\n"],[10,0],[15,0,[29,["user-comment ",[52,[30,0,["invalidUserMessage"]],"has-error"]]]],[12],[1,"\\n  "],[8,[39,4],[[24,0,"user-message-reply"],[16,"placeholder",[28,[37,3],["away_experience.offline_reply"],null]],[16,"aria-label",[28,[37,3],["away_experience.offline_reply"],null]]],[["@value","@type","@key-up","@rows","@maxlength"],[[30,0,["userMessage"]],"text",[28,[37,2],[[30,0],"validateUserMessage"],null],"15",2000]],null],[13],[1,"\\n"],[41,[30,0,["extraParams","isOfflineSendingFailed"]],[[[1,"  "],[10,0],[14,0,"error-text"],[12],[1,"\\n    "],[10,1],[12],[1,"\\n      "],[10,"img"],[14,0,"error-state"],[15,"src",[30,0,["images","ICNotSent"]]],[15,"alt",[28,[37,3],["alt.error_state"],null]],[12],[13],[1,"\\n    "],[13],[1,"\\n    "],[1,[28,[35,3],["away_experience.sending_failed"],null]],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[10,0],[14,0,"send-offline-reply"],[12],[1,"\\n  "],[11,"button"],[16,0,[29,["send-message\\n      ",[52,[28,[37,5],[[30,0,["offlineFormSubmitted"]],[28,[37,6],[[30,0,["extraParams","isOfflineSendingFailed"]]],null]],null],"disabled"]]]],[24,4,"button"],[4,[38,2],[[30,0],"sendMessages"],null],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["offlineFormSubmitted"]],[28,[37,6],[[30,0,["extraParams","isOfflineSendingFailed"]]],null]],null],[[[1,"      "],[1,[28,[35,3],["message.pending"],null]],[1,"\\n"]],[]],[[[41,[30,0,["extraParams","isOfflineSendingFailed"]],[[[1,"      "],[1,[28,[35,3],["away_experience.resend"],null]],[1,"\\n"]],[]],[[[1,"      "],[1,[28,[35,3],["away_experience.send"],null]],[1,"\\n    "]],[]]]],[]]],[1,"  "],[13],[1,"\\n"],[13]],[],false,["if","input","action","t","textarea","and","not"]]',
                moduleName: "hotline-web/components/app-offline-form/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        8087: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = g(n(83973)),
                o = g(n(99251)),
                s = g(n(21572)),
                a = g(n(5234)),
                l = g(n(18149)),
                r = g(n(49925)),
                u = g(n(11262)),
                c = g(n(98862)),
                d = g(n(38471)),
                p = g(n(24892)),
                h = g(n(52892)),
                f = g(n(47273)),
                m = g(n(20202));

            function g(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-select-box/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-select-box/component", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-time-picker/template", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-time-picker/component", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-feedback/template", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-feedback/component", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return c.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return d.default
            })), window.define("hotline-web/components/ui-upload-attachment/template", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-upload-attachment/component", (function() {
                return h.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/template", (function() {
                return f.default
            })), window.define("hotline-web/components/ui-quick-action-buttons/component", (function() {
                return m.default
            }));
            var v = (0, Ember.HTMLBars.template)({
                id: "gyt2DvW7",
                block: '[[[41,[30,0,["isFeedbackReplyMessage"]],[[[1,"  "],[10,0],[14,0,"bot-feedback-response-container"],[12],[1,"\\n    "],[10,"img"],[14,0,"bot-feedback-response-tick"],[15,"src",[30,0,["images","TickFeedbackSubmitted"]]],[15,"alt",[28,[37,1],["alt.bot_feedback_response_tick"],null]],[12],[13],[1,"\\n    "],[10,0],[14,0,"bot-feedback-response"],[12],[1,[28,[35,1],["faqs.thank_you_for_feedback"],null]],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["dropdownOptions","length"]],[[[1,"  "],[8,[39,2],null,[["@options","@multiple","@onChange"],[[30,0,["dropdownOptions"]],[30,0,["isMultiSelectDropdown"]],[28,[37,3],[[30,0],"dropdownSelectionHandler"],null]]],null],[1,"\\n\\n"]],[]],[[[41,[30,0,["timeFragments"]],[[[1,"  "],[8,[39,4],null,[["@fromTime","@toTime","@onSelect","@onKeyDown","@isValidationError"],[[30,0,["timeFragments","fromTime"]],[30,0,["timeFragments","toTime"]],[28,[37,3],[[30,0],"dropdownSelectionHandler"],null],[28,[37,3],[[30,0],"onTimePickerKeyDownHandler"],null],[30,0,["isValidationError"]]]],null],[1,"\\n\\n"]],[]],[[[41,[30,0,["feedbackData","content","length"]],[[[1,"    "],[10,0],[14,0,"fc-feedback-wrapper"],[15,"onkeydown",[28,[37,3],[[30,0],"setNextFocus"],null]],[12],[1,"\\n      "],[8,[39,5],null,[["@feedbackData","@feedbackType","@onSelect","@message","@quickActionButtons","@feedbackCommentQuickActionsSlashCommandOptions","@feedbackCommentOnQuickActionSelect","@feedbackCommentId","@feedbackCommentOnBlur","@feedbackCommentOnFocus","@feedbackCommentOnKeyDown","@feedbackCommentContent","@feedbackCommentExceedAction"],[[30,0,["feedbackData","content"]],[30,0,["feedbackData","feedbackType"]],[28,[37,3],[[30,0],"feedbackSelectionHandler"],null],[30,0,["message"]],[30,0,["quickActionButtons"]],[30,0,["quickActionsSlashCommandOptions"]],[28,[37,3],[[30,0],"triggerSendButtonMessage"],null],[30,0,["DOM_ID","appReplyComposerEditor"]],[28,[37,3],[[30,0],"focusOut"],null],[28,[37,3],[[30,0],"focusIn"],null],[28,[37,3],[[30,0],"keyPressDownLocal"],null],[30,0,["content"]],[28,[37,3],[[30,0],"setIsTextLimitExceeded"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[]]]],[]]]],[]]],[1,"\\n"],[41,[30,0,["customTextComposer"]],[[[1,"  "],[10,0],[15,0,[29,["h-reply h-custom-composer ",[52,[51,[30,0,["hotline","ui","onLine"]]],"is-disabled"]]]],[12],[1,"\\n"],[41,[51,[30,0,["hotline","ui","isDesktop"]]],[[[1,"      "],[11,3],[16,0,[29,["h-reply-container\\n          ",[52,[51,[30,0,["showPlaceholderText"]]],"show-highlight"]]]],[24,6,"#"],[4,[38,3],[[30,0],"beforeSendMessage"],null],[12],[1,"\\n        "],[10,0],[14,0,"h-reply-send"],[12],[1,"\\n          "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"    "],[8,[39,7],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["quickActionsSlashCommandOptions"]],[28,[37,3],[[30,0],"triggerSendButtonMessage"],null]]],[["default"],[[[[1,"\\n      "],[8,[30,1,["editor"]],null,[["@onBlur","@onFocus","@emojiSupport","@onKeyDown","@content","@exceedAction","@id","@contentEditable","@placeholder"],[[28,[37,3],[[30,0],"focusOut"],null],[28,[37,3],[[30,0],"focusIn"],null],true,[28,[37,3],[[30,0],"keyPressDownLocal"],null],[30,0,["content"]],[28,[37,3],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["DOM_ID","appReplyComposerEditor"]],true,"conversation.ce.placeholders.default"]],null],[1,"\\n    "]],[1]]]]],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["isAttachmentRequested"]],[[[1,"  "],[8,[39,8],null,[["@exceedAction","@file","@imageSelect","@clearImage","@sendAttachment"],[[28,[37,3],[[30,0],"setIsTextLimitExceeded"],null],[30,0,["file"]],[28,[37,3],[[30,0],[30,0,["imageSelect"]]],null],[28,[37,3],[[30,0],[30,0,["clearImage"]]],null],[30,0,["sendButtonMessage"]]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,2],[[[1,"  "],[8,[39,9],null,[["@quickActions","@sendButtonMessage"],[[30,2],[30,3]]],null],[1,"\\n"]],[]],null]],["wrapper","@quickActionButtons","@sendButtonMessage"],false,["if","t","ui-select-box","action","ui-time-picker","ui-feedback","unless","ui-editor-wrapper","ui-upload-attachment","ui-quick-action-buttons"]]',
                moduleName: "hotline-web/components/app-reply-composer/template.hbs",
                isStrictMode: !1
            });
            t.default = v
        },
        44587: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(92945)),
                o = s(n(83973));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/or", (function() {
                return i.default
            })), window.define("hotline-web/helpers/t", (function() {
                return o.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "Y+o9hb8T",
                block: '[[[11,0],[16,0,[29,["ui-agent-typing-indicator ",[52,[51,[28,[37,1],[[30,0,["isAgentTyping"]],[30,0,["showTypingIndForBots"]]],null]],"hidden"]]]],[16,"aria-label",[28,[37,2],["aria_labels.agent_typing"],null]],[17,1],[12],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n  "],[10,1],[14,0,"indicator-dot"],[14,"aria-hidden","true"],[12],[13],[1,"\\n"],[13],[1,"\\n"]],["&attrs"],false,["unless","or","t"]]',
                moduleName: "hotline-web/components/ui-agent-typing-indicator/template.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        67157: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(19390)),
                o = a(n(98661)),
                s = a(n(83973));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/eq", (function() {
                return i.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "ZXEdzQdM",
                block: '[[[10,0],[14,0,"file-meta animated fadeInUp faster"],[12],[1,"\\n   "],[10,1],[14,0,"file-name"],[12],[1,"\\n      "],[10,"i"],[15,0,[29,["icons ",[52,[28,[37,1],[[30,1,["fileType"]],[30,0,["fileType","IMAGE"]]],null],"icon-ic_image","icon-ic_attachment"]]]],[14,"aria-hidden","true"],[12],[13],[1," "],[1,[28,[35,2],[[30,1,["fileData","name"]],"strict"],null]],[1,"\\n   "],[13],[1,"\\n\\n"],[41,[30,1,["fileContent"]],[[[1,"      "],[11,1],[24,0,"edit"],[24,"role","button"],[16,"onkeydown",[30,2]],[24,"tabindex","0"],[16,"aria-label",[28,[37,3],["aria_labels.select_image"],null]],[4,[38,4],[[30,0],[30,3]],null],[12],[1,"\\n         "],[10,"i"],[14,0,"icons icon-ic_pencil"],[12],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"\\n   "],[11,1],[24,0,"close"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,3],["aria_labels.clear_image"],null]],[4,[38,4],[[30,0],[30,4]],null],[12],[1,"\\n      "],[10,"i"],[14,0,"icon-ic_close_small"],[12],[13],[1,"\\n   "],[13],[1,"\\n"],[13]],["@fileData","@onKeyDown","@imageSelect","@clearImage"],false,["if","eq","sanitize-html","t","action"]]',
                moduleName: "hotline-web/components/ui-attachment-preview/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        73734: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "09j+IXLq",
                block: '[[[10,1],[15,0,[29,["btn-content ",[52,[30,0,["isIPhone"]],"iphone-button"]]]],[12],[1,"\\n  "],[1,[30,0,["generatedHTML"]]],[1,"\\n"],[13]],[],false,["if"]]',
                moduleName: "hotline-web/components/ui-button-composer/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        48812: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(83973)),
                o = a(n(51180)),
                s = a(n(74902));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-session-view/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-calendar-session-view/component", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "ZhGqMVu0",
                block: '[[[42,[28,[37,1],[[28,[37,1],[[30,0,["daysWithSlotsAsQuads"]]],null]],null],null,[[[1,"  "],[10,0],[14,0,"cal-weekday-details"],[14,"tabindex","0"],[12],[1,"\\n    "],[10,1],[14,0,"cal-weekday-name"],[12],[1,"\\n      "],[1,[30,1,["weekday"]]],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"cal-weekday-date bolder"],[12],[1,"\\n      "],[1,[30,1,["date"]]],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,1,["morningSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session morning icon-ic_morning"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.morn"],null]],[1,"("],[1,[30,1,["morningSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["morningSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["afternoonSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session afternoon icon-ic_afternoon"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.afternoon"],null]],[1,"("],[1,[30,1,["afternoonSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["afternoonSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["eveningSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session evening icon-ic_evening"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.evening"],null]],[1,"("],[1,[30,1,["eveningSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["eveningSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,1,["nightSlots"]],[[[1,"    "],[10,0],[14,0,"cal-time-slots pad-quad"],[12],[1,"\\n      "],[10,0],[14,0,"session-name picker-max"],[12],[1,"\\n        "],[10,"i"],[14,0,"ic-calendar-session night icon-ic_night"],[12],[13],[1,"\\n        "],[10,1],[14,0,"session-name-text"],[12],[1,[28,[35,3],["calendar.night"],null]],[1,"("],[1,[30,1,["nightSlotsCount"]]],[1,")"],[13],[1,"\\n      "],[13],[1,"\\n      "],[8,[39,4],null,[["@slots","@viewTriplets","@openConfirmationView"],[[30,1,["nightSlots"]],"",[28,[37,5],[[30,0],"openConfirmationView"],null]]],null],[1,"\\n    "],[13],[1,"\\n"]],[]],null]],[1]],null]],["day"],false,["each","-track-array","if","t","ui-calendar-session-view","action"]]',
                moduleName: "hotline-web/components/ui-calendar-day-quads/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        35522: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(51180)),
                o = s(n(74902));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-calendar-session-view/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-session-view/component", (function() {
                return o.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "awo5KgU2",
                block: '[[[10,0],[14,0,"cal-weekday-details"],[14,"tabindex","0"],[12],[1,"\\n"],[41,[30,0,["isLoadingSlots"]],[[[1,"    "],[10,1],[14,0,"is-loading-weekday"],[12],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"is-loading-weekday-name"],[12],[1,"\\n    "],[13],[1,"\\n"]],[]],[[[1,"    "],[10,1],[14,0,"cal-weekday-name"],[12],[1,"\\n      "],[1,[30,0,["model","weekday"]]],[1,"\\n    "],[13],[1,"\\n    "],[10,1],[14,0,"cal-weekday-date"],[12],[1,"\\n      "],[1,[30,0,["model","date"]]],[1,"\\n    "],[13],[1,"\\n"]],[]]],[13],[1,"\\n"],[10,0],[14,0,"cal-time-slots"],[12],[1,"\\n"],[41,[30,0,["isLoadingSlots"]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["mockSlots"]]],null]],null],null,[[[1,"      "],[10,0],[14,0,"cal-time-slot-group cal-time-slot-triplet loading"],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,1]],null]],null],null,[[[1,"          "],[10,1],[14,0,"cal-time-slot"],[12],[1,"\\n            "],[10,1],[14,0,"is-loading-timeslot"],[12],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[1,"      "],[13],[1,"\\n"]],[1]],null]],[]],[[[1,"    "],[10,0],[14,0,"session-name"],[12],[1,"\\n      "],[10,"i"],[15,0,[30,0,["tripletSessionIconClass"]]],[12],[13],[1,"\\n      "],[10,1],[14,0,"session-name-text"],[12],[1,[30,0,["tripletSessionWithCount"]]],[13],[1,"\\n    "],[13],[1,"\\n    "],[8,[39,3],null,[["@slots","@viewTriplets","@bookSlot"],[[30,0,["slotsAsTriplets"]],"true",[28,[37,4],[[30,0],"bookSlot"],null]]],null],[1,"\\n"]],[]]],[13]],["slotsTriplet"],false,["if","each","-track-array","ui-calendar-session-view","action"]]',
                moduleName: "hotline-web/components/ui-calendar-day-triplets/template.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        23738: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(83973)),
                o = a(n(48812)),
                s = a(n(70122));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-calendar-day-quads/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-calendar-day-quads/component", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "70N4b2So",
                block: '[[[10,0],[14,0,"cal-picker-nav"],[12],[1,"\\n  "],[10,1],[14,0,"cal-nav-left"],[12],[1,"\\n    "],[11,"i"],[24,0,"ic-cal-back clickable icon-ic_back_calendar"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,0],["aria_labels.close_calendar_picker_maxmode"],null]],[4,[38,1],[[30,0],"closeCalendarPickerMaxMode"],null],[12],[13],[1,"\\n  "],[13],[1,"\\n  "],[10,1],[14,0,"cal-picker-title"],[12],[1,"\\n    "],[1,[28,[35,0],["calendar.schedule_a_demo"],null]],[1,"\\n  "],[13],[1,"\\n  "],[10,1],[14,0,"cal-meeting-length"],[12],[1,"\\n    "],[1,[30,0,["meetingLengthAsString"]]],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"],[10,0],[14,0,"cal-timings-scroll"],[12],[1,"\\n  "],[8,[39,2],null,[["@openConfirmationScreen","@model"],[[28,[37,1],[[30,0],"openConfirmationScreen"],null],[30,0,["slotsData"]]]],null],[1,"\\n"],[13]],[],false,["t","action","ui-calendar-day-quads"]]',
                moduleName: "hotline-web/components/ui-calendar-picker-max/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        19934: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = d(n(83973)),
                o = d(n(12076)),
                s = d(n(48692)),
                a = d(n(26207)),
                l = d(n(51996)),
                r = d(n(98661)),
                u = d(n(35522)),
                c = d(n(46616));

            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/not", (function() {
                return o.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return a.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return l.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-calendar-day-triplets/template", (function() {
                return u.default
            })), window.define("hotline-web/components/ui-calendar-day-triplets/component", (function() {
                return c.default
            }));
            var p = (0, Ember.HTMLBars.template)({
                id: "whxmvZjh",
                block: '[[[10,0],[14,0,"h-chat"],[12],[1,"\\n  "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n    "],[10,0],[14,0,"h-comment calendar-picker-container"],[12],[1,"\\n"],[41,[30,0,["isTimeZoneSelectMode"]],[[[1,"        "],[10,0],[14,0,"timezone-picker"],[12],[1,"\\n          "],[10,0],[14,0,"timezone-picker-header"],[12],[1,"\\n            "],[11,1],[24,0,"cal-nav-left"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.close_time_zone_selectmode"],null]],[4,[38,2],[[30,0],"closeTimeZoneSelectMode"],null],[12],[1,"\\n              "],[10,"i"],[14,0,"ic-cal-back clickable icon-ic_back_calendar"],[12],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,1],[14,0,"cal-tz-existing"],[12],[1,"\\n"],[41,[30,0,["userCustomTimeZone"]],[[[1,"                "],[1,[30,0,["userCustomTimeZone"]]],[1,"\\n"]],[]],[[[1,"                "],[1,[30,0,["userDefaultTimeZone"]]],[1,"\\n"]],[]]],[1,"            "],[13],[1,"\\n          "],[13],[1,"\\n"],[1,"          "],[10,0],[14,0,"timezone-picker-body"],[12],[1,"\\n            "],[10,0],[14,0,"time-zone-search-bar"],[15,"onkeydown",[28,[37,2],[[30,0],"dropDownKeyboardEvent"],null]],[12],[1,"\\n              "],[8,[39,3],[[24,0,"time-zone-input"],[16,"aria-label",[28,[37,1],["calendar.search_tz"],null]]],[["@value","@placeholder"],[[30,0,["timeZoneFilterValue"]],[28,[37,1],["calendar.search_tz"],null]]],null],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"time-zones-container"],[12],[1,"\\n              "],[10,"ul"],[14,0,"time-zones-list"],[14,"role","listbox"],[14,1,"time-zone-list"],[12],[1,"\\n"],[42,[28,[37,5],[[28,[37,5],[[30,0,["filteredTimeZones"]]],null]],null],null,[[[1,"                  "],[11,"li"],[24,0,"time-zone-list-item"],[24,"tabindex","-1"],[24,"aria-selected","false"],[24,"role","option"],[4,[38,2],[[30,0],"setUserCustomTimezone",[30,1]],null],[12],[1,"\\n                    "],[1,[30,1]],[1,"\\n                  "],[13],[1,"\\n"]],[1]],null],[1,"              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"],[1,"        "],[13],[1,"\\n"]],[]],[[[1,"        "],[10,0],[14,0,"calendar-picker-minified"],[14,"tabindex","-1"],[12],[1,"\\n          "],[10,0],[15,0,[29,["calendar-picker-header ",[52,[51,[30,0,["userEmailSubmitted"]]],"email-input-view"]]]],[12],[1,"\\n            "],[10,0],[14,0,"cal-header-left"],[12],[1,"\\n\\n              "],[10,"i"],[14,0,"ic-calendar cp-mini icon-ic_schedule_meeting"],[12],[13],[1,"\\n              "],[10,1],[14,0,"schedule-a-demo-text"],[12],[1,"\\n                "],[1,[28,[35,1],["calendar.schedule_a_demo"],null]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n            "],[10,0],[14,0,"cal-header-tw"],[12],[1,"\\n              "],[1,[30,0,["meetingLengthAsString"]]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"],[41,[28,[37,7],[[30,0,["userEmailSubmitted"]]],null],[[[1,"            "],[10,0],[14,0,"cal-picker-email-view"],[12],[1,"\\n              "],[10,0],[14,0,"email-input-container"],[12],[1,"\\n                "],[10,0],[15,0,[29,["email-input ",[52,[28,[37,8],[[28,[37,7],[[30,0,["userInputEmailIsValid"]]],null],[30,0,["showValidationCrossMarkExplicit"]]],null],"invalid-email"]]]],[12],[1,"\\n                  "],[8,[39,3],[[24,0,"email-input-field"],[16,"aria-label",[28,[37,1],["calendar.email_placeholder"],null]]],[["@enter","@value","@placeholder"],[[28,[37,2],[[30,0],"userEmailEnterPress"],null],[30,0,["userInputEmail"]],[28,[37,1],["calendar.email_placeholder"],null]]],null],[1,"\\n                "],[13],[1,"\\n                "],[11,0],[24,0,"email-action"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.schedule_meeting"],null]],[4,[38,2],[[30,0],[52,[30,0,["userInputEmailIsValid"]],"userEmailEnterPress",""]],null],[12],[1,"\\n                  "],[10,"i"],[15,0,[30,0,["emailIconClass"]]],[12],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["message","internalMeta","meetingStartTime"]],[[[1,"            "],[10,0],[14,0,"cal-picker-conf-view"],[12],[1,"\\n              "],[10,0],[14,0,"participants"],[12],[1,"\\n                "],[10,0],[14,0,"agent-segment"],[12],[1,"\\n                  "],[10,0],[14,0,"cal-agent-pic"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,1],["aria-label.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["agentData","profilePicThumbUrl"]],[28,[37,7],[[30,0,["hideName"]]],null]],null],[[[41,[30,0,["hidePic"]],[[[41,[30,0,["agentData","firstName"]],[[[1,"                          "],[10,1],[14,0,"event-participant-avatar"],[12],[1,"\\n                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,9],[[30,0,["agentData","firstName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[14,"data-calendar-agent-name-avatar",""],[12],[1,"\\n                                  "],[1,[28,[35,10],[[30,0,["agentData","firstName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                          "],[10,1],[14,0,"event-participant-avatar"],[12],[1,"\\n                            "],[10,1],[14,0,"avatar-content-wrap agent-circle"],[12],[1,"\\n                              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,9],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                                  "],[1,[28,[35,10],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                                "],[13],[1,"\\n                              "],[13],[1,"\\n                            "],[13],[1,"\\n                          "],[13],[1,"\\n                        "]],[]],null]],[]]]],[]],[[[1,"                        "],[10,"img"],[15,"src",[30,0,["agentData","profilePicThumbUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["session","appLogoUrl"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["session","appLogoUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.app_logo"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["images","AgentDefault"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n                    "]],[]]]],[]]]],[]]],[1,"                  "],[13],[1,"\\n"],[41,[28,[37,8],[[30,0,["agentData","firstName"]],[28,[37,7],[[30,0,["hideName"]]],null]],null],[[[1,"                    "],[10,0],[14,0,"cal-agent-name"],[12],[1,[30,0,["agentData","firstName"]]],[13],[1,"\\n"]],[]],[[[41,[30,0,["session","appDisplayName"]],[[[1,"                      "],[10,0],[14,0,"cal-agent-name"],[12],[1,"\\n                        "],[1,[28,[35,11],[[30,0,["session","appDisplayName"]],"strict"],null]],[1,"\\n                      "],[13],[1,"\\n"]],[]],null]],[]]],[1,"                "],[13],[1,"\\n                "],[10,0],[14,0,"user-segment"],[12],[1,"\\n                  "],[10,0],[14,0,"cal-user-pic"],[12],[1,"\\n"],[41,[30,0,["userPicUrl"]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["userPicUrl"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.user_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[1,"                      "],[10,"img"],[15,"src",[30,0,["images","CalUser"]]],[14,0,"event-participant-avatar"],[15,"alt",[28,[37,1],["alt.participant_avatar"],null]],[12],[13],[1,"\\n"]],[]]],[1,"                  "],[13],[1,"\\n                  "],[10,0],[14,0,"cal-user-name"],[12],[1,"\\n                    "],[1,[28,[35,1],["calendar.you"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"meeting-date"],[12],[1,"\\n                "],[1,[30,0,["dateToBeBooked"]]],[1,"\\n              "],[13],[1,"\\n              "],[11,0],[24,0,"meeting-time"],[24,"role","button"],[24,"tabindex","0"],[16,"aria-label",[28,[37,1],["aria_labels.time_slot"],[["time"],[[30,0,["timeSlotToBeBooked"]]]]]],[4,[38,2],[[30,0],"resetSlot"],null],[12],[1,"\\n                "],[1,[30,0,["timeSlotToBeBooked"]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"time-zone"],[12],[1,"\\n                "],[1,[30,0,["userTimeZoneToUse"]]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"],[1,"            "],[11,0],[16,0,[29,["cal-confirmation-div ",[52,[30,0,["message","isCalendarInviteBooked"]],"disabled"]]]],[16,"aria-disabled",[52,[30,0,["message","isCalendarInviteBooked"]],"true"]],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"bookSlot"],null],[12],[1,"\\n              "],[1,[28,[35,1],["calendar.confirm"],null]],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["noSlotsAvailable"]],[[[1,"              "],[10,0],[14,0,"calendar-slots-not-av"],[12],[1,"\\n                "],[1,[28,[35,1],["calendar.no_slots"],null]],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"calendar-picker-body"],[12],[1,"\\n                "],[8,[39,12],null,[["@isLoadingSlots","@setSlot","@model"],[[30,0,["isLoadingSlots"]],[28,[37,2],[[30,0],"setSlot"],null],[30,0,["firstFreeTimeSlots"]]]],null],[1,"\\n                "],[10,0],[15,0,[29,["calendar-picker-actions ",[52,[30,0,["isLoadingSlots"]],"is-loading"]]]],[12],[1,"\\n"],[41,[51,[30,0,["isLoadingSlots"]]],[[[1,"                    "],[11,0],[24,0,"calendar-show-more"],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"maximizeCalendarPicker"],null],[12],[1,"\\n                      "],[1,[28,[35,1],["calendar.show_more"],null]],[1,"\\n                    "],[13],[1,"\\n                    "],[11,0],[24,0,"calendar-tz-action"],[24,"role","combobox"],[24,"tabindex","0"],[4,[38,2],[[30,0],"switchToTimeZoneSelectMode"],null],[12],[1,"\\n"],[41,[30,0,["userCustomTimeZone"]],[[[1,"                        "],[1,[30,0,["userCustomTimeZone"]]],[1,"\\n"]],[]],[[[1,"                        "],[1,[30,0,["userDefaultTimeZone"]]],[1,"\\n"]],[]]],[1,"                    "],[13],[1,"\\n"]],[]],null],[1,"                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]]],[1,"\\n"],[1,"            "],[11,0],[24,0,"calendar-cancel-action"],[24,"role","button"],[24,"tabindex","0"],[4,[38,2],[[30,0],"cancelInvite"],null],[12],[1,"\\n              "],[1,[28,[35,1],["calendar.cancel"],null]],[1,"\\n            "],[13],[1,"\\n"],[1,"          "]],[]]]],[]]],[1,"        "],[13],[1,"\\n"]],[]]],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"],[13],[1,"\\n"]],["filterResult"],false,["if","t","action","input","each","-track-array","unless","not","and","choose-theme","avatar-content","sanitize-html","ui-calendar-day-triplets"]]',
                moduleName: "hotline-web/components/ui-calendar-picker/template.hbs",
                isStrictMode: !1
            });
            t.default = p
        },
        51180: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, o = (i = n(46750)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/helpers/maximize-calendar-slot", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "goOpqBct",
                block: '[[[41,[30,0,["viewTriplets"]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["slots"]]],null]],null],null,[[[1,"    "],[10,0],[15,0,[29,["cal-time-slot-group cal-time-slot-triplet ",[28,[37,3],[[30,2],[30,1,["length"]],true],null]]]],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,1]],null]],null],null,[[[1,"        "],[11,1],[24,0,"cal-time-slot maximize-slot"],[24,"role","button"],[24,"tabindex","0"],[4,[38,4],[[30,0],"bookSlot",[30,3]],null],[12],[1,"\\n          "],[1,[30,3,["fromAsTime"]]],[1,"\\n        "],[13],[1,"\\n"]],[3]],null],[1,"    "],[13],[1,"\\n"]],[1,2]],null]],[]],[[[42,[28,[37,2],[[28,[37,2],[[30,0,["slots"]]],null]],null],null,[[[1,"    "],[10,0],[15,0,[29,["cal-time-slot-group cal-time-slot-quad ",[28,[37,3],[[30,5],[30,4,["length"]],false],null]]]],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,4]],null]],null],null,[[[1,"        "],[11,1],[24,0,"cal-time-slot maximize-slot"],[24,"role","button"],[24,"tabindex","0"],[4,[38,4],[[30,0],"openConfirmationView",[30,6]],null],[12],[1,"\\n          "],[1,[30,6,["fromAsTime"]]],[1,"\\n        "],[13],[1,"\\n"]],[6]],null],[1,"    "],[13],[1,"\\n"]],[4,5]],null]],[]]]],["slotsTriplet","index","slot","slotQuad","index","slot"],false,["if","each","-track-array","maximize-calendar-slot","action"]]',
                moduleName: "hotline-web/components/ui-calendar-session-view/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        92482: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "OxpG/mnC",
                block: '[[[41,[30,1],[[[1,"  "],[10,1],[14,0,"chip__content"],[12],[1,[30,1]],[13],[1,"\\n"]],[]],null]],["@label"],false,["if"]]',
                moduleName: "hotline-web/components/ui-chip/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        13734: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i, o = (i = n(1958)) && i.__esModule ? i : {
                default: i
            };
            window.define("hotline-web/components/ember-flatpickr", (function() {
                return o.default
            }));
            var s = (0, Ember.HTMLBars.template)({
                id: "cl6Zg4Xi",
                block: '[[[10,0],[14,1,"margin-date-picker"],[14,0,"message-container margin-reply-fragments resize-fragments"],[12],[1,"\\n  "],[8,[39,0],null,[["@date","@inline","@minDate","@maxDate","@onChange","@dateFormat"],["",true,[30,0,["minDate"]],[30,0,["maxDate"]],[28,[37,1],[[30,0],"onChangeDate"],null],[30,0,["dateFormat"]]]],null],[1,"\\n"],[13]],[],false,["ember-flatpickr","action"]]',
                moduleName: "hotline-web/components/ui-date-picker/template.hbs",
                isStrictMode: !1
            });
            t.default = s
        },
        2895: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(93521)),
                o = l(n(19390)),
                s = l(n(48692)),
                a = l(n(98661));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/array-includes", (function() {
                return i.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return o.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "JC8n8ibH",
                block: '[[[11,"ul"],[24,0,"dropdown-list"],[24,"tabindex","0"],[4,[38,0],[[30,1],[30,0,["onEnter"]]],null],[12],[1,"\\n"],[42,[28,[37,2],[[28,[37,2],[[30,2]],null]],null],null,[[[44,[[28,[37,4],[[30,5],[28,[37,5],[[30,3],[30,0,["bindLabel"]]],null]],[["property"],[[30,0,["bindLabel"]]]]]],[[[1,"    "],[11,"li"],[24,"role","button"],[16,0,[29,["dropdown-item d-flex ",[52,[30,6],"selected"]," ",[52,[28,[37,7],[[30,0,["activeClassIndex"]],[30,4]],null],"active"]]]],[16,"aria-selected",[29,[[28,[37,8],[[30,1],[28,[37,7],[[30,4],0],null]],null]]]],[4,[38,9],["click",[28,[37,10],[[30,0,["onSelect"]],[30,3]],null]],null],[4,[38,9],["mouseover",[28,[37,10],[[30,0,["updateActiveClass"]],[30,4]],null]],null],[12],[1,"\\n      "],[10,1],[14,0,"dropdown-list-item ellipsis"],[12],[1,"\\n        "],[1,[28,[35,11],[[30,3,["label"]],"strict"],null]],[1,"\\n      "],[13],[1,"\\n"],[41,[30,6],[[[1,"        "],[10,"i"],[14,0,"icon icon-check_circle_solid"],[12],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n"]],[6]]]],[3,4]],null],[13]],["@enableKeyboardNavigation","@items","option","index","@selectedItems","isSelectedOption"],false,["attach-keyboard-navigation","each","-track-array","let","array-includes","get","if","eq","and","on","fn","sanitize-html"]]',
                moduleName: "hotline-web/components/ui-dropdown-list/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        98862: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(48692)),
                o = l(n(37717)),
                s = l(n(5957)),
                a = l(n(83057));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/and", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-quick-action-slash-menu/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-quick-action-slash-menu/component", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-editor/component", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "W9NexFAB",
                block: '[[[41,[28,[37,1],[[30,0,["slashQuickActionsText"]],[30,1]],null],[[[1,"  "],[8,[39,2],null,[["@quickActions","@search","@selectionHandler"],[[30,1],[30,0,["slashQuickActionsText"]],[28,[37,3],[[30,0],[30,0,["handleSelectionHandler"]]],null]]],null],[1,"\\n"]],[]],null],[1,"\\n"],[18,2,[[28,[37,5],null,[["editor"],[[50,"ui-editor",0,null,[["onKeyUp"],[[28,[37,3],[[30,0],[30,0,["keyPressUp"]]],null]]]]]]]]],[1,"\\n"]],["@quickActionsSlashCommandOptions","&default"],false,["if","and","ui-quick-action-slash-menu","action","yield","hash","component"]]',
                moduleName: "hotline-web/components/ui-editor-wrapper/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        20961: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "pe3A7rXI",
                block: '[[[10,"svg"],[14,"width","1.7rem"],[15,"height",[30,1]],[14,"viewBox","0 0 20 20"],[14,"fill","none"],[14,"xmlns","http://www.w3.org/2000/svg","http://www.w3.org/2000/xmlns/"],[15,0,[30,2]],[12],[1,"\\n  "],[10,"path"],[14,"fill-rule","evenodd"],[14,"clip-rule","evenodd"],[15,"d",[30,0,["ellipsisAlignemnt"]]],[15,"fill",[30,3]],[12],[13],[1,"\\n"],[13]],["@height","@class","@fillColor"],false,[]]',
                moduleName: "hotline-web/components/ui-ellipsis-icon/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        49925: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = u(n(19390)),
                o = u(n(16136)),
                s = u(n(83973)),
                a = u(n(82370)),
                l = u(n(98862)),
                r = u(n(38471));

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/eq", (function() {
                return i.default
            })), window.define("hotline-web/components/radio-button/component", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            })), window.define("hotline-web/helpers/gte", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-editor-wrapper/template", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-editor-wrapper/component", (function() {
                return r.default
            }));
            var c = (0, Ember.HTMLBars.template)({
                id: "Te36rK4d",
                block: '[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_RATING"]]],null],[[[1,"  "],[10,0],[15,0,[29,["csat-rating animated fadeIn speed ",[52,[30,0,["quickActionButtons"]],"feedback-quickactions"]]]],[14,1,"bot-feedback-rating"],[12],[1,"\\n    "],[10,0],[14,0,"vote-yes-outer animated delay-1 slideInUp speed"],[12],[1,"\\n      "],[10,0],[14,0,"vote-yes-wrapper"],[12],[1,"\\n        "],[10,0],[14,0,"vote-yes"],[12],[1,"\\n          "],[10,0],[14,0,"align-middle"],[12],[1,"\\n            "],[10,0],[14,0,"voting-section"],[12],[1,"\\n              "],[10,0],[14,0,"rate"],[12],[1,"\\n                "],[10,"fieldset"],[14,0,"rating"],[14,"role","radiogroup"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["feedbackData"]]],null]],null],null,[[[1,"                    "],[8,[39,4],null,[["@id","@name","@value","@tabIndex","@ariaHidden","@group","@onchange"],[[29,["star",[30,1,["displayOrder"]]]],"rating",[30,1],[30,2],"true",[30,0,["feedback","star"]],[28,[37,5],[[30,0],"submitBotFeedback"],null]]],null],[1,"\\n                    "],[10,"label"],[15,"for",[29,["star",[30,1,["displayOrder"]]]]],[14,0,"star-label bot-feedback-rating-star-label"],[15,"tabindex",[52,[28,[37,1],[[30,0,["feedback","star"]],[30,1,["displayOrder"]]],null],"0","-1"]],[14,"role","radio"],[15,"aria-label",[28,[37,6],["aria_labels.star"],[["star"],["{{rating.displayOrder}}"]]]],[15,"aria-checked",[29,[[28,[37,7],[[30,0,["feedback","star"]],[30,1,["displayOrder"]]],null]]]],[12],[1,[30,1,["label"]]],[13],[1,"\\n"]],[1,2]],null],[1,"                  "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_OPINION_POLL"]]],null],[[[1,"  "],[10,0],[14,0,"bot-feedback-poll"],[12],[1,"\\n"],[42,[28,[37,3],[[28,[37,3],[[30,0,["feedbackData"]]],null]],null],null,[[[1,"        "],[11,"button"],[16,1,[29,["opinion-poll-btn-",[30,4]]]],[24,0,"h-img-button"],[24,4,"button"],[4,[38,5],[[30,0],"submitBotFeedback",[30,3]],null],[12],[1,"\\n          "],[10,1],[14,0,"btn-content"],[12],[1,[30,3,["label"]]],[13],[1,"\\n        "],[13],[1,"\\n"]],[3,4]],null],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,1],[[30,0,["feedbackType"]],[30,0,["FEEDBACK_COMMENT"]]],null],[[[1,"  "],[10,0],[14,0,"bot-feedback-comment h-reply"],[12],[1,"\\n    "],[10,0],[15,0,[29,["h-reply h-custom-composer ",[52,[51,[30,0,["hotline","ui","onLine"]]],"is-disabled"]]]],[12],[1,"\\n"],[41,[51,[30,0,["hotline","ui","isDesktop"]]],[[[1,"        "],[11,3],[16,0,[29,["h-reply-container\\n            ",[52,[30,0,["isValueInEditor"]],"active","disabled"],"\\n            ",[52,[51,[30,0,["showPlaceholderText"]]],"show-highlight"]]]],[24,6,"#"],[4,[38,5],[[30,0],"sendMessageFromMobile"],null],[12],[1,"\\n          "],[10,0],[14,0,"h-reply-send"],[12],[1,"\\n            "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n          "],[13],[1,"\\n        "],[13],[1,"\\n"]],[]],null],[1,"      "],[8,[39,9],null,[["@quickActionsSlashCommandOptions","@onQuickActionSelect"],[[30,0,["feedbackCommentQuickActionsSlashCommandOptions"]],[30,0,["feedbackCommentOnQuickActionSelect"]]]],[["default"],[[[[1,"\\n        "],[8,[30,5,["editor"]],null,[["@onBlur","@onFocus","@emojiSupport","@onKeyDown","@content","@exceedAction","@id","@contentEditable","@placeholder","@hasValueInEditor"],[[30,0,["feedbackCommentOnBlur"]],[30,0,["feedbackCommentOnFocus"]],true,[30,0,["keyPressDownFeedbackComment"]],[30,0,["feedbackCommentContent"]],[30,0,["feedbackCommentExceedAction"]],[30,0,["feedbackCommentId"]],true,"aria_labels.feedback_comment",[28,[37,5],[[30,0],"hasValueInEditor"],null]]],null],[1,"\\n      "]],[5]]]]],[1,"\\n"],[41,[30,0,["isFeedbackCommentTextLengthExceeded"]],[[[1,"          "],[10,0],[14,0,"err-feeback-comment"],[12],[1,"\\n            "],[10,1],[14,0,"validation-error-info"],[12],[1,"\\n              "],[10,"img"],[14,0,"validation-error-icon"],[15,"src",[30,0,["images","ValidationErrorIcon"]]],[15,"alt",[28,[37,6],["alt.invalid_input"],null]],[12],[13],[1,"\\n              "],[10,1],[12],[1,[28,[35,6],["alt.bot_feedback_comment_text_limit_exceeded_error"],null]],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],[]]]],[]]]],["rating","index","opinionPollButton","index","wrapper"],false,["if","eq","each","-track-array","radio-button","action","t","gte","unless","ui-editor-wrapper"]]',
                moduleName: "hotline-web/components/ui-feedback/template.hbs",
                isStrictMode: !1
            });
            t.default = c
        },
        33401: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = y(n(83973)),
                o = y(n(48692)),
                s = y(n(26207)),
                a = y(n(51996)),
                l = y(n(19390)),
                r = y(n(12076)),
                u = y(n(56480)),
                c = y(n(72847)),
                d = y(n(98661)),
                p = y(n(52310)),
                h = y(n(12688)),
                f = y(n(15112)),
                m = y(n(37452)),
                g = y(n(79100)),
                v = y(n(19934)),
                b = y(n(94101));

            function y(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/t", (function() {
                return i.default
            })), window.define("hotline-web/helpers/and", (function() {
                return o.default
            })), window.define("hotline-web/helpers/choose-theme", (function() {
                return s.default
            })), window.define("hotline-web/helpers/avatar-content", (function() {
                return a.default
            })), window.define("hotline-web/helpers/eq", (function() {
                return l.default
            })), window.define("hotline-web/helpers/not", (function() {
                return r.default
            })), window.define("hotline-web/helpers/is-same", (function() {
                return u.default
            })), window.define("hotline-web/helpers/format-time", (function() {
                return c.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return d.default
            })), window.define("hotline-web/helpers/contain-valid-text-fragment", (function() {
                return p.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/template", (function() {
                return h.default
            })), window.define("hotline-web/components/ui-unity-message-fragment/component", (function() {
                return f.default
            })), window.define("hotline-web/components/app-offline-form/template", (function() {
                return m.default
            })), window.define("hotline-web/components/app-offline-form/component", (function() {
                return g.default
            })), window.define("hotline-web/components/ui-calendar-picker/template", (function() {
                return v.default
            })), window.define("hotline-web/components/ui-calendar-picker/component", (function() {
                return b.default
            }));
            var w = (0, Ember.HTMLBars.template)({
                id: "NODE/7I/",
                block: '[[[41,[30,0,["model","isCBInitiated"]],[[[1,"  "],[10,0],[14,0,"h-chat h-fc-co-browse-pad"],[12],[1,"\\n"],[41,[30,0,["isGrpStart"]],[[[1,"      "],[10,0],[14,0,"agent-pic"],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[30,0,["agentPic","profilePicThumbUrl"]],[[[1,"          "],[10,"img"],[15,"src",[30,0,["agentPic","profilePicThumbUrl"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[30,0,["hideName"]],[30,0,["session","appDisplayName"]]],null],[[[1,"          "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n              "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","messageUserName"]],[[[1,"          "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n            "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["model","messageUserName"]]],null]]]],[12],[1,"\\n              "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                "],[1,[28,[35,4],[[30,0,["model","messageUserName"]]],null]],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "]],[]],null]],[]]]],[]]],[1,"      "],[13],[1,"\\n"]],[]],null],[1,"    "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n      "],[10,0],[14,0,"agent-name"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","CHANNEL"]]],null],[[[1,"          "],[1,[30,0,["session","appDisplayName"]]],[1,"\\n"]],[]],[[[41,[28,[37,6],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","USER"]]],null]],null],[[[41,[30,0,["hideName"]],[[[1,"            "],[1,[30,0,["session","appDisplayName"]]],[1,"\\n"]],[]],[[[1,"            "],[1,[30,0,["model","messageUserFirstName"]]],[1,"\\n"]],[]]],[1,"        "]],[]],null]],[]]],[1,"      "],[13],[1,"\\n      "],[10,"ul"],[12],[1,"\\n        "],[10,"li"],[12],[1,"\\n          "],[10,0],[14,0,"h-fc-cobrowse"],[12],[1,"\\n"],[41,[30,0,["screenshareControl"]],[[[1,"              "],[10,0],[14,0,"sc-visitor-header"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.header_vc"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"sc-visitor-footer"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.footer_vc"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n                "],[10,3],[15,6,[30,0,["CO_BROWSING_SUPPORT_URL"]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,[28,[35,1],["screenShare.read_more_link"],null]],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"sc-visitor-header"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.header"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n              "],[13],[1,"\\n              "],[10,0],[14,0,"sc-visitor-footer"],[12],[1,"\\n                "],[1,[28,[35,1],["screenShare.footer"],[["agentName"],[[30,0,["model","messageUserFirstName"]]]]]],[1,"\\n                "],[10,3],[15,6,[30,0,["CO_BROWSING_SUPPORT_URL"]]],[14,"target","_blank"],[14,"rel","noopener noreferrer"],[12],[1,[28,[35,1],["screenShare.read_more_link"],null]],[13],[1,"\\n              "],[13],[1,"\\n"]],[]]],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","DENIED"]]],null],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[10,"button"],[14,0,"sc-deny-btn"],[14,4,"button"],[12],[1,"\\n                    "],[10,"i"],[14,0,"icon icon-ic_cobrowse_close"],[12],[13],[1,"\\n                    "],[1,[28,[35,1],["screenShare.denied"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","ACCEPTED"]]],null],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[10,"button"],[14,0,"sc-accept-btn"],[14,4,"button"],[12],[1,"\\n                    "],[10,"i"],[14,0,"icon icon-ic_cobrowse_tick"],[12],[13],[1,"\\n                    "],[1,[28,[35,1],["screenShare.approved"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,0],[14,0,"sc-visitor-tailer-control"],[12],[1,"\\n                "],[10,1],[14,0,"sc-btn-container"],[12],[1,"\\n                  "],[11,"button"],[24,0,"sc-accept-btn"],[24,4,"button"],[4,[38,7],[[30,0],"allowScreenShare",true],null],[12],[1,"\\n                    "],[1,[28,[35,1],["screenShare.allow"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n                "],[10,1],[14,0,"sc-btn-container last-btn"],[12],[1,"\\n                  "],[11,"button"],[24,0,"sc-deny-btn"],[24,4,"button"],[4,[38,7],[[30,0],"denyScreensShare"],null],[12],[1,"\\n                    "],[1,[28,[35,1],["screenShare.deny"],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "]],[]]]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","isCBDenied"]],[[[1,"  "],[10,0],[14,0,"h-chat"],[12],[1,"\\n"],[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","SCREEN_SHARING","CANCELLD"]]],null],[[[1,"      "],[10,0],[14,0,"h-fc-cb-status-messge"],[12],[1," "],[1,[28,[35,1],["screenShare.req_cancelled"],null]],[13],[1,"\\n"]],[]],[[[1,"      "],[10,0],[14,0,"h-fc-cb-status-messge"],[12],[1," "],[1,[28,[35,1],["screenShare.session_end"],null]],[13],[1,"\\n"]],[]]],[1,"  "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","messageType"]],[30,0,["CONVERSATION","MESSAGE_TYPE","CALENDAR","CANCELLED_BY_USER"]]],null],[[[1,"  "],[10,0],[14,0,"h-chat"],[12],[1,"\\n    "],[10,0],[14,0,"h-calendar-status-message-container"],[12],[1,"\\n      "],[10,0],[14,0,"h-calendar-cancelled-message-text"],[12],[1,"\\n        "],[1,[28,[35,1],["calendar.user_cancelled"],null]],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[41,[30,0,["showDayStamp"]],[[[1,"    "],[10,0],[14,0,"h-divide"],[12],[1,"\\n      "],[10,0],[12],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"d-line-left"],[12],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"date"],[12],[1,"\\n"],[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["day"]]],[[[1,"              "],[1,[28,[35,1],["conversation.chat_headers.today"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],[30,0,["yesterdayMillis"]]],[["precision"],["day"]]],[[[1,"              "],[1,[28,[35,1],["conversation.chat_headers.yesterday"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"D MMM YYYY"],null]],[1,"\\n            "]],[]]]],[]]],[1,"          "],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,"div",""],[14,0,"d-line-right"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[41,[30,0,["model","hasReadReceipt"]],[[[1,"    "],[10,0],[14,0,"h-divide"],[14,1,"newMessage"],[12],[1,"\\n      "],[10,0],[12],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"line"],[12],[13],[1,"\\n        "],[13],[1,"\\n        "],[10,1],[12],[10,1],[14,0,"text"],[12],[1,[28,[35,1],["conversation.chat_headers.new"],null]],[13],[13],[1,"\\n        "],[10,1],[12],[1,"\\n          "],[10,1],[14,0,"line"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[1,"\\n  "],[10,0],[15,0,[29,["h-chat ",[52,[30,0,["isArticleView"]],"h-article-view"]," ",[52,[30,0,["containsTranslations"]],"having-translations"]]]],[12],[1,"\\n"],[41,[28,[37,6],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","USER"]]],null]],null],[[[41,[30,0,["model","isBot"]],[[[41,[28,[37,2],[[30,0,["model","agentMessagePic"]],[30,0,["isGrpStart"]]],null],[[[1,"          "],[10,0],[15,0,[29,["agent-pic ",[52,[28,[37,6],[[30,0,["agentName"]]],null],"no-agent-name"]]]],[14,"aria-hidden","true"],[12],[1,"\\n            "],[10,"img"],[15,"src",[30,0,["model","agentMessagePic"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n          "],[13],[1,"\\n"]],[]],null]],[]],[[[41,[30,0,["isGrpStart"]],[[[1,"          "],[10,0],[15,0,[29,["agent-pic ",[52,[28,[37,6],[[30,0,["agentName"]]],null],"no-agent-name"]]]],[14,"aria-hidden","true"],[12],[1,"\\n"],[41,[30,0,["canShowFreshIdAgentPic"]],[[[1,"              "],[10,"img"],[15,"src",[30,0,["freshIdAgentPic"]]],[15,"alt",[28,[37,1],["aria-label.agent_profile_pic"],null]],[14,"height","24px"],[14,"width","24px"],[12],[13],[1,"\\n"]],[]],[[[41,[30,0,["agentPic","profilePicThumbUrl"]],[[[41,[28,[37,2],[[28,[37,5],[[30,0,["model","messageUserType"]],[30,0,["CONVERSATION","USER_TYPE","AGENT"]]],null],[28,[37,2],[[30,0,["hidePic"]],[28,[37,6],[[30,0,["hideName"]]],null]],null]],null],[[[1,"              "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n                "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["agentName"]]],null]]]],[12],[1,"\\n                  "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                    "],[1,[28,[35,4],[[30,0,["agentName"]]],null]],[1,"\\n                  "],[13],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n"]],[]],[[[1,"              "],[10,"img"],[15,"src",[30,0,["agentPic","profilePicThumbUrl"]]],[14,"height","24px"],[14,"width","24px"],[15,"alt",[28,[37,1],["alt.agent_profile_pic"],null]],[12],[13],[1,"\\n"]],[]]]],[]],[[[41,[30,0,["isAwayMessage"]],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,"\\n                  "],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[1,"\\n                "],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[30,0,["hideName"]],[30,0,["session","appDisplayName"]]],null],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["session","appDisplayName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["session","appDisplayName"]]],null]],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n"]],[]],[[[41,[30,0,["model","messageUserName"]],[[[1,"            "],[10,1],[14,0,"avatar-content-wrap"],[12],[1,"\\n              "],[10,1],[15,0,[29,["theme-bg ",[28,[37,3],[[30,0,["model","messageUserName"]]],null]]]],[12],[1,"\\n                "],[10,1],[14,0,"avatar-content"],[12],[1,[28,[35,4],[[30,0,["model","messageUserName"]]],null]],[13],[1,"\\n              "],[13],[1,"\\n            "],[13],[1,"\\n          "]],[]],null]],[]]]],[]]]],[]]]],[]]],[1,"          "],[13],[1,"\\n"]],[]],null],[41,[30,0,["isGrpEnd"]],[[[1,"          "],[10,1],[14,0,"time"],[12],[1,"\\n"],[41,[30,0,["model","createdMillis"]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["hour"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]]],[["interval"],[60000]]]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["day"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["week"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ddd, LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["year"]]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"MMM D, LT"],null]],[1,"\\n"]],[]],[[[1,"                "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ll, LT"],null]],[1,"\\n              "]],[]]]],[]]]],[]]]],[]]]],[]],null],[1,"          "],[13],[1,"\\n"]],[]],null]],[]]]],[]],null],[1,"    "],[10,0],[14,0,"h-conv multiple"],[12],[1,"\\n"],[41,[28,[37,2],[[30,0,["agentName"]],[30,0,["isGrpStart"]]],null],[[[1,"        "],[10,0],[14,0,"agent-name"],[12],[1,[28,[35,10],[[30,0,["agentName"]],"strict"],null]],[13],[1,"\\n"]],[]],null],[41,[28,[37,2],[[28,[37,11],[[30,0,["model"]]],null],[28,[37,6],[[30,0,["isUserPrivateMessage"]]],null]],null],[[[1,"        "],[8,[39,12],null,[["@message","@isMessageUnauthenticated","@containsTranslations","@showInBothLocales","@isOpen"],[[30,0,["model"]],[30,0,["model","isMessageUnauthenticated"]],[30,0,["containsTranslations"]],[30,0,["showTranslatedText"]],[30,0,["isOpen"]]]],null],[1,"\\n\\n"],[41,[28,[37,5],[[30,0,["model","status"]],[30,0,["MESSAGE_STATUS","NOT_SENT"]]],null],[[[1,"          "],[11,1],[24,0,"fc-resend"],[24,"tabindex","0"],[24,"role","button"],[4,[38,7],[[30,0],"resendMessage",[30,0,["model"]]],null],[12],[1,"\\n            "],[10,"i"],[14,0,"fc-ic-resend"],[12],[13],[1,"\\n            "],[10,1],[14,0,"screen-reader-only"],[12],[1,[28,[35,1],["aria_labels.message_not_sent"],null]],[13],[1,[28,[35,1],["message.resend_action"],null]],[1,"\\n          "],[13],[1,"\\n"]],[]],[[[41,[28,[37,5],[[30,0,["model","status"]],[30,0,["MESSAGE_STATUS","RETRYING"]]],null],[[[1,"          "],[10,0],[14,0,"time"],[12],[1,"\\n            "],[10,0],[12],[1,"\\n              "],[1,[28,[35,1],["message.pending"],null]],[1,"\\n            "],[13],[1,"\\n          "],[13],[1,"\\n        "]],[]],null]],[]]]],[]],null],[41,[30,0,["containsTranslations"]],[[[41,[51,[30,0,["isFreddyLiveTranslateEnabled"]]],[[[1,"          "],[11,1],[24,0,"translated-message-options-text"],[24,"tabindex","0"],[24,"role","button"],[4,[38,7],[[30,0],"toggleTranslatedTextView"],null],[12],[1,"\\n"],[41,[30,0,["showTranslatedText"]],[[[1,"              "],[1,[28,[35,1],["live_translate.hide_original"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,1],["live_translate.show_original"],null]],[1,"\\n"]],[]]],[1,"          "],[13],[1,"\\n"]],[]],null]],[]],null],[1,"\\n"],[41,[28,[37,2],[[30,0,["showTimeStamp"]],[28,[37,6],[[30,0,["isUserPrivateMessage"]]],null]],null],[[[1,"        "],[10,0],[14,0,"time"],[12],[1,"\\n"],[41,[30,0,["model","isMessagePending"]],[[[1,"            "],[10,0],[12],[1,[28,[35,1],["message.pending"],null]],[13],[1,"\\n"]],[]],[[[41,[28,[37,2],[[28,[37,6],[[30,0,["model","isLastMessageFailed"]]],null],[28,[37,6],[[30,0,["model","isRetryingLastMessage"]]],null]],null],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["hour"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]]],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["week"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ddd, LT"],null]],[1,"\\n"]],[]],[[[41,[28,[37,8],[[30,0,["model","createdMillis"]],"now"],[["precision"],["year"]]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"MMM D, LT"],null]],[1,"\\n"]],[]],[[[1,"              "],[1,[28,[35,9],[[30,0,["model","createdMillis"]],"ll, LT"],null]],[1,"\\n            "]],[]]]],[]]]],[]]],[1,"          "]],[]],null]],[]]],[1,"        "],[13],[1,"\\n"]],[]],null],[1,"    "],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,0,["showOfflineForm"]],[[[1,"    "],[8,[39,14],null,[["@extraParams","@sendOfflineMessage"],[[30,0,["extraParams"]],[28,[37,7],[[30,0],"sendOfflineMessage"],null]]],null],[1,"\\n"]],[]],null],[41,[30,0,["shouldDisplayCalendarPicker"]],[[[1,"    "],[8,[39,15],null,[["@message","@sendMessageFromAppConversation","@openCalendarPickerMaximized","@messageMetaData"],[[30,0,["model"]],[28,[37,7],[[30,0],"sendCalendarMessage"],null],[28,[37,7],[[30,0],"openCalendarPickerMaximized"],null],[30,0,["messageMetaData"]]]],null],[1,"\\n"]],[]],null]],[]]]],[]]]],[]]]],[],false,["if","t","and","choose-theme","avatar-content","eq","not","action","is-same","format-time","sanitize-html","contain-valid-text-fragment","ui-unity-message-fragment","unless","app-offline-form","ui-calendar-picker"]]',
                moduleName: "hotline-web/components/ui-message/template.hbs",
                isStrictMode: !1
            });
            t.default = w
        },
        78910: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(73734)),
                o = a(n(34607)),
                s = a(n(63398));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-button-composer/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-button-composer/component", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-multi-select-footer/template", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "4F+oW2oP",
                block: '[[[10,0],[14,0,"message-container"],[12],[1,"\\n  "],[10,0],[14,0,"button-region resize-fragments margin-reply-fragments"],[12],[1,"\\n"],[42,[28,[37,1],[[28,[37,1],[[30,0,["buttonsData"]]],null]],null],null,[[[1,"      "],[8,[39,2],null,[["@sendButtonMessage","@model","@label","@selected"],[[28,[37,3],[[30,0],"onSelect",[30,2]],null],[30,1],[30,1,["label"]],[30,1,["selected"]]]],null],[1,"\\n"]],[1,2]],null],[1,"  "],[13],[1,"\\n\\n "],[8,[39,4],null,[["@selectedCount","@deselectSelection","@submitSelection"],[[30,0,["count"]],[28,[37,3],[[30,0],"deselectAll"],null],[28,[37,3],[[30,0],"sendMessage"],null]]],null],[1,"\\n"],[13]],["button","index"],false,["each","-track-array","ui-button-composer","action","ui-multi-select-footer"]]',
                moduleName: "hotline-web/components/ui-multi-select-buttons/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        66895: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = (0, Ember.HTMLBars.template)({
                id: "T30oUpBn",
                block: '[[[11,0],[16,0,[28,[37,0],["phone-number-code editable ce-textarea ",[52,[30,1],"validation-error"]],null]],[4,[38,2],[[30,0,["initiateInput"]]],null],[12],[1,"\\n  "],[11,"input"],[24,1,"phone-number-code"],[16,0,[29,[[52,[51,[30,0,["hotline","ui","isDesktop"]]],"mobile-phone-input"]]]],[24,4,"tel"],[4,[38,4],["change",[30,0,["changePhoneNumber"]]],null],[4,[38,4],["input",[30,0,["checkInput"]]],null],[12],[13],[1,"\\n  \\n    "],[10,0],[14,1,"append-country-list-ul"],[12],[13],[1,"\\n"],[41,[51,[30,0,["hotline","ui","isDesktop"]]],[[[1,"      "],[11,3],[16,0,[29,["h-reply-container rm-text-decorator\\n        ",[52,[30,0,["isValueInEditor"]],"active","disabled"]]]],[24,6,"#"],[4,[38,5],[[30,0],"changePhoneNumber"],null],[12],[1,"\\n\\n        "],[10,0],[14,0,"h-reply-send"],[12],[1,"\\n          "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n        "],[13],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[13]],["@showValidationMsg"],false,["concat","if","did-insert","unless","on","action"]]',
                moduleName: "hotline-web/components/ui-phone-number/template.hbs",
                isStrictMode: !1
            });
            t.default = n
        },
        47273: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = c(n(73734)),
                o = c(n(34607)),
                s = c(n(48692)),
                a = c(n(54119)),
                l = c(n(47838)),
                r = c(n(20961)),
                u = c(n(15611));

            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-button-composer/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-button-composer/component", (function() {
                return o.default
            })), window.define("hotline-web/helpers/and", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-quick-action-menu/template", (function() {
                return a.default
            })), window.define("hotline-web/components/ui-quick-action-menu/component", (function() {
                return l.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/template", (function() {
                return r.default
            })), window.define("hotline-web/components/ui-ellipsis-icon/component", (function() {
                return u.default
            }));
            var d = (0, Ember.HTMLBars.template)({
                id: "IZX8b1P/",
                block: '[[[10,0],[14,0,"actions-button-dropdown"],[12],[1,"\\n  "],[10,0],[14,0,"actions-button-region"],[12],[1,"\\n"],[42,[28,[37,1],[[28,[37,1],[[30,0,["primaryActions"]]],null]],null],null,[[[1,"      "],[8,[39,2],[[16,0,[29,["h-img-button--mini ",[52,[30,0,["resendOtpButton"]],"disabled"]]]],[16,"disabled",[30,0,["resendOtpButton"]]]],[["@sendButtonMessage","@isQuickActionButton","@model","@title"],[[28,[37,4],[[30,0],[30,2]],null],true,[30,1],[30,1,["label"]]]],null],[1,"\\n"]],[1]],null],[1,"\\n"],[41,[28,[37,5],[[30,0,["resendOtpButton"]],[30,0,["displayCounter"]]],null],[[[1,"      "],[11,1],[24,0,"otp-timer"],[4,[38,6],[[30,0,["clearExistingTimer"]]],null],[12],[1,"\\n        "],[1,[30,0,["defaultCounterValue"]]],[1,":"],[1,[30,0,["displayCounter"]]],[1,"\\n      "],[13],[1,"\\n"]],[]],null],[1,"  "],[13],[1,"\\n"],[41,[30,0,["restActions"]],[[[1,"    "],[8,[39,7],null,[["@selectionHandler","@quickActions"],[[28,[37,4],[[30,0],[30,2]],null],[30,0,["restActions"]]]],[["default"],[[[[1,"\\n      "],[10,"button"],[15,0,[29,["h-img-button h-img-button--mini ",[52,[30,0,["isIPhone"]],"iphone-button"]]]],[14,4,"button"],[12],[1,"\\n        "],[8,[39,8],null,[["@fillColor","@class","@alignment","@height"],["#12344D","vertical-align-middle","horizontal","1rem"]],null],[1,"\\n      "],[13],[1,"\\n    "]],[]]]]],[1,"\\n"]],[]],null],[13]],["button","@sendButtonMessage"],false,["each","-track-array","ui-button-composer","if","action","and","will-destroy","ui-quick-action-menu","ui-ellipsis-icon"]]',
                moduleName: "hotline-web/components/ui-quick-action-buttons/template.hbs",
                isStrictMode: !1
            });
            t.default = d
        },
        54119: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(8964)),
                o = l(n(86687)),
                s = l(n(2895)),
                a = l(n(34354));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return i.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-dropdown-list/template", (function() {
                return s.default
            })), window.define("hotline-web/components/ui-dropdown-list/component", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "MNsWForh",
                block: '[[[10,0],[12],[1,"\\n  "],[8,[39,0],null,[["@calculatePosition"],[[30,1]]],[["default"],[[[[1,"\\n    "],[8,[30,2,["Trigger"]],null,null,[["default"],[[[[1,"\\n      "],[18,4,null],[1,"\\n    "]],[]]]]],[1,"\\n    "],[8,[30,2,["Content"]],[[24,0,"actions-menu"]],null,[["default"],[[[[1,"\\n      "],[8,[39,2],null,[["@items","@selectionHandler","@dropdown"],[[30,3],[28,[37,3],[[30,0],[30,0,["handleSelection"]]],null],[30,2]]],null],[1,"\\n    "]],[]]]]],[1,"\\n  "]],[2]]]]],[1,"\\n"],[13],[1,"\\n"]],["@menuPosition","dd","@quickActions","&default"],false,["basic-dropdown","yield","ui-dropdown-list","action"]]',
                moduleName: "hotline-web/components/ui-quick-action-menu/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        37717: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(2895)),
                o = s(n(34354));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-dropdown-list/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-dropdown-list/component", (function() {
                return o.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "8vlC/9yV",
                block: '[[[41,[30,0,["filteredQuickActions","length"]],[[[1,"  "],[10,0],[15,1,[30,0,["slashCmdId"]]],[14,0,"custom-dropdown-content"],[12],[1,"\\n    "],[8,[39,1],null,[["@enableKeyboardNavigation","@items","@selectionHandler"],[true,[30,0,["filteredQuickActions"]],[28,[37,2],[[30,0],[30,0,["handleSelection"]]],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null]],[],false,["if","ui-dropdown-list","action"]]',
                moduleName: "hotline-web/components/ui-quick-action-slash-menu/template.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        99251: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = u(n(48692)),
                o = u(n(2895)),
                s = u(n(34354)),
                a = u(n(98661)),
                l = u(n(83973)),
                r = u(n(12076));

            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/helpers/and", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-dropdown-list/template", (function() {
                return o.default
            })), window.define("hotline-web/components/ui-dropdown-list/component", (function() {
                return s.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return a.default
            })), window.define("hotline-web/helpers/t", (function() {
                return l.default
            })), window.define("hotline-web/helpers/not", (function() {
                return r.default
            }));
            var c = (0, Ember.HTMLBars.template)({
                id: "HYBY4RM/",
                block: '[[[41,[28,[37,1],[[30,0,["isDropdownOpen"]],[30,0,["filteredOptions","length"]]],null],[[[1,"  "],[10,0],[14,0,"custom-dropdown-content"],[12],[1,"\\n    "],[8,[39,2],null,[["@enableKeyboardNavigation","@multiple","@items","@selectedItems","@selectionHandler"],[true,[30,1],[30,0,["filteredOptions"]],[30,0,["selectedOptions"]],[28,[37,3],[[30,0],[30,0,["selectionHandler"]]],null]]],null],[1,"\\n  "],[13],[1,"\\n"]],[]],null],[1,"\\n"],[10,0],[14,0,"select-box"],[12],[1,"\\n  "],[11,0],[24,0,"select-box-trigger"],[24,"role","button"],[4,[38,4],["click",[30,0,["toggleDD"]]],null],[4,[38,4],["keydown",[30,0,["handleKeyPressDown"]]],null],[12],[1,"\\n    "],[10,0],[14,0,"select-box-input-container"],[12],[1,"\\n"],[41,[30,1],[[[42,[28,[37,6],[[28,[37,6],[[30,0,["selectedOptions"]]],null]],null],null,[[[1,"          "],[10,0],[14,0,"multi-select-option"],[12],[1,"\\n            "],[10,1],[14,0,"multi-select-option--name"],[12],[1,"\\n              "],[1,[28,[35,7],[[28,[37,8],[[30,2],[30,0,["bindLabel"]]],null],"strict"],null]],[1,"\\n            "],[13],[1,"\\n"],[1,"            "],[11,1],[24,0,"multi-select-option--remove"],[4,[38,4],["click",[28,[37,9],[[30,0,["removeItem"]],[30,2]],null]],null],[12],[1,"\\n              x\\n            "],[13],[1,"\\n"],[1,"          "],[13],[1,"\\n"]],[2,3]],null]],[]],null],[1,"\\n      "],[8,[39,10],[[16,"placeholder",[52,[51,[30,0,["selectedOptions","length"]]],[30,0,["dropdownPlaceholder"]]]],[24,0,"select-box-input"],[24,"autocomplete","off"],[16,"aria-label",[28,[37,12],["aria_labels.search"],null]],[4,[38,4],["input",[30,0,["showDropdown"]]],null],[4,[38,13],[[30,0,["focusInput"]]],null]],[["@value"],[[30,0,["searchText"]]]],null],[1,"\\n    "],[13],[1,"\\n    "],[10,"img"],[14,0,"dropdown-icon"],[15,"src",[30,0,["images","DropdownArrow"]]],[15,"alt",[28,[37,12],["alt.dropdown_arrow"],null]],[12],[13],[1,"\\n  "],[13],[1,"\\n"],[41,[30,1],[[[1,"    "],[11,"button"],[24,0,"h-icon-button"],[16,"disabled",[28,[37,14],[[30,0,["selectedOptions","length"]]],null]],[24,4,"button"],[4,[38,4],["click",[30,0,["onMultiSubmit"]]],null],[12],[1,"\\n      "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n    "],[13],[1,"\\n"]],[]],null],[13]],["@multiple","option","index"],false,["if","and","ui-dropdown-list","action","on","each","-track-array","sanitize-html","get","fn","input","unless","t","autofocus-when","not"]]',
                moduleName: "hotline-web/components/ui-select-box/template.hbs",
                isStrictMode: !1
            });
            t.default = c
        },
        5234: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(n(8964)),
                o = l(n(86687)),
                s = l(n(83973)),
                a = l(n(98661));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/templates/components/basic-dropdown", (function() {
                return i.default
            })), window.define("hotline-web/components/basic-dropdown", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            })), window.define("hotline-web/helpers/sanitize-html", (function() {
                return a.default
            }));
            var r = (0, Ember.HTMLBars.template)({
                id: "D8bZH27h",
                block: '[[[8,[39,0],null,[["@calculatePosition"],[[30,0,["calculatePosition"]]]],[["default"],[[[[1,"\\n  "],[8,[30,1,["Trigger"]],null,null,[["default"],[[[[1,"\\n    "],[8,[39,1],[[16,"placeholder",[28,[37,2],["conversation.ce.placeholders.time"],null]],[24,"autocomplete","off"],[16,0,[29,["time-picker-input ",[52,[30,0,["isValidationError"]],"validation-error"]]]],[24,1,"focus-input"]],[["@type","@key-down"],["text",[28,[37,4],[[30,0],"onInputKeyDown"],null]]],null],[1,"\\n  "]],[]]]]],[1,"\\n  "],[8,[30,1,["Content"]],null,null,[["default"],[[[[1,"\\n    "],[10,"ul"],[14,0,"time-list dropdown-list"],[14,"tabindex","-1"],[14,"role","listbox"],[12],[1,"\\n"],[42,[28,[37,6],[[28,[37,6],[[30,0,["timeOptions"]]],null]],null],null,[[[1,"        "],[10,"li"],[15,"onclick",[28,[37,4],[[30,0],"onSelectDropdown",[30,2]],null]],[14,"tabindex","-1"],[14,"aria-selected","false"],[14,0,"drop-down-list"],[14,"role","option"],[12],[1,[28,[35,7],[[30,2,["label"]],"strict"],null]],[13],[1,"\\n"]],[2,3]],null],[1,"    "],[13],[1,"\\n  "]],[]]]]],[1,"\\n"]],[1]]]]]],["dd","option","index"],false,["basic-dropdown","input","t","if","action","each","-track-array","sanitize-html"]]',
                moduleName: "hotline-web/components/ui-time-picker/template.hbs",
                isStrictMode: !1
            });
            t.default = r
        },
        24892: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n(67157)),
                o = a(n(83057)),
                s = a(n(83973));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/ui-attachment-preview/template", (function() {
                return i.default
            })), window.define("hotline-web/components/ui-editor/component", (function() {
                return o.default
            })), window.define("hotline-web/helpers/t", (function() {
                return s.default
            }));
            var l = (0, Ember.HTMLBars.template)({
                id: "pDUlLJt/",
                block: '[[[41,[30,0,["file","fileData","name"]],[[[1,"  "],[8,[39,1],null,[["@fileData","@imageSelect","@onKeyDown","@clearImage"],[[30,0,["file"]],[30,1],[28,[37,2],[[30,0],"onFileEdit"],null],[30,2]]],null],[1,"\\n"]],[]],null],[1,"  "],[8,[39,3],null,[["@onBlur","@onFocus","@ariaLabel","@onClickEditor","@onKeyDown","@contentEditable","@exceedAction","@testId","@placeholder","@autoFocus"],[[28,[37,2],[[30,0],"focusOut"],null],[28,[37,2],[[30,0],"focusIn"],null],"aria_labels.file_attachment",[28,[37,2],[[30,0],"onClickHandler"],null],[28,[37,2],[[30,0],"onEnterFileUpload"],null],false,[30,3],"attachment-editor","conversation.ce.placeholders.attachment",true]],null],[1,"\\n"],[41,[30,0,["file","fileData","name"]],[[[1,"  "],[11,3],[24,6,"#"],[16,0,[29,["h-reply-container ",[52,[30,0,["file","fileData","name"]]," active"]]]],[24,"role","button"],[4,[38,2],[[30,0],[30,4]],null],[12],[1,"\\n    "],[10,0],[15,0,[29,["h-reply-send ",[52,[30,0,["file","fileData","name"]]," fileAttached"]]]],[12],[1,"\\n      "],[10,"i"],[14,0,"icons icon-ic_send"],[12],[13],[1,"\\n    "],[13],[1,"\\n  "],[13],[1,"\\n"]],[]],[[[1,"  "],[11,3],[24,6,"#"],[16,0,[29,["h-reply-smiley ",[52,[30,0,["file","fileData","name"]]," fileAttached"]]]],[24,"role","button"],[16,"aria-label",[28,[37,4],["aria_labels.file_attachment"],null]],[4,[38,2],[[30,0],[30,1]],null],[12],[1,"\\n    "],[10,"i"],[14,0,"icons icon-ic_attachment"],[12],[13],[1,"\\n  "],[13],[1,"\\n"]],[]]]],["@imageSelect","@clearImage","@exceedAction","@sendAttachment"],false,["if","ui-attachment-preview","action","ui-editor","t"]]',
                moduleName: "hotline-web/components/ui-upload-attachment/template.hbs",
                isStrictMode: !1
            });
            t.default = l
        },
        30169: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = s(n(55357)),
                o = s(n(46379));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            window.define("hotline-web/components/app-conversation/template", (function() {
                return i.default
            })), window.define("hotline-web/components/app-conversation/component", (function() {
                return o.default
            }));
            var a = (0, Ember.HTMLBars.template)({
                id: "VPtU3kpF",
                block: '[[[8,[39,0],null,[["@model","@gotoHome"],[[30,0,["model"]],[28,[37,1],[[30,0],"gotoHome"],null]]],null]],[],false,["app-conversation","action"]]',
                moduleName: "hotline-web/templates/home/channel.hbs",
                isStrictMode: !1
            });
            t.default = a
        },
        57041: function(e, t, n) {
            "use strict";
            t.Z = n.p + "info_red.63f90ddece5b89e17560b1cc02645168.svg"
        }
    }
]);