"use strict";
(self.webpackChunkhotline_web = self.webpackChunkhotline_web || []).push([
    [7873], {
        57873: function(e, n, t) {
            t.r(n), n.default = {}
        }
    }
]);