define("@ember/error/index", ["exports"], function(_exports) {
    "use strict";

    Object.defineProperty(_exports, "__esModule", {
        value: true
    });
    _exports.default = void 0;

    /**
     @module @ember/error
    */

    /**
      The JavaScript Error object used by Ember.assert.
  
      @class Error
      @namespace Ember
      @extends Error
      @constructor
      @public
    */
    var _default = Error;
    _exports.default = _default;
});