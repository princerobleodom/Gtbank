define("@ember/component/template-only", ["exports", "@glimmer/runtime"], function(_exports, _runtime) {
    "use strict";

    Object.defineProperty(_exports, "__esModule", {
        value: true
    });
    Object.defineProperty(_exports, "default", {
        enumerable: true,
        get: function get() {
            return _runtime.templateOnlyComponent;
        }
    });
});